import { boolean, doublePrecision, integer, jsonb, pgTable, serial, text, timestamp } from "drizzle-orm/pg-core";
import type {
  Budget,
  Finding,
  Hypothesis,
  NegativeSpaceReport,
  QueryTraceStep,
} from "@/lib/nullspace/types";
import type { EngineEvent } from "@/lib/nullspace/state";

export const cases = pgTable("cases", {
  id: text("id").primaryKey(),
  scenarioKey: text("scenario_key"),
  alertClass: text("alert_class").notNull(),
  status: text("status").notNull().default("investigating"),
  alert: jsonb("alert").$type<Record<string, unknown>>().notNull(),
  label: text("label"),
  verdict: text("verdict"),
  verdictConfidence: doublePrecision("verdict_confidence"),
  verdictReason: text("verdict_reason"),
  recommendedAction: text("recommended_action"),
  decisiveQuestion: text("decisive_question"),
  winningKey: text("winning_key"),
  negativeSpace: jsonb("negative_space").$type<NegativeSpaceReport | null>(),
  hypothesesInitial: jsonb("hypotheses_initial").$type<Hypothesis[]>(),
  hypothesesFinal: jsonb("hypotheses_final").$type<Hypothesis[]>(),
  queryTrace: jsonb("query_trace").$type<QueryTraceStep[]>(),
  budgetUsed: jsonb("budget_used").$type<Budget | null>(),
  events: jsonb("events").$type<EngineEvent[]>(),
  queryCount: integer("query_count").notNull().default(0),
  llmUsed: boolean("llm_used").notNull().default(false),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  completedAt: timestamp("completed_at", { withTimezone: true }),
});

export const caseFindings = pgTable("case_findings", {
  id: serial("id").primaryKey(),
  caseId: text("case_id").notNull(),
  findingId: text("finding_id").notNull(),
  claim: text("claim").notNull(),
  type: text("type").notNull(),
  queryTemplateId: text("query_template_id").notNull(),
  params: jsonb("params").$type<Record<string, unknown>>().notNull(),
  executedAt: text("executed_at").notNull(),
  resultHash: text("result_hash").notNull(),
  resultSnapshotUri: text("result_snapshot_uri").notNull(),
  reproducibility: text("reproducibility").notNull(),
  coverageAtExecution: text("coverage_at_execution").notNull(),
  hypothesisImpact: jsonb("hypothesis_impact").$type<string[]>().notNull(),
  summary: text("summary").notNull(),
  result: jsonb("result").$type<Record<string, unknown>>().notNull(),
});

export const verifications = pgTable("verifications", {
  id: serial("id").primaryKey(),
  caseId: text("case_id").notNull(),
  findingId: text("finding_id").notNull(),
  status: text("status").notNull(),
  mode: text("mode").notNull(),
  originalHash: text("original_hash").notNull(),
  currentHash: text("current_hash").notNull(),
  diff: jsonb("diff").$type<Record<string, unknown> | null>(),
  message: text("message").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const historicalCases = pgTable("historical_cases", {
  id: serial("id").primaryKey(),
  alertClass: text("alert_class").notNull(),
  cluster: text("cluster").notNull(),
  resolution: text("resolution").notNull(),
  cases: integer("cases").notNull(),
  label: text("label").notNull(),
});

export const evaluationRuns = pgTable("evaluation_runs", {
  id: text("id").primaryKey(),
  startedAt: timestamp("started_at", { withTimezone: true }).notNull().defaultNow(),
  total: integer("total").notNull(),
  correct: integer("correct").notNull(),
  sycophancyRate: doublePrecision("sycophancy_rate").notNull(),
  averageQueries: doublePrecision("average_queries").notNull(),
  benignSurvival: doublePrecision("benign_survival"),
  results: jsonb("results").$type<Record<string, unknown>[]>().notNull(),
});
