import type { HypothesisStatus, PredictionOutcome, FindingType, CoverageStatus, Inference } from "@/lib/nullspace/types";

const VERDICT_STYLE: Record<string, string> = {
  benign: "border-emerald-500/40 bg-emerald-500/10 text-emerald-300",
  benign_noisy: "border-emerald-500/40 bg-emerald-500/10 text-emerald-300",
  suspicious: "border-amber-500/40 bg-amber-500/10 text-amber-300",
  confirmed: "border-rose-500/50 bg-rose-500/15 text-rose-300",
  tamper_suspected: "border-fuchsia-500/40 bg-fuchsia-500/10 text-fuchsia-300",
  indeterminate: "border-sky-500/40 bg-sky-500/10 text-sky-300",
};

const VERDICT_TEXT: Record<string, string> = {
  benign: "Benign — falsified",
  benign_noisy: "Benign — recurring noise",
  suspicious: "Suspicious — corroborated",
  confirmed: "Confirmed — canary tripped",
  tamper_suspected: "Tamper suspected",
  indeterminate: "Indeterminate",
};

export function VerdictBadge({ verdict, confidence }: { verdict: string; confidence?: number }) {
  return (
    <span className="inline-flex items-center gap-2">
      <span
        className={`inline-flex items-center rounded-full border px-2.5 py-0.5 text-[10px] font-semibold uppercase tracking-wider ${VERDICT_STYLE[verdict] ?? "border-slate-700 bg-slate-800/60 text-slate-300"}`}
      >
        {VERDICT_TEXT[verdict] ?? verdict}
      </span>
      {typeof confidence === "number" ? (
        <span className="mono text-[10px] text-slate-500">p={(confidence * 100).toFixed(0)}%</span>
      ) : null}
    </span>
  );
}

export function StatusBadge({ status }: { status: HypothesisStatus }) {
  const style: Record<HypothesisStatus, string> = {
    alive: "border-emerald-500/40 bg-emerald-500/10 text-emerald-300",
    falsified: "border-rose-500/40 bg-rose-500/10 text-rose-300",
    unobservable: "border-slate-600 bg-slate-800/60 text-slate-400",
  };
  const label: Record<HypothesisStatus, string> = { alive: "alive", falsified: "falsified", unobservable: "unobservable" };
  return (
    <span className={`mono rounded border px-1.5 py-0.5 text-[10px] uppercase ${style[status]}`}>{label[status]}</span>
  );
}

export function OutcomeChip({ outcome }: { outcome: PredictionOutcome | null | undefined }) {
  if (!outcome) {
    return <span className="mono rounded border border-slate-700 bg-slate-800/40 px-1.5 py-0.5 text-[10px] text-slate-500">untested</span>;
  }
  const style: Record<PredictionOutcome, string> = {
    confirmed: "border-emerald-500/40 bg-emerald-500/10 text-emerald-300",
    violated: "border-rose-500/40 bg-rose-500/10 text-rose-300",
    unobservable: "border-sky-500/40 bg-sky-500/10 text-sky-300",
  };
  const label: Record<PredictionOutcome, string> = { confirmed: "✓ confirmed", violated: "✗ violated", unobservable: "? unobservable" };
  return <span className={`mono rounded border px-1.5 py-0.5 text-[10px] ${style[outcome]}`}>{label[outcome]}</span>;
}

export function FindingTypeBadge({ type }: { type: FindingType }) {
  const style: Record<FindingType, string> = {
    presence: "border-cyan-500/40 bg-cyan-500/10 text-cyan-300",
    absence: "border-slate-600 bg-slate-800/60 text-slate-300",
    anomaly: "border-fuchsia-500/40 bg-fuchsia-500/10 text-fuchsia-300",
  };
  return <span className={`mono rounded border px-1.5 py-0.5 text-[10px] uppercase ${style[type]}`}>{type}</span>;
}

export function CoverageChip({ status }: { status: CoverageStatus }) {
  const style: Record<CoverageStatus, string> = {
    covered: "border-emerald-500/40 bg-emerald-500/10 text-emerald-300",
    uncovered: "border-rose-500/40 bg-rose-500/10 text-rose-300",
    unknown: "border-slate-600 bg-slate-800/60 text-slate-400",
  };
  return <span className={`mono rounded border px-1.5 py-0.5 text-[10px] ${style[status]}`}>{status}</span>;
}

export function InferenceChip({ inference }: { inference: Inference }) {
  const style: Record<Inference, string> = {
    presence: "border-emerald-500/40 bg-emerald-500/10 text-emerald-300",
    mild_absence: "border-amber-500/40 bg-amber-500/10 text-amber-300",
    anomaly: "border-fuchsia-500/40 bg-fuchsia-500/10 text-fuchsia-300",
    unknown: "border-sky-500/40 bg-sky-500/10 text-sky-300",
  };
  return <span className={`mono rounded border px-1.5 py-0.5 text-[10px] ${style[inference]}`}>{inference}</span>;
}

export function Bar({ value, tone = "cyan" }: { value: number; tone?: "cyan" | "emerald" | "rose" }) {
  const colors: Record<string, string> = {
    cyan: "bg-cyan-400/70",
    emerald: "bg-emerald-400/70",
    rose: "bg-rose-400/70",
  };
  return (
    <span className="relative block h-1.5 w-full overflow-hidden rounded-full bg-slate-800">
      <span className={`absolute inset-y-0 left-0 rounded-full ${colors[tone]}`} style={{ width: `${Math.min(100, Math.max(0, value * 100))}%` }} />
    </span>
  );
}
