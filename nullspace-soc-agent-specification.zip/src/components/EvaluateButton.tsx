"use client";

import { useState } from "react";
import type { EvaluationReport } from "@/lib/nullspace/evaluate";

export function EvaluateButton({ llmAvailable }: { llmAvailable: boolean }) {
  const [busy, setBusy] = useState(false);
  const [report, setReport] = useState<EvaluationReport | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [useLlm, setUseLlm] = useState(false);

  async function run() {
    setBusy(true);
    setError(null);
    try {
      const response = await fetch("/api/evaluate", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ useLlm }),
      });
      const payload = (await response.json()) as EvaluationReport & { error?: string };
      if (!response.ok) throw new Error(payload.error ?? "evaluation failed");
      setReport(payload);
    } catch (err) {
      setError(err instanceof Error ? err.message : String(err));
    } finally {
      setBusy(false);
    }
  }

  const metrics = report
    ? [
        ["accuracy", `${(report.accuracy * 100).toFixed(0)}%`, report.correct, report.total],
        ["sycophancy rate", `${(report.sycophancyRate * 100).toFixed(1)}%`, null, null],
        ["avg queries", report.averageQueries.toFixed(1), null, null],
        ["benign survival", `${(report.benignSurvivalRate * 100).toFixed(0)}%`, null, null],
        ["false-negative rate", `${(report.falseNegativeRate * 100).toFixed(0)}%`, null, null],
      ]
    : [];

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-center gap-3">
        <button
          type="button"
          onClick={() => void run()}
          disabled={busy}
          className="rounded-md bg-cyan-500/90 px-4 py-2 text-xs font-semibold text-slate-950 transition hover:bg-cyan-400 disabled:opacity-50"
        >
          {busy ? "replaying golden set…" : "Run golden-case replay"}
        </button>
        <label className="flex items-center gap-2 text-xs text-slate-400">
          <input
            type="checkbox"
            checked={useLlm}
            onChange={(e) => setUseLlm(e.target.checked)}
            disabled={!llmAvailable}
            className="h-3.5 w-3.5 rounded border-slate-600 bg-slate-800"
          />
          include LLM generative source{llmAvailable ? "" : " (OPENAI_API_KEY not set)"}
        </label>
      </div>

      {error ? (
        <p className="rounded-md border border-rose-500/40 bg-rose-500/10 px-3 py-2 text-xs text-rose-300">{error}</p>
      ) : null}

      {report ? (
        <>
          <div className="grid gap-3 sm:grid-cols-3 lg:grid-cols-5">
            {metrics.map(([label, value, num, den]) => (
              <div key={String(label)} className="rounded-xl border border-slate-800 bg-slate-950/60 p-3">
                <p className="text-[10px] uppercase tracking-wider text-slate-500">{label}</p>
                <p className="mono mt-1 text-xl text-slate-100">{value}</p>
                {num !== null ? <p className="mono text-[10px] text-slate-500">{num}/{den} cases</p> : null}
              </div>
            ))}
          </div>

          <p
            className={`mono rounded-lg border px-3 py-2 text-[11px] ${
              report.anomalyFindingDetected
                ? "border-fuchsia-500/40 bg-fuchsia-500/10 text-fuchsia-300"
                : "border-amber-500/40 bg-amber-500/10 text-amber-300"
            }`}
          >
            negative-space test: {report.anomalyFindingDetected ? "ANOMALY finding produced when the EDR heartbeat was removed ✓" : "no anomaly finding produced"}
          </p>

          <div className="overflow-hidden rounded-xl border border-slate-800">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-900/70 text-[10px] uppercase tracking-wider text-slate-500">
                <tr>
                  <th className="px-3 py-2">scenario</th>
                  <th className="px-3 py-2">expected</th>
                  <th className="px-3 py-2">actual</th>
                  <th className="px-3 py-2">paraphrase</th>
                  <th className="px-3 py-2">queries</th>
                  <th className="px-3 py-2">falsified</th>
                  <th className="px-3 py-2">negative space</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/70 bg-slate-950/40">
                {report.results.map((r) => (
                  <tr key={r.scenarioKey}>
                    <td className="px-3 py-2 text-slate-300">{r.label}</td>
                    <td className="mono px-3 py-2 text-slate-400">{r.expected}</td>
                    <td className={`mono px-3 py-2 ${r.correct ? "text-emerald-300" : "text-rose-300"}`}>{r.actual}</td>
                    <td className={`mono px-3 py-2 ${r.sycophancyFlip ? "text-rose-300" : "text-slate-400"}`}>
                      {r.paraphraseVerdict}
                    </td>
                    <td className="mono px-3 py-2 text-slate-300">
                      {r.queries}/{r.paraphraseQueries}
                    </td>
                    <td className="mono px-3 py-2 text-slate-400">
                      {r.falsified}/{r.hypotheses}
                    </td>
                    <td className="mono px-3 py-2 text-slate-400">{r.negativeSpace}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {report.results.some((r) => r.decisiveQuestion) ? (
            <div className="rounded-xl border border-slate-800 bg-slate-900/40 p-4">
              <p className="text-[10px] uppercase tracking-wider text-slate-500">decisive questions emitted</p>
              <ul className="mt-2 space-y-1.5">
                {report.results
                  .filter((r) => r.decisiveQuestion)
                  .map((r) => (
                    <li key={r.scenarioKey} className="text-[11px] leading-relaxed text-slate-300">
                      <span className="mono text-slate-500">{r.scenarioKey}</span> — {r.decisiveQuestion}
                    </li>
                  ))}
              </ul>
            </div>
          ) : null}
        </>
      ) : (
        <p className="text-xs leading-relaxed text-slate-500">
          Replays every labelled golden case twice — once with the original alert prose and once with a paraphrase that
          carries identical structured data — then measures verdict accuracy, sycophancy (verdict flips under
          rewording), query budget, benign-explanation survival and false negatives.
        </p>
      )}
    </div>
  );
}
