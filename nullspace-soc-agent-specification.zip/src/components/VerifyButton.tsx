"use client";

import { useState } from "react";

interface VerifyResponse {
  status: "PASS" | "DRIFT" | "FAIL";
  message: string;
  originalHash: string;
  currentHash: string;
  diff: Record<string, unknown> | null;
  currentData?: Record<string, unknown> | null;
  snapshotData?: Record<string, unknown> | null;
}

export function VerifyButton({ findingId, reproducibility }: { findingId: string; reproducibility: string }) {
  const [busy, setBusy] = useState<"replay" | "drift" | null>(null);
  const [result, setResult] = useState<VerifyResponse | null>(null);
  const [error, setError] = useState<string | null>(null);

  async function run(mode: "replay" | "drift") {
    setBusy(mode);
    setError(null);
    try {
      const response = await fetch(`/api/findings/${findingId}/verify`, {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ mode }),
      });
      const payload = (await response.json()) as VerifyResponse & { error?: string };
      if (!response.ok) throw new Error(payload.error ?? "verification failed");
      setResult(payload);
    } catch (err) {
      setError(err instanceof Error ? err.message : String(err));
    } finally {
      setBusy(null);
    }
  }

  const tone =
    result?.status === "PASS"
      ? "border-emerald-500/40 bg-emerald-500/10 text-emerald-300"
      : result?.status === "DRIFT"
        ? "border-amber-500/40 bg-amber-500/10 text-amber-300"
        : "border-rose-500/40 bg-rose-500/10 text-rose-300";

  return (
    <div className="mt-3 space-y-2">
      <div className="flex flex-wrap items-center gap-2">
        <button
          type="button"
          onClick={() => void run("replay")}
          disabled={busy !== null}
          className="mono rounded border border-cyan-500/40 bg-cyan-500/10 px-2.5 py-1 text-[11px] text-cyan-200 transition hover:bg-cyan-500/20 disabled:opacity-50"
        >
          {busy === "replay" ? "re-running…" : "▶ re-run query"}
        </button>
        <button
          type="button"
          onClick={() => void run("drift")}
          disabled={busy !== null}
          className="mono rounded border border-slate-700 bg-slate-800/50 px-2.5 py-1 text-[11px] text-slate-300 transition hover:bg-slate-800 disabled:opacity-50"
        >
          {busy === "drift" ? "re-running…" : "▶ re-run in drifted world"}
        </button>
        <span className="mono text-[10px] uppercase text-slate-500">{reproducibility.replace("_", " ")}</span>
      </div>

      {error ? <p className="mono text-[11px] text-rose-400">{error}</p> : null}

      {result ? (
        <div className={`rounded-lg border p-3 ${tone}`}>
          <p className="mono text-xs font-semibold">
            {result.status} · {result.message}
          </p>
          <div className="mono mt-2 grid gap-1 text-[10px] text-slate-400 sm:grid-cols-2">
            <span className="truncate">original {result.originalHash.slice(0, 32)}…</span>
            <span className="truncate">current {result.currentHash.slice(0, 32)}…</span>
          </div>
          {result.diff ? (
            <pre className="mono mt-2 max-h-40 overflow-auto rounded bg-slate-950/70 p-2 text-[10px] leading-relaxed text-slate-300">
              {JSON.stringify(result.diff, null, 2)}
            </pre>
          ) : null}
        </div>
      ) : null}
    </div>
  );
}
