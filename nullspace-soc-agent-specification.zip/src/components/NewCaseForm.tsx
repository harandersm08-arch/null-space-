"use client";

import { useRouter } from "next/navigation";
import { useState, useTransition } from "react";

export interface ScenarioOption {
  key: string;
  label: string;
  narrative: string;
  verdict: string;
  severity: string;
}

const VERDICT_TONE: Record<string, string> = {
  benign: "text-emerald-300",
  benign_noisy: "text-emerald-300",
  suspicious: "text-amber-300",
  tamper_suspected: "text-fuchsia-300",
  indeterminate: "text-sky-300",
};

export function NewCaseForm({ scenarios, llmAvailable }: { scenarios: ScenarioOption[]; llmAvailable: boolean }) {
  const router = useRouter();
  const [pending, startTransition] = useTransition();
  const [busy, setBusy] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [useLlm, setUseLlm] = useState(false);
  const [form, setForm] = useState({
    asset: "WKSTN-9001",
    user: "jdoe",
    ruleId: "SEC-1001",
    processName: "powershell.exe",
    parentProcessName: "explorer.exe",
    commandLine: "powershell.exe -ExecutionPolicy Bypass -File .\\tools\\bootstrap.ps1",
    fileHash: "",
    severity: "medium",
    title: "Ad-hoc alert",
    description: "Analyst-submitted alert envelope.",
  });

  async function launch(body: Record<string, unknown>, key: string) {
    setBusy(key);
    setError(null);
    try {
      const response = await fetch("/api/cases", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ ...body, useLlm }),
      });
      const payload = (await response.json()) as { case_id?: string; error?: string };
      if (!response.ok || !payload.case_id) throw new Error(payload.error ?? "failed to create case");
      startTransition(() => router.push(`/cases/${payload.case_id}`));
    } catch (err) {
      setError(err instanceof Error ? err.message : String(err));
      setBusy(null);
    }
  }

  return (
    <div className="space-y-6">
      <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-3">
        {scenarios.map((scenario) => (
          <button
            key={scenario.key}
            type="button"
            disabled={busy !== null || pending}
            onClick={() => launch({ scenarioKey: scenario.key }, scenario.key)}
            className="group flex h-full flex-col gap-2 rounded-xl border border-slate-800 bg-slate-900/50 p-4 text-left transition hover:border-cyan-500/50 hover:bg-slate-900 disabled:opacity-50"
          >
            <span className="flex items-center justify-between gap-2 text-[10px] uppercase tracking-[0.16em] text-slate-500">
              <span>{scenario.severity}</span>
              <span className={VERDICT_TONE[scenario.verdict] ?? "text-slate-400"}>{scenario.verdict}</span>
            </span>
            <span className="text-sm font-medium text-slate-100 group-hover:text-white">{scenario.label}</span>
            <span className="text-xs leading-relaxed text-slate-400">{scenario.narrative}</span>
            <span className="mono mt-auto text-[10px] text-cyan-400/80">
              {busy === scenario.key ? "investigating…" : "run investigation →"}
            </span>
          </button>
        ))}
      </div>

      <form
        className="rounded-xl border border-slate-800 bg-slate-900/40 p-5"
        onSubmit={(event) => {
          event.preventDefault();
          void launch({ alert: form }, "custom");
        }}
      >
        <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
          <h3 className="text-sm font-semibold text-slate-100">Ad-hoc alert envelope</h3>
          <label className="flex items-center gap-2 text-xs text-slate-400">
            <input
              type="checkbox"
              checked={useLlm}
              onChange={(e) => setUseLlm(e.target.checked)}
              disabled={!llmAvailable}
              className="h-3.5 w-3.5 rounded border-slate-600 bg-slate-800"
            />
            generative hypothesis source (LLM){llmAvailable ? "" : " — OPENAI_API_KEY not set"}
          </label>
        </div>
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
          {(
            [
              ["asset", "Asset"],
              ["user", "Identity"],
              ["ruleId", "Rule id"],
              ["processName", "Process"],
              ["parentProcessName", "Parent process"],
              ["fileHash", "SHA-256 (optional)"],
              ["severity", "Severity"],
              ["title", "Title"],
            ] as const
          ).map(([field, label]) => (
            <label key={field} className="block text-xs text-slate-400">
              <span className="mb-1 block">{label}</span>
              <input
                value={form[field]}
                onChange={(e) => setForm((prev) => ({ ...prev, [field]: e.target.value }))}
                className="mono w-full rounded-md border border-slate-700 bg-slate-950/80 px-2.5 py-1.5 text-xs text-slate-100 outline-none focus:border-cyan-500/70"
              />
            </label>
          ))}
          <label className="block text-xs text-slate-400 sm:col-span-2 lg:col-span-4">
            <span className="mb-1 block">Command line</span>
            <input
              value={form.commandLine}
              onChange={(e) => setForm((prev) => ({ ...prev, commandLine: e.target.value }))}
              className="mono w-full rounded-md border border-slate-700 bg-slate-950/80 px-2.5 py-1.5 text-xs text-slate-100 outline-none focus:border-cyan-500/70"
            />
          </label>
        </div>
        <div className="mt-4 flex items-center gap-3">
          <button
            type="submit"
            disabled={busy !== null || pending}
            className="rounded-md bg-cyan-500/90 px-4 py-2 text-xs font-semibold text-slate-950 transition hover:bg-cyan-400 disabled:opacity-50"
          >
            {busy === "custom" ? "investigating…" : "Run investigation"}
          </button>
          <span className="text-[11px] text-slate-500">
            The mock adapter derives a deterministic telemetry world from these fields.
          </span>
        </div>
      </form>

      {error ? <p className="rounded-md border border-rose-500/40 bg-rose-500/10 px-3 py-2 text-xs text-rose-300">{error}</p> : null}
    </div>
  );
}
