import { allTemplates } from "@/lib/nullspace/templates";
import { loadEtm } from "@/lib/nullspace/etm";
import { SETTINGS } from "@/lib/nullspace/settings";
import { HYPOTHESIS_LIBRARY } from "@/lib/nullspace/hypotheses";
import { formatAssertion } from "@/lib/nullspace/util";

export default function ReferencePage() {
  const etm = loadEtm(SETTINGS.alertClass);

  return (
    <main className="mx-auto max-w-6xl px-6 py-10">
      <p className="mono text-xs uppercase tracking-[0.22em] text-cyan-400/80">Allowlisted surface</p>
      <h1 className="mt-3 text-3xl font-semibold text-slate-50">Query registry, ETM &amp; hypothesis library</h1>
      <p className="mt-3 max-w-3xl text-sm leading-relaxed text-slate-400">
        The LLM (and the analyst) can only reach the data through these templates. Parameters are schema-validated
        before execution, the adapter is read-only, and every result is wrapped as untrusted observational data — never
        as instructions.
      </p>

      <section className="mt-8 space-y-3">
        <h2 className="text-sm font-semibold uppercase tracking-[0.16em] text-slate-300">Query templates ({allTemplates().length})</h2>
        <div className="grid gap-3 lg:grid-cols-2">
          {allTemplates().map((t) => (
            <article key={t.id} className="rounded-xl border border-slate-800 bg-slate-900/40 p-4">
              <div className="flex flex-wrap items-center gap-2">
                <span className="mono text-sm text-cyan-300">{t.id}</span>
                <span className="mono rounded border border-slate-700 bg-slate-800/50 px-1.5 py-0.5 text-[10px] text-slate-400">
                  {t.capability}
                </span>
                <span className="mono ml-auto text-[10px] text-slate-500">
                  {t.typicalLatencyS}s · cost {t.cost} · {t.reproducibility}
                </span>
              </div>
              <p className="mt-2 text-xs leading-relaxed text-slate-400">{t.description}</p>
              <div className="mt-2 grid gap-1">
                {Object.entries(t.paramSpec).map(([name, spec]) => (
                  <p key={name} className="mono text-[10px] text-slate-500">
                    <span className="text-slate-300">{name}</span>: {spec.type}
                    {spec.pattern ? ` pattern ${spec.pattern}` : ""} {spec.required ? "required" : "optional"}
                  </p>
                ))}
              </div>
              <p className="mono mt-2 text-[10px] text-slate-500">
                returns {t.returns.map((r) => r.name).join(", ")}
              </p>
              <ul className="mt-2 space-y-0.5">
                {t.discriminates.map((d) => (
                  <li key={d} className="text-[11px] text-slate-500">
                    · {d}
                  </li>
                ))}
              </ul>
            </article>
          ))}
        </div>
      </section>

      <section className="mt-10 grid gap-6 lg:grid-cols-2">
        <div className="rounded-2xl border border-slate-800 bg-slate-900/40 p-5">
          <h2 className="text-sm font-semibold uppercase tracking-[0.16em] text-slate-300">
            Expected-Telemetry Model · {etm.alertClass}
          </h2>
          <div className="mt-3 space-y-2">
            {etm.requiredIfReal.map((a) => (
              <div key={a.artifact} className="rounded-lg border border-slate-800 bg-slate-950/60 p-2.5">
                <p className="mono text-[11px] text-slate-200">
                  {a.artifact} <span className="text-slate-500">{a.necessity}</span>
                </p>
                <p className="mono mt-1 text-[10px] text-slate-500">scope {a.scope} · probe {a.probeTemplateId}</p>
                {a.condition ? <p className="mono mt-1 text-[10px] text-sky-300">if {a.condition}</p> : null}
                <p className="mono mt-1 text-[10px] text-slate-500">observed when {formatAssertion(a.observedWhen)}</p>
              </div>
            ))}
          </div>
          <div className="mt-4 space-y-2">
            <p className="text-[10px] uppercase tracking-wider text-fuchsia-300">tamper signals</p>
            {etm.tamperSignals.map((s) => (
              <p key={s.pattern} className="text-[11px] leading-relaxed text-slate-400">
                <span className="mono text-fuchsia-300">{s.weight}</span> — {s.pattern}
              </p>
            ))}
          </div>
        </div>

        <div className="rounded-2xl border border-slate-800 bg-slate-900/40 p-5">
          <h2 className="text-sm font-semibold uppercase tracking-[0.16em] text-slate-300">
            Hypothesis library ({HYPOTHESIS_LIBRARY.length} curated + H0)
          </h2>
          <div className="mt-3 space-y-2">
            {HYPOTHESIS_LIBRARY.map((h) => (
              <div key={h.key} className="rounded-lg border border-slate-800 bg-slate-950/60 p-2.5">
                <p className="mono text-[11px] text-slate-200">
                  {h.key} <span className="text-slate-500">{h.hypothesisClass}</span>{" "}
                  <span className="text-slate-600">prior {h.basePrior.toFixed(2)}</span>
                </p>
                <p className="mt-1 text-[11px] leading-relaxed text-slate-400">{h.statement}</p>
                <ul className="mt-1 space-y-0.5">
                  {h.predictions.map((p) => (
                    <li key={`${h.key}-${p.queryTemplateId}`} className="mono text-[10px] text-slate-500">
                      [{p.necessity}] {p.queryTemplateId} → {formatAssertion(p.assertion)}
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="mt-10 rounded-2xl border border-slate-800 bg-slate-900/40 p-5">
        <h2 className="text-sm font-semibold uppercase tracking-[0.16em] text-slate-300">Settings</h2>
        <pre className="mono mt-3 overflow-auto rounded-lg bg-slate-950/70 p-3 text-[10px] leading-relaxed text-slate-400">
          {JSON.stringify(SETTINGS, null, 2)}
        </pre>
      </section>
    </main>
  );
}
