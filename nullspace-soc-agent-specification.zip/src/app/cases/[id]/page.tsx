import Link from "next/link";
import { notFound } from "next/navigation";
import { loadCase } from "@/lib/nullspace/repo";
import { getTemplate, allTemplates } from "@/lib/nullspace/templates";
import { shortParams } from "@/lib/nullspace/findings";
import { formatAssertion } from "@/lib/nullspace/util";
import { Bar, CoverageChip, FindingTypeBadge, InferenceChip, OutcomeChip, StatusBadge, VerdictBadge } from "@/components/badges";
import { VerifyButton } from "@/components/VerifyButton";

export const dynamic = "force-dynamic";

export default async function CasePage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const record = await loadCase(id);
  if (!record) notFound();

  const c = record.case;
  const hypotheses = [...c.hypothesesFinal].sort((a, b) => {
    if (a.status === "falsified" && b.status !== "falsified") return 1;
    if (b.status === "falsified" && a.status !== "falsified") return -1;
    return b.posterior - a.posterior;
  });
  const live = hypotheses.filter((h) => h.status === "alive");
  const alert = c.alert;

  return (
    <main className="mx-auto max-w-7xl px-6 py-8">
      <Link href="/" className="mono text-[11px] text-slate-500 hover:text-slate-300">
        ← all cases
      </Link>

      {/* Case header */}
      <section className="mt-3 rounded-2xl border border-slate-800 bg-slate-900/40 p-6">
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div>
            <p className="mono text-xs text-slate-500">{c.id}</p>
            <h1 className="mt-1 text-2xl font-semibold text-slate-50">{alert.title}</h1>
            <p className="mono mt-2 text-[11px] leading-relaxed text-slate-400">
              {alert.ruleId} · {alert.ruleName} · {alert.severity} · {alert.source} · {new Date(alert.observedAt).toISOString().slice(0, 19).replace("T", " ")}Z
            </p>
            <p className="mono mt-1 text-[11px] text-slate-400">
              asset <span className="text-slate-200">{alert.asset}</span> · identity{" "}
              <span className="text-slate-200">{alert.user}</span> · pid <span className="text-slate-200">{alert.pid}</span> · hash{" "}
              <span className="text-slate-200">{alert.fileHash.slice(0, 24)}…</span>
            </p>
            <p className="mono mt-2 max-w-3xl rounded-lg border border-slate-800 bg-slate-950/70 px-3 py-2 text-[11px] break-all text-slate-300">
              {alert.commandLine}
            </p>
          </div>
          <div className="min-w-[260px] space-y-3">
            <VerdictBadge verdict={c.verdict} confidence={c.verdictConfidence} />
            <p className="text-xs leading-relaxed text-slate-400">
              <span className="block text-[10px] uppercase tracking-wider text-slate-500">recommended action</span>
              {c.recommendedAction}
            </p>
            <div className="mono grid grid-cols-3 gap-2 text-center text-[10px] text-slate-400">
              <div className="rounded border border-slate-800 bg-slate-950/60 p-2">
                <span className="block text-sm text-slate-100">{c.budgetUsed.queries}</span>queries
              </div>
              <div className="rounded border border-slate-800 bg-slate-950/60 p-2">
                <span className="block text-sm text-slate-100">${c.budgetUsed.costUsd.toFixed(3)}</span>cost
              </div>
              <div className="rounded border border-slate-800 bg-slate-950/60 p-2">
                <span className="block text-sm text-slate-100">{c.budgetUsed.wallMs}ms</span>wall
              </div>
            </div>
            {record.verdictReason ? (
              <p className="mono text-[10px] leading-relaxed text-slate-500">reason: {record.verdictReason}</p>
            ) : null}
          </div>
        </div>
      </section>

      {c.verdict === "indeterminate" && c.decisiveQuestion ? (
        <section className="mt-4 rounded-2xl border border-sky-500/30 bg-sky-500/5 p-5">
          <h2 className="text-xs font-semibold uppercase tracking-[0.16em] text-sky-300">Decisive question for the analyst</h2>
          <p className="mt-2 text-sm leading-relaxed text-slate-200">{c.decisiveQuestion}</p>
          <p className="mono mt-2 text-[10px] text-slate-500">
            the agent stopped here rather than guessing — answer this one question and the case resolves
          </p>
        </section>
      ) : null}

      <div className="mt-6 grid gap-6 xl:grid-cols-[1.6fr_1fr]">
        <div className="space-y-6">
          {/* Kill board */}
          <section className="rounded-2xl border border-slate-800 bg-slate-900/40 p-5">
            <header className="mb-4 flex flex-wrap items-center justify-between gap-2">
              <h2 className="text-sm font-semibold uppercase tracking-[0.16em] text-slate-300">Kill board</h2>
              <p className="mono text-[11px] text-slate-500">
                {live.length} alive · {hypotheses.filter((h) => h.status === "falsified").length} falsified ·{" "}
                {hypotheses.length} hypotheses
              </p>
            </header>
            <div className="space-y-2">
              {hypotheses.map((h, index) => (
                <details
                  key={h.id}
                  open={index < 4}
                  className="group rounded-xl border border-slate-800 bg-slate-950/50 p-3 open:bg-slate-950/70"
                >
                  <summary className="flex flex-wrap items-center gap-x-3 gap-y-2">
                    <span className="chevron mono text-[10px] text-slate-500">▸</span>
                    <span className="mono text-xs text-slate-300">{h.id}</span>
                    <StatusBadge status={h.status} />
                    <span
                      className={`mono rounded border px-1.5 py-0.5 text-[10px] ${
                        h.hypothesisClass === "benign"
                          ? "border-emerald-500/30 bg-emerald-500/10 text-emerald-300"
                          : h.hypothesisClass === "malicious"
                            ? "border-rose-500/30 bg-rose-500/10 text-rose-300"
                            : "border-fuchsia-500/30 bg-fuchsia-500/10 text-fuchsia-300"
                      }`}
                    >
                      {h.hypothesisClass}
                    </span>
                    <span className="mono text-[10px] text-slate-500">{h.source}</span>
                    <span className="ml-auto flex w-40 items-center gap-2">
                      <span className="mono text-[10px] text-slate-500">prior {(h.prior * 100).toFixed(0)}%</span>
                      <Bar value={h.posterior} tone={h.status === "falsified" ? "rose" : h.hypothesisClass === "benign" ? "emerald" : "cyan"} />
                      <span className="mono text-[10px] text-slate-300">{(h.posterior * 100).toFixed(0)}%</span>
                    </span>
                  </summary>
                  <p className="mt-2 pl-6 text-xs leading-relaxed text-slate-300">{h.statement}</p>
                  {h.falsifiedBy.length > 0 ? (
                    <p className="mono mt-1 pl-6 text-[10px] text-rose-400">killed by {h.falsifiedBy.join(", ")}</p>
                  ) : null}
                  <div className="mt-3 space-y-1.5 pl-6">
                    {h.predictions.map((p, i) => (
                      <div key={`${h.id}-${i}`} className="rounded-lg border border-slate-800/80 bg-slate-900/40 p-2">
                        <div className="flex flex-wrap items-center gap-2">
                          <OutcomeChip outcome={p.outcome ?? null} />
                          <span
                            className={`mono rounded border px-1.5 py-0.5 text-[10px] ${
                              p.necessity === "hard"
                                ? "border-rose-500/30 bg-rose-500/10 text-rose-300"
                                : p.necessity === "soft"
                                  ? "border-slate-600 bg-slate-800/60 text-slate-300"
                                  : "border-sky-500/30 bg-sky-500/10 text-sky-300"
                            }`}
                          >
                            {p.necessity}
                          </span>
                          <span className="mono text-[11px] text-cyan-300">{p.queryTemplateId}</span>
                          <span className="mono text-[10px] text-slate-500">{shortParams(p.params)}</span>
                          {p.evidenceFindingId ? (
                            <span className="mono text-[10px] text-slate-400">→ {p.evidenceFindingId}</span>
                          ) : null}
                        </div>
                        <p className="mt-1 text-[11px] leading-relaxed text-slate-400">{p.ifTrue}</p>
                        <p className="mono mt-1 text-[10px] text-slate-500">assert {formatAssertion(p.assertion)}</p>
                      </div>
                    ))}
                  </div>
                </details>
              ))}
            </div>
          </section>

          {/* Findings */}
          <section className="rounded-2xl border border-slate-800 bg-slate-900/40 p-5">
            <header className="mb-4 flex flex-wrap items-center justify-between gap-2">
              <h2 className="text-sm font-semibold uppercase tracking-[0.16em] text-slate-300">Findings</h2>
              <p className="mono text-[11px] text-slate-500">executable queries · sha256 result hashes</p>
            </header>
            <div className="space-y-3">
              {c.findings.map((f) => (
                <article key={f.id} className="rounded-xl border border-slate-800 bg-slate-950/50 p-3">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="mono text-xs text-slate-200">{f.id}</span>
                    <FindingTypeBadge type={f.type} />
                    <CoverageChip status={f.coverageAtExecution} />
                    <span className="mono text-[11px] text-cyan-300">{f.queryTemplateId}</span>
                    <span className="mono text-[10px] text-slate-500">{shortParams(f.params)}</span>
                    <span className="mono ml-auto text-[10px] text-slate-600">{new Date(f.executedAt).toISOString().slice(11, 19)}Z</span>
                  </div>
                  <p className="mt-2 text-xs leading-relaxed text-slate-300">{f.claim}</p>
                  <p className="mono mt-1 text-[10px] text-slate-500">{f.summary}</p>
                  <p className="mono mt-1 truncate text-[10px] text-slate-600" title={f.resultHash}>
                    sha256 {f.resultHash}
                  </p>
                  <p className="mono mt-1 text-[10px] text-slate-600">snapshot {f.resultSnapshotUri}</p>
                  {f.hypothesisImpact.length > 0 ? (
                    <p className="mono mt-1 text-[10px] text-slate-500">impacts {f.hypothesisImpact.join(", ")}</p>
                  ) : null}
                  <VerifyButton findingId={f.id} reproducibility={f.reproducibility} />
                </article>
              ))}
            </div>
          </section>

          {/* Query trace */}
          <section className="rounded-2xl border border-slate-800 bg-slate-900/40 p-5">
            <h2 className="mb-4 text-sm font-semibold uppercase tracking-[0.16em] text-slate-300">Query trace</h2>
            <ol className="space-y-2">
              {c.queryTrace.map((t) => (
                <li key={t.step} className="rounded-xl border border-slate-800 bg-slate-950/50 p-3">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="mono grid h-5 w-5 place-items-center rounded bg-slate-800 text-[10px] text-slate-300">{t.step}</span>
                    <span className="mono text-[11px] text-cyan-300">{t.queryTemplateId}</span>
                    <span className="mono text-[10px] text-slate-500">{shortParams(t.params)}</span>
                    <span className="mono ml-auto text-[10px] text-slate-400">IG {t.igScore.toFixed(3)}</span>
                    <span className="mono text-[10px] text-slate-600">{t.latencyMs}ms</span>
                    <span className="mono text-[10px] text-slate-600">→ {t.resultFindingId}</span>
                  </div>
                  <p className="mono mt-1.5 text-[10px] leading-relaxed text-slate-500">{t.rationale}</p>
                </li>
              ))}
            </ol>
          </section>
        </div>

        {/* Right rail */}
        <div className="space-y-6">
          <section className="rounded-2xl border border-slate-800 bg-slate-900/40 p-5">
            <header className="mb-3 flex items-center justify-between gap-2">
              <h2 className="text-sm font-semibold uppercase tracking-[0.16em] text-slate-300">Negative space</h2>
              <span
                className={`mono rounded border px-2 py-0.5 text-[10px] uppercase ${
                  c.negativeSpace.overall === "anomaly"
                    ? "border-fuchsia-500/40 bg-fuchsia-500/10 text-fuchsia-300"
                    : c.negativeSpace.overall === "gap"
                      ? "border-amber-500/40 bg-amber-500/10 text-amber-300"
                      : "border-emerald-500/40 bg-emerald-500/10 text-emerald-300"
                }`}
              >
                {c.negativeSpace.overall}
              </span>
            </header>
            <p className="mb-3 text-[11px] leading-relaxed text-slate-500">
              If this alert were real, this telemetry must exist. Uncovered sensors are scored as unknown, not as
              &ldquo;nothing found&rdquo;.
            </p>
            <div className="space-y-2">
              {c.negativeSpace.artifacts.map((a) => (
                <div key={a.artifact} className="rounded-lg border border-slate-800 bg-slate-950/50 p-2.5">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="mono text-[11px] text-slate-200">{a.artifact}</span>
                    <span className="mono text-[10px] text-slate-500">{a.necessity}</span>
                    <span className="ml-auto flex items-center gap-1.5">
                      <CoverageChip status={a.covered} />
                      <InferenceChip inference={a.inference} />
                    </span>
                  </div>
                  <p className="mono mt-1 text-[10px] leading-relaxed text-slate-500">{a.detail}</p>
                  <p className="mono mt-1 text-[10px] text-slate-600">scope in ETM · {a.observed ? "observed" : "not observed"}</p>
                </div>
              ))}
            </div>
            {c.negativeSpace.tamperSignals.length > 0 ? (
              <div className="mt-3 space-y-2">
                <p className="text-[10px] uppercase tracking-wider text-fuchsia-300">tamper signals</p>
                {c.negativeSpace.tamperSignals.map((s) => (
                  <div key={s.pattern} className="rounded-lg border border-fuchsia-500/30 bg-fuchsia-500/5 p-2.5">
                    <p className="text-[11px] leading-relaxed text-fuchsia-200">{s.pattern}</p>
                    <p className="mono mt-1 text-[10px] text-slate-400">{s.detail}</p>
                    <p className="mono mt-1 text-[10px] text-slate-500">weight {s.weight}</p>
                  </div>
                ))}
              </div>
            ) : null}
          </section>

          <section className="rounded-2xl border border-slate-800 bg-slate-900/40 p-5">
            <h2 className="mb-3 text-sm font-semibold uppercase tracking-[0.16em] text-slate-300">Initial ledger</h2>
            <div className="space-y-1.5">
              {c.hypothesesInitial.map((h) => (
                <div key={h.id} className="flex items-center gap-2 text-[11px]">
                  <span className="mono text-slate-500">{h.id}</span>
                  <span className="truncate text-slate-400">{h.statement}</span>
                  <span className="mono ml-auto text-slate-600">p={(h.prior * 100).toFixed(0)}%</span>
                </div>
              ))}
            </div>
          </section>

          <section className="rounded-2xl border border-slate-800 bg-slate-900/40 p-5">
            <h2 className="mb-3 text-sm font-semibold uppercase tracking-[0.16em] text-slate-300">Engine trace</h2>
            <p className="mono mb-2 text-[10px] text-slate-500">
              {record.events.length} spans · {record.llmUsed ? "LLM hypothesis source active" : "deterministic hypothesis sources"}
            </p>
            <details className="rounded-lg border border-slate-800 bg-slate-950/50">
              <summary className="mono px-2.5 py-2 text-[11px] text-cyan-300">open span log</summary>
              <ol className="max-h-96 space-y-1 overflow-auto p-2.5">
                {record.events.map((e, i) => (
                  <li key={i} className="mono text-[10px] leading-relaxed text-slate-500">
                    <span className="text-slate-400">{e.ts.slice(11, 23)}</span>{" "}
                    <span className="text-cyan-400/80">{e.kind}</span> <span className="text-slate-300">{e.name}</span>{" "}
                    {Object.entries(e.attrs)
                      .slice(0, 4)
                      .map(([k, v]) => `${k}=${typeof v === "object" ? "…" : String(v).slice(0, 40)}`)
                      .join(" ")}
                  </li>
                ))}
              </ol>
            </details>
          </section>

          <section className="rounded-2xl border border-slate-800 bg-slate-900/40 p-5">
            <h2 className="mb-3 text-sm font-semibold uppercase tracking-[0.16em] text-slate-300">Templates used</h2>
            <div className="space-y-1.5">
              {allTemplates()
                .filter((t) => c.queryTrace.some((step) => step.queryTemplateId === t.id))
                .map((t) => (
                  <div key={t.id} className="rounded-lg border border-slate-800 bg-slate-950/50 p-2.5">
                    <p className="mono text-[11px] text-cyan-300">{t.id}</p>
                    <p className="mt-1 text-[11px] leading-relaxed text-slate-400">{t.description}</p>
                    <p className="mono mt-1 text-[10px] text-slate-600">
                      {t.capability} · {t.reproducibility} · {t.typicalLatencyS}s · cost {t.cost}
                    </p>
                  </div>
                ))}
              <p className="mono text-[10px] text-slate-600">
                {getTemplate(c.queryTrace[0]?.queryTemplateId ?? "asset_context")?.capability ?? "read-only"} adapter ·
                SELECT/READ only
              </p>
            </div>
          </section>
        </div>
      </div>
    </main>
  );
}
