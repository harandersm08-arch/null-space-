import Link from "next/link";
import { listCases } from "@/lib/nullspace/repo";
import { SCENARIOS } from "@/lib/nullspace/world";
import { SETTINGS } from "@/lib/nullspace/settings";
import { NewCaseForm } from "@/components/NewCaseForm";
import { VerdictBadge } from "@/components/badges";

export const dynamic = "force-dynamic";

const INVARIANTS = [
  "The agent asks “can I prove this alert benign?”, not “is this malicious?”",
  "Every hypothesis carries ≥1 falsifiable prediction bound to an allowlisted query template.",
  "Missing evidence is scored: evidence-of-absence, unknown (blind sensor) or anomaly (tamper).",
  "Every finding is an executable query + sha256 result hash — re-runnable in one click.",
  "The LLM never writes queries: it selects templates and fills schema-validated params.",
  "All tool calls are read-only; containment needs a human approval path.",
];

export default async function HomePage() {
  const cases = await listCases(12);
  const llmAvailable = Boolean(process.env.OPENAI_API_KEY);
  const verdictCounts = cases.reduce<Record<string, number>>((acc, c) => {
    acc[c.verdict] = (acc[c.verdict] ?? 0) + 1;
    return acc;
  }, {});
  const avgQueries = cases.length ? cases.reduce((s, c) => s + c.queryCount, 0) / cases.length : 0;

  return (
    <main className="mx-auto max-w-7xl px-6 py-10">
      <section className="mb-10 grid gap-8 lg:grid-cols-[1.35fr_1fr]">
        <div>
          <p className="mono text-xs uppercase tracking-[0.22em] text-cyan-400/80">NullSpace · Phase 3</p>
          <h1 className="mt-3 text-4xl font-semibold leading-tight text-slate-50 sm:text-5xl">
            The agent that tries to <span className="text-cyan-300">kill the alert</span> before it escalates it.
          </h1>
          <p className="mt-4 max-w-2xl text-sm leading-relaxed text-slate-400">
            NullSpace is a falsification-first autonomous SOC investigator. It generates benign and malicious
            hypotheses, selects the query with the highest expected information gain, kills hypotheses with hard
            evidence, and scores the telemetry that <em>should</em> have existed but did not. Budget:{" "}
            <span className="mono text-slate-300">
              ≤{SETTINGS.budget.maxQueries} queries / {SETTINGS.budget.maxWallMs}ms / ${SETTINGS.budget.maxCostUsd}
            </span>
            .
          </p>
          <div className="mt-6 grid gap-2 sm:grid-cols-2">
            {INVARIANTS.map((line) => (
              <p key={line} className="flex gap-2 rounded-lg border border-slate-800/80 bg-slate-900/40 px-3 py-2 text-xs leading-relaxed text-slate-400">
                <span className="text-cyan-400/70">▸</span>
                {line}
              </p>
            ))}
          </div>
        </div>
        <div className="rounded-2xl border border-slate-800 bg-slate-900/40 p-5">
          <h2 className="text-sm font-semibold text-slate-100">Fleet state</h2>
          <dl className="mt-4 grid grid-cols-2 gap-3 text-sm">
            <div className="rounded-lg border border-slate-800 bg-slate-950/60 p-3">
              <dt className="text-[11px] uppercase tracking-wider text-slate-500">cases</dt>
              <dd className="mono mt-1 text-xl text-slate-100">{cases.length}</dd>
            </div>
            <div className="rounded-lg border border-slate-800 bg-slate-950/60 p-3">
              <dt className="text-[11px] uppercase tracking-wider text-slate-500">avg queries</dt>
              <dd className="mono mt-1 text-xl text-slate-100">{avgQueries.toFixed(1)}</dd>
            </div>
          </dl>
          <div className="mt-4 space-y-2">
            {Object.entries(verdictCounts).length === 0 ? (
              <p className="text-xs text-slate-500">No cases yet — run a golden scenario below.</p>
            ) : (
              Object.entries(verdictCounts)
                .sort((a, b) => b[1] - a[1])
                .map(([verdict, count]) => (
                  <div key={verdict} className="flex items-center justify-between gap-3 text-xs">
                    <VerdictBadge verdict={verdict} />
                    <span className="mono text-slate-400">{count}</span>
                  </div>
                ))
            )}
          </div>
          <Link
            href="/evaluate"
            className="mt-5 block rounded-lg border border-cyan-500/30 bg-cyan-500/10 px-3 py-2 text-center text-xs font-medium text-cyan-200 transition hover:bg-cyan-500/20"
          >
            Run the golden-case evaluation →
          </Link>
        </div>
      </section>

      <section className="mb-12">
        <h2 className="mb-4 text-sm font-semibold uppercase tracking-[0.16em] text-slate-400">New investigation</h2>
        <NewCaseForm
          llmAvailable={llmAvailable}
          scenarios={SCENARIOS.map((s) => ({
            key: s.key,
            label: s.label,
            narrative: s.narrative,
            verdict: s.verdict,
            severity: s.expected,
          }))}
        />
      </section>

      <section>
        <h2 className="mb-4 text-sm font-semibold uppercase tracking-[0.16em] text-slate-400">Recent cases</h2>
        {cases.length === 0 ? (
          <p className="rounded-xl border border-slate-800 bg-slate-900/40 px-4 py-6 text-sm text-slate-500">
            Nothing investigated yet.
          </p>
        ) : (
          <div className="overflow-hidden rounded-xl border border-slate-800">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-900/70 text-[10px] uppercase tracking-wider text-slate-500">
                <tr>
                  <th className="px-4 py-2.5">case</th>
                  <th className="px-4 py-2.5">alert</th>
                  <th className="px-4 py-2.5">asset / identity</th>
                  <th className="px-4 py-2.5">verdict</th>
                  <th className="px-4 py-2.5">queries</th>
                  <th className="px-4 py-2.5">negative space</th>
                  <th className="px-4 py-2.5">created</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/70 bg-slate-950/40">
                {cases.map((c) => (
                  <tr key={c.id} className="transition hover:bg-slate-900/60">
                    <td className="px-4 py-2.5">
                      <Link href={`/cases/${c.id}`} className="mono text-cyan-300 hover:underline">
                        {c.id}
                      </Link>
                    </td>
                    <td className="mono px-4 py-2.5 text-slate-400">
                      {c.ruleId} · {c.asset}
                    </td>
                    <td className="mono px-4 py-2.5 text-slate-400">{c.user}</td>
                    <td className="px-4 py-2.5">
                      <VerdictBadge verdict={c.verdict} />
                    </td>
                    <td className="mono px-4 py-2.5 text-slate-300">{c.queryCount}</td>
                    <td className="mono px-4 py-2.5 text-slate-400">{c.negativeSpace?.overall ?? "—"}</td>
                    <td className="mono px-4 py-2.5 text-slate-500">{new Date(c.createdAt).toISOString().slice(0, 19).replace("T", " ")}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </section>
    </main>
  );
}
