import { latestEvaluations, saveEvaluation } from "@/lib/nullspace/repo";
import { runGoldenEvaluation } from "@/lib/nullspace/evaluate";

export const dynamic = "force-dynamic";
export const maxDuration = 60;

/** GET /api/evaluate — most recent evaluation runs. */
export async function GET() {
  const runs = await latestEvaluations(5);
  return Response.json({ runs });
}

/** POST /api/evaluate — replay the golden set and store the report. */
export async function POST(request: Request) {
  let body: Record<string, unknown> = {};
  try {
    body = (await request.json()) as Record<string, unknown>;
  } catch {
    body = {};
  }
  const useLlm = body.useLlm === true && Boolean(process.env.OPENAI_API_KEY);
  const report = await runGoldenEvaluation({ useLlm });
  const id = await saveEvaluation({
    total: report.total,
    correct: report.correct,
    sycophancyRate: report.sycophancyRate,
    averageQueries: report.averageQueries,
    benignSurvival: report.benignSurvivalRate,
    results: report.results as unknown as Record<string, unknown>[],
  });
  return Response.json({ evaluation_id: id, ...report });
}
