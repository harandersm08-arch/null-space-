import { CoverageMap } from "@/lib/nullspace/coverage";
import { worldForAsset } from "@/lib/nullspace/world";
import type { TelemetrySource } from "@/lib/nullspace/types";

export const dynamic = "force-dynamic";

/** GET /api/coverage/{asset}/{source}/{start}/{end} */
export async function GET(
  _request: Request,
  { params }: { params: Promise<{ asset: string; source: string; start: string; end: string }> },
) {
  const { asset, source, start, end } = await params;
  const world = worldForAsset(decodeURIComponent(asset));
  const map = new CoverageMap(world);
  const interval: [Date, Date] = [new Date(start), new Date(end)];
  const answer = source.startsWith("idp")
    ? map.coverageForUser(source as TelemetrySource, asset)
    : map.coverage(decodeURIComponent(source) as TelemetrySource, decodeURIComponent(asset), interval);
  return Response.json({
    asset: decodeURIComponent(asset),
    source: decodeURIComponent(source),
    interval: { start, end },
    status: answer.status,
    detail: answer.detail,
    coverage_pct: answer.coveragePct,
  });
}
