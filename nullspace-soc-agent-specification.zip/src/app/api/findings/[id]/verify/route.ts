import { verifyFindingById } from "@/lib/nullspace/repo";

export const dynamic = "force-dynamic";

/**
 * POST /api/findings/{id}/verify — re-execute the finding and diff.
 * Body: { mode: "replay" | "drift" } (default replay)
 */
export async function POST(request: Request, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  let body: Record<string, unknown> = {};
  try {
    body = (await request.json()) as Record<string, unknown>;
  } catch {
    body = {};
  }
  const mode = body.mode === "drift" ? "drift" : "replay";
  const result = await verifyFindingById(id, mode);
  if (!result) return Response.json({ error: "finding not found" }, { status: 404 });
  return Response.json(result);
}
