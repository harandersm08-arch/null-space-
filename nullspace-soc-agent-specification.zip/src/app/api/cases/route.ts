import { investigateAndPersist, listCases } from "@/lib/nullspace/repo";
import { scenarioByKey } from "@/lib/nullspace/world";

export const dynamic = "force-dynamic";

/**
 * POST /api/cases — create a case and run the investigation loop.
 * Body: { scenarioKey } OR { alert: { ...normalized alert fields } }
 */
export async function POST(request: Request) {
  let body: Record<string, unknown> = {};
  try {
    body = (await request.json()) as Record<string, unknown>;
  } catch {
    body = {};
  }

  const scenarioKey = typeof body.scenarioKey === "string" ? body.scenarioKey : null;
  const useLlm = body.useLlm === true && Boolean(process.env.OPENAI_API_KEY);
  let alertInput: Record<string, unknown>;
  let label: string | null = null;

  if (scenarioKey) {
    const scenario = scenarioByKey(scenarioKey);
    if (!scenario) {
      return Response.json({ error: `unknown scenario: ${scenarioKey}` }, { status: 400 });
    }
    const paraphrase = body.paraphrase === true;
    alertInput = {
      ...scenario.alert,
      worldKey: scenario.key,
      scenarioKey: scenario.key,
      ...(paraphrase ? { title: scenario.paraphrase.title, description: scenario.paraphrase.description } : {}),
    };
    label = scenario.verdict;
  } else if (body.alert && typeof body.alert === "object") {
    alertInput = { ...(body.alert as Record<string, unknown>), worldKey: "synthetic" };
  } else {
    return Response.json({ error: "body must contain scenarioKey or alert" }, { status: 400 });
  }

  const result = await investigateAndPersist(alertInput, { label, useLlm });
  return Response.json(
    {
      case_id: result.caseId,
      status: "complete",
      verdict: result.case.verdict,
      verdict_confidence: result.case.verdictConfidence,
      queries: result.case.queryTrace.length,
      decisive_question: result.case.decisiveQuestion,
    },
    { status: 201 },
  );
}

/** GET /api/cases — recent cases (lightweight summaries). */
export async function GET() {
  const rows = await listCases(25);
  return Response.json({ cases: rows });
}
