import { loadCase } from "@/lib/nullspace/repo";

export const dynamic = "force-dynamic";

/** GET /api/cases/{id} — the full Case object (hypotheses, findings, verdict, trace). */
export async function GET(_request: Request, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const record = await loadCase(id);
  if (!record) return Response.json({ error: "case not found" }, { status: 404 });
  return Response.json({
    case: record.case,
    verdict_reason: record.verdictReason,
    llm_used: record.llmUsed,
    created_at: record.createdAt,
    trace_events: record.events,
  });
}
