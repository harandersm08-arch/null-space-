import { loadCase } from "@/lib/nullspace/repo";

export const dynamic = "force-dynamic";

/** GET /api/cases/{id}/trace — the query trace that feeds the kill board. */
export async function GET(_request: Request, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const record = await loadCase(id);
  if (!record) return Response.json({ error: "case not found" }, { status: 404 });
  return Response.json({ case_id: id, query_trace: record.case.queryTrace, findings: record.case.findings });
}
