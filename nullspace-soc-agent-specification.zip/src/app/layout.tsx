import type { Metadata } from "next";
import type { ReactNode } from "react";
import Link from "next/link";
import "./globals.css";

export const metadata: Metadata = {
  title: "NullSpace — falsification-first SOC investigator",
  description:
    "Autonomous SOC investigation agent that tries to prove alerts benign, scores missing evidence, and makes every finding re-executable.",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body className="min-h-screen bg-[#05070d] text-slate-200 antialiased">
        <header className="border-b border-slate-800/80 bg-slate-950/60 backdrop-blur">
          <div className="mx-auto flex max-w-7xl flex-wrap items-center gap-x-8 gap-y-3 px-6 py-4">
            <Link href="/" className="group flex items-center gap-3">
              <span className="grid h-9 w-9 place-items-center rounded-lg border border-cyan-500/40 bg-cyan-500/10 text-cyan-300 mono text-sm font-semibold">
                ∅
              </span>
              <span>
                <span className="block text-base font-semibold tracking-tight text-slate-50">NullSpace</span>
                <span className="block text-[11px] uppercase tracking-[0.18em] text-slate-500">
                  falsification-first investigator
                </span>
              </span>
            </Link>
            <nav className="flex items-center gap-1 text-sm">
              <Link
                href="/"
                className="rounded-md px-3 py-1.5 text-slate-400 transition hover:bg-slate-800/60 hover:text-slate-100"
              >
                Cases
              </Link>
              <Link
                href="/evaluate"
                className="rounded-md px-3 py-1.5 text-slate-400 transition hover:bg-slate-800/60 hover:text-slate-100"
              >
                Evaluation
              </Link>
              <Link
                href="/reference"
                className="rounded-md px-3 py-1.5 text-slate-400 transition hover:bg-slate-800/60 hover:text-slate-100"
              >
                Registry &amp; ETM
              </Link>
            </nav>
            <div className="ml-auto hidden items-center gap-2 text-[11px] text-slate-500 lg:flex">
              <span className="inline-flex h-2 w-2 rounded-full bg-emerald-400/80" />
              read-only adapters · template registry · OPA budget gate
            </div>
          </div>
        </header>
        {children}
        <footer className="mx-auto max-w-7xl px-6 py-10 text-xs text-slate-600">
          Every finding is an executable query + sha256 result hash. Actions (isolate, block, disable) are outside the
          autonomous path and require human approval.
        </footer>
      </body>
    </html>
  );
}
