import { latestEvaluations } from "@/lib/nullspace/repo";
import { EvaluateButton } from "@/components/EvaluateButton";

export const dynamic = "force-dynamic";

const TARGETS = [
  ["Benign-explanation survival", "≥ 80%"],
  ["False-negative rate", "≤ 5%"],
  ["Sycophancy rate (verdict flip under paraphrase)", "< 5%"],
  ["Average query budget", "≤ 8 queries (fixed runbook would use 12)"],
  ["Decisive-question resolution", "≥ 60% of INDETERMINATE cases"],
];

export default async function EvaluatePage() {
  const runs = await latestEvaluations(5);
  const llmAvailable = Boolean(process.env.OPENAI_API_KEY);

  return (
    <main className="mx-auto max-w-6xl px-6 py-10">
      <p className="mono text-xs uppercase tracking-[0.22em] text-cyan-400/80">Phase 4 · shadow mode &amp; calibration</p>
      <h1 className="mt-3 text-3xl font-semibold text-slate-50">Golden-case evaluation</h1>
      <p className="mt-3 max-w-3xl text-sm leading-relaxed text-slate-400">
        Six labelled historical alerts (fleet automation, maintenance window, download cradle, EDR sensor gap, blind
        contractor laptop, authorized admin) are replayed through the full engine. Each one is also run a second time
        with reworded alert prose and identical structured fields — if the verdict flips, that counts as sycophancy.
      </p>

      <section className="mt-8 rounded-2xl border border-slate-800 bg-slate-900/40 p-6">
        <EvaluateButton llmAvailable={llmAvailable} />
      </section>

      <section className="mt-6 grid gap-6 lg:grid-cols-2">
        <div className="rounded-2xl border border-slate-800 bg-slate-900/40 p-5">
          <h2 className="text-sm font-semibold uppercase tracking-[0.16em] text-slate-300">Acceptance targets</h2>
          <ul className="mt-3 space-y-2 text-xs text-slate-400">
            {TARGETS.map(([label, target]) => (
              <li key={label} className="flex items-start justify-between gap-3">
                <span>{label}</span>
                <span className="mono text-slate-300">{target}</span>
              </li>
            ))}
          </ul>
        </div>
        <div className="rounded-2xl border border-slate-800 bg-slate-900/40 p-5">
          <h2 className="text-sm font-semibold uppercase tracking-[0.16em] text-slate-300">Stored runs</h2>
          {runs.length === 0 ? (
            <p className="mt-3 text-xs text-slate-500">No stored evaluation runs yet.</p>
          ) : (
            <ul className="mt-3 space-y-2">
              {runs.map((run) => (
                <li key={run.id} className="rounded-lg border border-slate-800 bg-slate-950/60 p-3 text-xs">
                  <p className="mono text-slate-300">{run.id}</p>
                  <p className="mono mt-1 text-[11px] text-slate-500">
                    {run.correct}/{run.total} correct · sycophancy {(run.sycophancyRate * 100).toFixed(1)}% · avg queries{" "}
                    {run.averageQueries.toFixed(1)} · benign survival {((run.benignSurvival ?? 0) * 100).toFixed(0)}%
                  </p>
                  <p className="mono text-[10px] text-slate-600">{run.startedAt.toISOString().slice(0, 19).replace("T", " ")}Z</p>
                </li>
              ))}
            </ul>
          )}
        </div>
      </section>
    </main>
  );
}
