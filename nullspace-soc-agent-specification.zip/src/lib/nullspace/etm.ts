import type { AlertEnvelope, EtmArtifact, TamperSignal } from "./types";
import { getField } from "./util";

/**
 * Expected-Telemetry Model (§6). If the alert were real, this telemetry must
 * exist. Missing evidence is scored, never ignored (invariant 3).
 */

export interface Etm {
  alertClass: string;
  requiredIfReal: EtmArtifact[];
  tamperSignals: TamperSignal[];
}

function dataOf(byTemplate: Record<string, { result: Record<string, unknown> }>, templateId: string): Record<string, unknown> | null {
  const entry = byTemplate[templateId];
  return entry ? entry.result : null;
}

export const SUSPICIOUS_POWERSHELL_ETM: Etm = {
  alertClass: "process_execution.suspicious_powershell",
  requiredIfReal: [
    {
      artifact: "edr.process_event",
      scope: "host, t±5m",
      necessity: "hard",
      probeTemplateId: "edr_process_tree",
      probeParamsFrom: "asset",
      observedWhen: { field: "found", op: "is_true" },
    },
    {
      artifact: "edr.image_load",
      scope: "host, t",
      necessity: "hard",
      probeTemplateId: "edr_process_tree",
      probeParamsFrom: "asset",
      observedWhen: { field: "module_load_count", op: "gte", value: 1 },
    },
    {
      artifact: "edr.heartbeat",
      scope: "host, t±10m",
      necessity: "hard",
      probeTemplateId: "edr_heartbeat_check",
      probeParamsFrom: "asset",
      observedWhen: { field: "coverage_pct", op: "gte", value: 0.9 },
    },
    {
      artifact: "idp.logon",
      scope: "user, t−24h",
      necessity: "soft",
      probeTemplateId: "idp_signin_lookup",
      probeParamsFrom: "user",
      observedWhen: { field: "event_count", op: "gte", value: 1 },
    },
    {
      artifact: "dns.resolution",
      scope: "host, t±5m",
      necessity: "conditional",
      condition: "decoded_cmdline contains network patterns (IEX, WebClient, DownloadString, Invoke-WebRequest)",
      probeTemplateId: "dns_resolution_lookup",
      probeParamsFrom: "asset",
      observedWhen: { field: "resolution_count", op: "gte", value: 1 },
    },
  ],
  tamperSignals: [
    {
      pattern: "heartbeat present before AND after event, gap covering t_event",
      weight: "high",
      detect: ({ byTemplate }) => {
        const hb = dataOf(byTemplate, "edr_heartbeat_check");
        if (!hb) return null;
        const gap = getField(hb, "gap_covering_event");
        const status = getField(hb, "agent_status");
        if (gap === true && status === "online") {
          return `agent online before/after, coverage ${(Number(getField(hb, "coverage_pct")) * 100).toFixed(0)}% of cadence, ${getField(hb, "gap_minutes")}m gap straddling t_event`;
        }
        return null;
      },
    },
    {
      pattern: "process corroborated by ≥2 sources, edr.process_event absent, coverage confirmed",
      weight: "critical",
      detect: ({ byTemplate, artifacts, alert }) => {
        const proc = artifacts.find((a) => a.artifact === "edr.process_event");
        if (!proc || proc.observed || proc.covered !== "covered") return null;
        const tree = dataOf(byTemplate, "edr_process_tree");
        const sources = Array.isArray(getField(tree, "correlated_sources")) ? (getField(tree, "correlated_sources") as string[]) : [];
        const corroborators = new Set<string>([...sources, alert.source]);
        corroborators.delete("edr");
        if (corroborators.size >= 1) {
          return `execution corroborated by ${[...corroborators].join(", ")} while EDR process telemetry is absent and the agent reports covered`;
        }
        return null;
      },
    },
    {
      pattern: "idp.logon present, edr.process_event absent, coverage confirmed",
      weight: "high",
      detect: ({ byTemplate, artifacts }) => {
        const proc = artifacts.find((a) => a.artifact === "edr.process_event");
        const idp = artifacts.find((a) => a.artifact === "idp.logon");
        if (!proc || !idp) return null;
        if (!proc.observed && proc.covered === "covered" && idp.observed) {
          const events = dataOf(byTemplate, "idp_signin_lookup");
          return `identity is active (${getField(events, "event_count")} IdP events) but the EDR saw no process for it`;
        }
        return null;
      },
    },
  ],
};

const ETMS: Record<string, Etm> = {
  "process_execution.suspicious_powershell": SUSPICIOUS_POWERSHELL_ETM,
};

export function loadEtm(alertClass: string): Etm {
  return ETMS[alertClass] ?? SUSPICIOUS_POWERSHELL_ETM;
}

/**
 * Typed context facts derived from structured alert fields. These are rules,
 * not LLM output, so paraphrasing alert prose can never change them.
 */
export interface ContextFacts {
  cmdlineHasNetworkPattern: boolean;
  executingUserIsServiceAccount: boolean;
  assetIsServer: boolean;
}

export function contextFacts(alert: AlertEnvelope): ContextFacts {
  const pattern = /(IEX|Invoke-Expression|DownloadString|DownloadData|Invoke-WebRequest|WebClient|Net\.WebClient|Start-BitsTransfer|http:|https:)/i;
  return {
    cmdlineHasNetworkPattern: pattern.test(alert.commandLine ?? ""),
    executingUserIsServiceAccount: /^(svc-|sa_|.*_svc|.*service)$/i.test(alert.user ?? ""),
    assetIsServer: /^(srv|server|db|app)-/i.test(alert.asset ?? ""),
  };
}

/** Conditional necessity only binds when its typed condition is met. */
export function conditionMet(artifact: EtmArtifact, facts: ContextFacts): boolean {
  if (artifact.necessity !== "conditional") return true;
  if (artifact.artifact === "dns.resolution") return facts.cmdlineHasNetworkPattern;
  return true;
}
