import { createHash } from "node:crypto";
import type { Assertion } from "./types";

/** Canonical JSON: sorted keys, no insignificant whitespace. */
export function canonicalJson(value: unknown): string {
  return JSON.stringify(sortValue(value));
}

function sortValue(value: unknown): unknown {
  if (Array.isArray(value)) return value.map(sortValue);
  if (value && typeof value === "object") {
    const src = value as Record<string, unknown>;
    const out: Record<string, unknown> = {};
    for (const key of Object.keys(src).sort()) out[key] = sortValue(src[key]);
    return out;
  }
  return value;
}

export function sha256(value: string): string {
  return createHash("sha256").update(value).digest("hex");
}

export function resultHash(templateId: string, params: Record<string, unknown>, data: unknown): string {
  return sha256(canonicalJson({ templateId, params, data }));
}

/** Typed field access into a nested record. Returns undefined when missing. */
export function getField(data: unknown, path: string): unknown {
  return path
    .split(".")
    .reduce<unknown>((acc, part) => {
      if (acc === null || acc === undefined) return undefined;
      if (typeof acc !== "object") return undefined;
      return (acc as Record<string, unknown>)[part];
    }, data);
}

function isBlank(value: unknown): boolean {
  if (value === null || value === undefined) return true;
  if (typeof value === "string") return value.trim() === "";
  if (Array.isArray(value)) return value.length === 0;
  if (typeof value === "object") return Object.keys(value as object).length === 0;
  return false;
}

function num(value: unknown): number | null {
  if (typeof value === "number" && Number.isFinite(value)) return value;
  if (typeof value === "string" && value.trim() !== "" && Number.isFinite(Number(value))) return Number(value);
  return null;
}

/** Deterministic, typed assertion evaluation. No free-text matching. */
export function evaluateAssertion(assertion: Assertion, data: Record<string, unknown>): boolean {
  const actual = getField(data, assertion.field);
  const expected = assertion.value;
  switch (assertion.op) {
    case "exists":
      return actual !== undefined && actual !== null;
    case "not_exists":
      return actual === undefined || actual === null;
    case "is_empty":
      return isBlank(actual);
    case "not_empty":
      return !isBlank(actual);
    case "is_true":
      return actual === true;
    case "is_false":
      return actual === false;
    case "eq":
      return actual === expected;
    case "ne":
      return actual !== expected;
    case "gt": {
      const a = num(actual);
      const b = num(expected);
      return a !== null && b !== null && a > b;
    }
    case "gte": {
      const a = num(actual);
      const b = num(expected);
      return a !== null && b !== null && a >= b;
    }
    case "lt": {
      const a = num(actual);
      const b = num(expected);
      return a !== null && b !== null && a < b;
    }
    case "lte": {
      const a = num(actual);
      const b = num(expected);
      return a !== null && b !== null && a <= b;
    }
    case "in":
      return Array.isArray(expected) && expected.includes(actual as never);
    case "not_in":
      return Array.isArray(expected) && !expected.includes(actual as never);
    case "contains":
      return Array.isArray(actual) && actual.includes(expected as never);
    case "not_contains":
      return Array.isArray(actual) && !actual.includes(expected as never);
    default:
      return false;
  }
}

export function formatValue(value: unknown): string {
  if (value === undefined) return "∅";
  if (value === null) return "null";
  if (typeof value === "string") return value;
  if (Array.isArray(value)) return `[${value.map((v) => JSON.stringify(v)).join(", ")}]`;
  return JSON.stringify(value);
}

const OP_TEXT: Record<string, string> = {
  eq: "==",
  ne: "!=",
  gt: ">",
  gte: ">=",
  lt: "<",
  lte: "<=",
  in: "∈",
  not_in: "∉",
  contains: "contains",
  not_contains: "does not contain",
  exists: "exists",
  not_exists: "does not exist",
  is_true: "is true",
  is_false: "is false",
  is_empty: "is empty",
  not_empty: "is not empty",
};

export function formatAssertion(a: Assertion): string {
  if (a.op === "exists" || a.op === "is_true") return `${a.field} ${OP_TEXT[a.op]}`;
  if (a.op === "not_exists" || a.op === "is_false" || a.op === "is_empty" || a.op === "not_empty") {
    return `${a.field} ${OP_TEXT[a.op]}`;
  }
  return `${a.field} ${OP_TEXT[a.op] ?? a.op} ${formatValue(a.value)}`;
}

/** Structural diff used by the finding verifier. */
export function deepDiff(
  before: unknown,
  after: unknown,
  path = "",
  out: Record<string, unknown> = {},
): Record<string, unknown> | null {
  if (canonicalJson(before) === canonicalJson(after)) return Object.keys(out).length ? out : null;
  if (Array.isArray(before) && Array.isArray(after)) {
    if (canonicalJson(before) !== canonicalJson(after)) {
      out[path || "value"] = { before, after };
    }
    return out;
  }
  if (
    before &&
    after &&
    typeof before === "object" &&
    typeof after === "object" &&
    !Array.isArray(before) &&
    !Array.isArray(after)
  ) {
    const keys = new Set([...Object.keys(before as object), ...Object.keys(after as object)]);
    for (const key of keys) {
      deepDiff(
        (before as Record<string, unknown>)[key],
        (after as Record<string, unknown>)[key],
        path ? `${path}.${key}` : key,
        out,
      );
    }
    return Object.keys(out).length ? out : null;
  }
  out[path || "value"] = { before, after };
  return out;
}

export function pct(value: number): string {
  return `${(value * 100).toFixed(1)}%`;
}

export function clamp(value: number, min: number, max: number): number {
  return Math.min(max, Math.max(min, value));
}

/** Deterministic hash-derived pseudo random in [0,1) for the synthetic world. */
export function seededUnit(seed: string): number {
  const digest = sha256(seed);
  return parseInt(digest.slice(0, 8), 16) / 0x100000000;
}

export function sha256Of(value: string): string {
  return sha256(value);
}
