import type { AlertEnvelope, Budget, Case, Hypothesis, Prediction } from "./types";
import { SETTINGS } from "./settings";
import { loadEtm } from "./etm";
import { CoverageMap } from "./coverage";
import { resolveWorld, normalizeHash, type MockWorld } from "./world";
import {
  generateHypotheses,
  historyClusters,
  orgContextFor,
  type OrgContext,
} from "./hypotheses";
import { getTemplate } from "./templates";
import { QueryExecutor, type ExecOutcome } from "./executor";
import { allowQuery } from "./policy";
import { buildFinding, markAnomaly, shortParams, summarize } from "./findings";
import { bestUnrunCandidate, selectQuery } from "./selector";
import { computeVerdict, coverageDecisiveQuestion, decisiveQuestion, recommendedAction } from "./verdict";
import { refreshNegativeSpace, logEvent, liveHypotheses, predictionKey, queryKey, type EngineEvent, type EngineState } from "./state";
import { canonicalJson, evaluateAssertion } from "./util";

/** core/engine.py — the falsification-first investigation loop (§8). */

const COST_PER_UNIT_USD = 0.015;

/** A tiny LangGraph-compatible state machine (nodes + conditional edges). */
export class StateGraph<S> {
  private nodes = new Map<string, (state: S) => Promise<S> | S>();
  private edges = new Map<string, string>();
  private conditional = new Map<string, (state: S) => string>();
  private entry = "";

  addNode(name: string, fn: (state: S) => Promise<S> | S): this {
    this.nodes.set(name, fn);
    return this;
  }

  addEdge(from: string, to: string): this {
    this.edges.set(from, to);
    return this;
  }

  addConditionalEdges(from: string, router: (state: S) => string, mapping?: Record<string, string>): this {
    this.conditional.set(from, mapping ? (state: S) => mapping[router(state)] ?? "END" : router);
    return this;
  }

  setEntryPoint(name: string): this {
    this.entry = name;
    return this;
  }

  async invoke(state: S): Promise<S> {
    let current = this.entry;
    let guard = 0;
    while (current && current !== "END" && guard < 100) {
      guard += 1;
      const node = this.nodes.get(current);
      if (!node) throw new Error(`unknown graph node: ${current}`);
      const started = Date.now();
      const next = await node(state);
      const events = (next as unknown as { events?: EngineEvent[] }).events;
      if (events) {
        events.push({
          ts: new Date().toISOString(),
          kind: "state_transition",
          name: current,
          attrs: { guard },
          durationMs: Date.now() - started,
        });
      }
      state = next;
      const router = this.conditional.get(current);
      current = router ? router(state) : (this.edges.get(current) ?? "END");
    }
    return state;
  }
}

const RULE_TO_CLASS: Record<string, string> = {
  "SEC-1001": "process_execution.suspicious_powershell",
  "SEC-1077": "process_execution.suspicious_powershell",
};

export function alertClassFor(ruleId: string): string {
  return RULE_TO_CLASS[ruleId] ?? SETTINGS.alertClass;
}

/** init_node step 1-2: normalize the incoming alert into the standard envelope. */
export function normalizeAlert(raw: Record<string, unknown>): AlertEnvelope {
  const str = (key: string, fallback = ""): string => (typeof raw[key] === "string" ? (raw[key] as string) : fallback);
  const asset = str("asset", "UNKNOWN-ASSET").trim() || "UNKNOWN-ASSET";
  const user = str("user", "UNKNOWN-USER").trim() || "UNKNOWN-USER";
  const processName = str("processName", "powershell.exe");
  const commandLine = str("commandLine", processName);
  const pid = Number.isFinite(Number(raw.pid)) && Number(raw.pid) > 0 ? Number(raw.pid) : 1000 + (asset.length % 800);
  const fileHash = normalizeHash(
    typeof raw.fileHash === "string" ? raw.fileHash : undefined,
    `${asset}|${user}|${commandLine}|${processName}`,
  );
  const observedAt = str("observedAt") || new Date().toISOString();
  return {
    alertId: str("alertId") || `ALT-${Date.now().toString(36).toUpperCase()}`,
    source: str("source", "edr"),
    ruleId: str("ruleId", "SEC-1001"),
    ruleName: str("ruleName", "Encoded PowerShell Command Line"),
    severity: str("severity", "medium"),
    title: str("title", "Encoded PowerShell activity"),
    description: str("description", ""),
    observedAt,
    asset,
    user,
    processName,
    pid,
    commandLine,
    fileHash,
    parentProcessName: str("parentProcessName"),
    destinationHost: typeof raw.destinationHost === "string" ? raw.destinationHost : null,
    worldKey: str("worldKey", "synthetic"),
    scenarioKey: typeof raw.scenarioKey === "string" ? raw.scenarioKey : null,
  };
}

export function emptyBudget(): Budget {
  return { queries: 0, wallMs: 0, costUsd: 0 };
}

function newCase(id: string, alert: AlertEnvelope, alertClass: string, label: string | null): Case {
  return {
    id,
    alert,
    alertClass,
    hypothesesInitial: [],
    hypothesesFinal: [],
    queryTrace: [],
    findings: [],
    negativeSpace: { alertClass, artifacts: [], tamperSignals: [], overall: "clean" },
    verdict: "indeterminate",
    verdictConfidence: 0,
    recommendedAction: "",
    decisiveQuestion: null,
    decisiveQuestionIg: null,
    createdAt: new Date().toISOString(),
    completedAt: null,
    budgetUsed: emptyBudget(),
    scenarioKey: alert.scenarioKey ?? null,
    label,
  };
}

export interface RunOptions {
  caseId: string;
  label?: string | null;
  useLlm?: boolean;
  dbBenignCaseCounts?: Record<string, number>;
  snapshotSink?: (uri: string, payload: Record<string, unknown>) => Promise<void>;
}

export function buildState(options: RunOptions, alert: AlertEnvelope): EngineState {
  const alertClass = alertClassFor(alert.ruleId);
  const etm = loadEtm(alertClass);
  const world = resolveWorld(alert);
  const coverageMap = new CoverageMap(world);
  const c = newCase(options.caseId, alert, alertClass, options.label ?? null);
  return {
    case: c,
    alert,
    pendingOutcome: null,
    extraHypothesisGenerated: false,
    world,
    coverageMap,
    etm,
    org: orgContextFor(alert, world),
    clusters: historyClusters(alertClass),
    hypotheses: [],
    findings: [],
    runKeys: new Set<string>(),
    budgetUsed: emptyBudget(),
    budgetExhausted: false,
    stepCount: 0,
    verdict: null,
    verdictReason: null,
    stopReason: null,
    pendingQuery: null,
    events: [],
    startedAt: Date.now(),
    llmUsed: false,
    llmError: null,
    decisiveQuestion: null,
    decisiveQuestionIg: null,
    useLlm: options.useLlm ?? false,
    dbBenignCaseCounts: options.dbBenignCaseCounts ?? {},
  };
}

/* ----------------------------- nodes ----------------------------- */

async function initNode(state: EngineState): Promise<EngineState> {
  const generated = await generateHypotheses({
    alert: state.alert,
    alertClass: state.case.alertClass,
    world: state.world,
    org: state.org,
    historyClusters: state.clusters,
    historyCaseCounts: state.dbBenignCaseCounts,
    useLlm: state.useLlm,
  });
  state.hypotheses = generated.hypotheses;
  state.llmUsed = generated.llmUsed;
  state.llmError = generated.llmError;
  state.case.hypothesesInitial = state.hypotheses.map((h) => ({ ...h, predictions: h.predictions.map((p) => ({ ...p })) }));
  refreshNegativeSpace(state);
  if (generated.llmUsed) {
    logEvent(state, "llm_call", "hypothesis_gen", {
      model: SETTINGS.llm.hypothesisModel,
      generated: generated.hypotheses.filter((h) => h.source === "generative").length,
    });
  }
  logEvent(state, "state_transition", "init", {
    alert_class: state.case.alertClass,
    hypotheses: state.hypotheses.length,
    org_context: state.org as unknown as Record<string, unknown>,
  });
  return state;
}

function selectNode(state: EngineState): EngineState {
  refreshNegativeSpace(state);
  const best = selectQuery(state);
  if (!best) {
    const result = computeVerdict(state);
    state.verdict = result.verdict;
    state.verdictReason = result.reason;
    state.stopReason = state.stopReason ?? "no query above information-gain threshold";
    state.pendingQuery = null;
    return state;
  }
  state.pendingQuery = best;
  logEvent(state, "query", "select", {
    template: best.templateId,
    params: best.params,
    ig: best.igScore,
    rationale: best.rationale,
  });
  return state;
}

async function executeNode(state: EngineState): Promise<EngineState> {
  if (!state.pendingQuery) return state;
  const template = getTemplate(state.pendingQuery.templateId);
  const costUsd = (template?.cost ?? 1) * COST_PER_UNIT_USD;
  const decision = allowQuery(state.budgetUsed, costUsd);
  logEvent(state, "policy", "budget_check", {
    template: state.pendingQuery.templateId,
    allow: decision.allow,
    rule: decision.rule,
    reason: decision.reason,
  });
  if (!decision.allow) {
    state.budgetExhausted = true;
    state.stopReason = `budget: ${decision.reason}`;
    state.pendingQuery = null;
    return state;
  }
  const executor = new QueryExecutor(state.world, state.coverageMap, async () => {});
  const outcome = await executor.execute(state.pendingQuery.templateId, state.pendingQuery.params);
  state.pendingOutcome = outcome;
  return state;
}

function recordNode(state: EngineState): EngineState {
  const outcome = state.pendingOutcome;
  const pending = state.pendingQuery;
  state.pendingOutcome = null;
  state.pendingQuery = null;
  if (!outcome || !pending || !outcome.ok || !outcome.untrusted) {
    if (outcome && pending) {
      state.runKeys.add(queryKey(pending.templateId, pending.params));
      logEvent(state, "query", "rejected", { template: pending.templateId, errors: outcome?.errors ?? [] });
    }
    return state;
  }

  const step = state.findings.length + 1;
  const findingId = `F${step}`;
  const hash = outcome.hash ?? "";
  const uri = `snapshots/${state.case.id}/${outcome.templateId}/${hash.slice(0, 16)}.json`;
  const finding = buildFinding({
    id: findingId,
    templateId: outcome.templateId,
    params: outcome.params,
    untrusted: outcome.untrusted,
    hash,
    snapshotUri: uri,
  });

  state.findings.push({ finding, result: outcome.untrusted.data, coverage: outcome.untrusted.coverage.status });
  state.case.findings.push(finding);
  state.case.queryTrace.push({
    step,
    queryTemplateId: outcome.templateId,
    params: outcome.params,
    igScore: pending.igScore,
    latencyMs: outcome.latencyMs,
    resultFindingId: findingId,
    rationale: pending.rationale,
  });
  state.runKeys.add(queryKey(outcome.templateId, outcome.params));
  state.stepCount += 1;
  state.budgetUsed.queries += 1;
  state.budgetUsed.costUsd = Number((state.budgetUsed.costUsd + (getTemplate(outcome.templateId)?.cost ?? 1) * COST_PER_UNIT_USD).toFixed(4));
  state.budgetUsed.wallMs = Date.now() - state.startedAt;

  logEvent(state, "query", "execute", {
    template: outcome.templateId,
    params: outcome.params,
    latency_ms: outcome.latencyMs,
    result_hash: outcome.hash,
    coverage: outcome.untrusted.coverage.status,
    summary: summarize(outcome.templateId, outcome.untrusted.data),
  });
  return state;
}

function applyOutcomesFromFindings(hypothesis: Hypothesis, findings: EngineState["findings"]): void {
  for (const prediction of hypothesis.predictions) {
    const key = predictionKey(prediction);
    const record = findings.find((f) => queryKey(f.finding.queryTemplateId, f.finding.params) === key);
    if (!record) continue;
    if (record.coverage !== "covered") {
      prediction.outcome = "unobservable";
    } else {
      prediction.outcome = evaluateAssertion(prediction.assertion, record.result) ? "confirmed" : "violated";
    }
    prediction.evidenceFindingId = record.finding.id;
    if (!record.finding.hypothesisImpact.includes(hypothesis.id)) {
      record.finding.hypothesisImpact.push(hypothesis.id);
    }
  }
}

function ensureTamperHypothesis(state: EngineState, reason: string): void {
  const existing = state.hypotheses.find((h) => h.key === "negative_space_tamper");
  if (existing) {
    existing.posterior = Math.max(existing.posterior, 0.55);
    applyOutcomesFromFindings(existing, state.findings);
    return;
  }
  const id = `H${state.hypotheses.length + 1}`;
  const hypothesis: Hypothesis = {
    id,
    statement: `Negative-space inference: ${reason}`,
    hypothesisClass: "tamper",
    prior: 0.2,
    posterior: 0.55,
    status: "alive",
    source: "library",
    predictions: [
      {
        ifTrue: "If telemetry was suppressed, the heartbeat cadence has a gap straddling the event.",
        queryTemplateId: "edr_heartbeat_check",
        params: { asset: state.alert.asset, window: "1h" },
        expected: "gap_covering_event is true",
        necessity: "hard",
        condition: null,
        assertion: { field: "gap_covering_event", op: "is_true" },
        outcome: null,
        evidenceFindingId: null,
      },
      {
        ifTrue: "If telemetry was suppressed, the EDR has no process event for the PID.",
        queryTemplateId: "edr_process_tree",
        params: { asset: state.alert.asset, pid: state.alert.pid },
        expected: "found is false",
        necessity: "hard",
        condition: null,
        assertion: { field: "found", op: "is_false" },
        outcome: null,
        evidenceFindingId: null,
      },
    ],
    falsifiedBy: [],
    key: "negative_space_tamper",
  };
  applyOutcomesFromFindings(hypothesis, state.findings);
  state.hypotheses.push(hypothesis);
}

function updateNode(state: EngineState): EngineState {
  const record = state.findings[state.findings.length - 1];
  if (!record) return state;
  const findingKey = queryKey(record.finding.queryTemplateId, record.finding.params);

  // 1. Evaluate every prediction this finding can settle.
  for (const hypothesis of state.hypotheses) {
    for (const prediction of hypothesis.predictions) {
      if (predictionKey(prediction) !== findingKey) continue;
      if (record.coverage !== "covered") {
        prediction.outcome = "unobservable";
      } else {
        prediction.outcome = evaluateAssertion(prediction.assertion, record.result) ? "confirmed" : "violated";
      }
      prediction.evidenceFindingId = record.finding.id;
      if (!record.finding.hypothesisImpact.includes(hypothesis.id)) {
        record.finding.hypothesisImpact.push(hypothesis.id);
      }
    }
  }

  // 2. Falsification: one violated hard prediction kills the hypothesis.
  for (const hypothesis of state.hypotheses) {
    if (hypothesis.status === "falsified") continue;
    const killer = hypothesis.predictions.find((p) => p.necessity === "hard" && p.outcome === "violated");
    if (killer) {
      hypothesis.status = "falsified";
      if (killer.evidenceFindingId && !hypothesis.falsifiedBy.includes(killer.evidenceFindingId)) {
        hypothesis.falsifiedBy.push(killer.evidenceFindingId);
      }
      continue;
    }
    const evaluated = hypothesis.predictions.filter((p) => p.outcome !== null);
    if (
      evaluated.length === hypothesis.predictions.length &&
      hypothesis.predictions.length > 0 &&
      evaluated.every((p) => p.outcome === "unobservable")
    ) {
      hypothesis.status = "unobservable";
    }
  }

  // 3. Posterior update with likelihood ratios, then renormalise live mass.
  for (const hypothesis of state.hypotheses) {
    if (hypothesis.status === "falsified") {
      hypothesis.posterior = 0;
      continue;
    }
    let factor = 1;
    for (const prediction of hypothesis.predictions) {
      if (prediction.evidenceFindingId !== record.finding.id) continue;
      if (prediction.outcome === "confirmed") {
        factor *= prediction.necessity === "hard" ? SETTINGS.posterior.confirmHard : SETTINGS.posterior.confirmSoft;
      } else if (prediction.outcome === "violated") {
        factor *= prediction.necessity === "soft" ? SETTINGS.posterior.violateSoft : 1;
      } else if (prediction.outcome === "unobservable") {
        factor *= SETTINGS.posterior.unobservable;
      }
    }
    hypothesis.posterior = Math.max(SETTINGS.posterior.floor, hypothesis.posterior * factor);
  }
  const survivors = state.hypotheses.filter((h) => h.status !== "falsified");
  const total = survivors.reduce((sum, h) => sum + h.posterior, 0);
  for (const hypothesis of survivors) {
    hypothesis.posterior = total > 0 ? Number((hypothesis.posterior / total).toFixed(6)) : Number((1 / survivors.length).toFixed(6));
  }

  // 4. Negative-space check → tamper hypothesis + anomaly reclassification.
  const report = refreshNegativeSpace(state);
  if (report.overall === "anomaly") {
    const reason = report.tamperSignals[0]?.detail ?? "hard-required telemetry missing while sensors were covered";
    ensureTamperHypothesis(state, reason);
    for (const artifact of report.artifacts) {
      if (artifact.inference !== "anomaly" || !artifact.evidenceFindingId) continue;
      const target = state.findings.find((f) => f.finding.id === artifact.evidenceFindingId);
      if (target) target.finding = markAnomaly(target.finding, `${artifact.artifact} was required but not observed while covered`);
    }
    const survivorsAfter = state.hypotheses.filter((h) => h.status !== "falsified");
    const totalAfter = survivorsAfter.reduce((sum, h) => sum + h.posterior, 0);
    for (const hypothesis of survivorsAfter) {
      hypothesis.posterior =
        totalAfter > 0 ? Number((hypothesis.posterior / totalAfter).toFixed(6)) : Number((1 / survivorsAfter.length).toFixed(6));
    }
  }

  // 5. Context expansion (new entity revealed by the finding).
  if (!state.extraHypothesisGenerated && record.finding.queryTemplateId === "edr_process_tree") {
    const treeUser = typeof record.result.user === "string" ? record.result.user : null;
    if (treeUser && treeUser !== state.alert.user) {
      state.extraHypothesisGenerated = true;
      const id = `H${state.hypotheses.length + 1}`;
      const prediction: Prediction = {
        ifTrue: "If the process-tree identity is a scheduled service, its IdP client is non-interactive.",
        queryTemplateId: "idp_signin_lookup",
        params: { user: treeUser, window: "24h" },
        expected: "client_app ∈ [service_principal, daemon]",
        necessity: "soft",
        condition: null,
        assertion: { field: "client_app", op: "in", value: ["service_principal", "daemon"] },
        outcome: null,
        evidenceFindingId: null,
      };
      state.hypotheses.push({
        id,
        statement: `Context expansion: the EDR reports the executing identity as ${treeUser}, not ${state.alert.user}.`,
        hypothesisClass: "benign",
        prior: 0.08,
        posterior: 0.08,
        status: "alive",
        source: "generative",
        predictions: [prediction],
        falsifiedBy: [],
        key: "ctx_expanded_identity",
      });
      logEvent(state, "llm_call", "context_expansion", { new_user: treeUser });
    }
  }

  logEvent(state, "state_transition", "update", {
    finding: record.finding.id,
    type: record.finding.type,
    coverage: record.coverage,
    live: liveHypotheses(state).length,
    negative_space: report.overall,
  });
  return state;
}

function checkNode(state: EngineState): EngineState {
  const result = computeVerdict(state);
  if (result.verdict && !state.verdict) {
    state.verdict = result.verdict;
    state.verdictReason = result.reason;
  }
  logEvent(state, "state_transition", "check", {
    step_count: state.stepCount,
    budget_exhausted: state.budgetExhausted,
    verdict: state.verdict,
    stop_reason: state.stopReason,
  });
  return state;
}

function checkRouter(state: EngineState): string {
  if (state.budgetExhausted) return "budget_exhausted";
  if (state.stopReason || state.verdict) return "verdict_reached";
  if (state.stepCount >= SETTINGS.budget.maxQueries) return "budget_exhausted";
  if (!selectQuery(state)) return "verdict_reached";
  return "continue";
}

function outputNode(state: EngineState): EngineState {
  refreshNegativeSpace(state);
  let result = computeVerdict(state);
  if (!result.verdict) {
    result = computeVerdict(state, { force: true });
    state.stopReason = state.stopReason ?? "forced verdict (anytime property)";
  }
  state.verdict = result.verdict ?? "indeterminate";
  state.verdictReason = result.reason;
  state.case.verdict = state.verdict;
  state.case.verdictConfidence = result.confidence;
  state.case.recommendedAction = recommendedAction(state.verdict, state);
  state.case.budgetUsed = { ...state.budgetUsed, wallMs: Date.now() - state.startedAt };

  if (state.verdict === "indeterminate") {
    const candidate = bestUnrunCandidate(state);
    state.decisiveQuestion = decisiveQuestion(state, candidate) ?? coverageDecisiveQuestion(state);
    state.decisiveQuestionIg = candidate?.igScore ?? null;
    state.case.decisiveQuestion = state.decisiveQuestion;
    state.case.decisiveQuestionIg = state.decisiveQuestionIg;
  }

  state.case.hypothesesFinal = state.hypotheses.map((h) => ({
    ...h,
    predictions: h.predictions.map((p) => ({ ...p })),
    falsifiedBy: [...h.falsifiedBy],
  }));
  state.case.findings = state.findings.map((f) => ({ ...f.finding }));
  state.case.completedAt = new Date().toISOString();
  logEvent(state, "verdict", "output", {
    verdict: state.verdict,
    confidence: result.confidence,
    reason: result.reason,
    queries: state.case.queryTrace.length,
    benign_share: Number(result.benignShare.toFixed(3)),
    malicious_share: Number(result.maliciousShare.toFixed(3)),
    stop_reason: state.stopReason,
  });
  return state;
}

export function buildGraph(): StateGraph<EngineState> {
  const graph = new StateGraph<EngineState>();
  graph.addNode("init", initNode);
  graph.addNode("select", selectNode);
  graph.addNode("execute", executeNode);
  graph.addNode("record", recordNode);
  graph.addNode("update", updateNode);
  graph.addNode("check", checkNode);
  graph.addNode("output", outputNode);
  graph.setEntryPoint("init");
  graph.addEdge("init", "select");
  graph.addEdge("select", "execute");
  graph.addEdge("execute", "record");
  graph.addEdge("record", "update");
  graph.addEdge("update", "check");
  graph.addConditionalEdges("check", checkRouter, {
    verdict_reached: "output",
    budget_exhausted: "output",
    continue: "select",
  });
  graph.addEdge("output", "END");
  return graph;
}

export interface RunResult {
  case: Case;
  events: EngineEvent[];
  findingResults: Record<string, Record<string, unknown>>;
  llmUsed: boolean;
  llmError: string | null;
  stopReason: string | null;
  verdictReason: string | null;
  org: OrgContext;
  world: MockWorld;
}

/** Entry point: run the full investigation loop for one alert. */
export async function runCase(alertInput: Record<string, unknown>, options: RunOptions): Promise<RunResult> {
  const alert = normalizeAlert(alertInput);
  const state = buildState(options, alert);
  const graph = buildGraph();
  await graph.invoke(state);
  return {
    case: state.case,
    findingResults: Object.fromEntries(state.findings.map((f) => [f.finding.id, f.result])),
    events: state.events,
    llmUsed: state.llmUsed,
    llmError: state.llmError,
    stopReason: state.stopReason,
    verdictReason: state.verdictReason,
    org: state.org,
    world: state.world,
  };
}

export { COST_PER_UNIT_USD };
