import type {
  AlertEnvelope,
  EtmArtifact,
  FindingRecord,
  Inference,
  NegativeSpaceArtifact,
  NegativeSpaceReport,
  Necessity,
  TamperWeight,
  TelemetrySource,
} from "./types";
import { evaluateAssertion, formatAssertion } from "./util";
import { conditionMet, contextFacts, type Etm } from "./etm";
import type { CoverageMap } from "./coverage";

/**
 * Negative-space scoring (§6). "I found nothing" is never an answer: it is one
 * of evidence-of-absence, unknown (uncovered sensor) or anomaly (tamper).
 */

export function scoreArtifact(
  artifact: string,
  observed: boolean,
  covered: boolean,
  necessity: Necessity,
): Inference {
  if (observed) return "presence";
  if (!covered) return "unknown";
  if (necessity === "hard") return "anomaly";
  if (necessity === "soft") return "mild_absence";
  return "anomaly";
}

function probeFinding(artifact: EtmArtifact, records: FindingRecord[], alert: AlertEnvelope): FindingRecord | null {
  return (
    records.find((r) => {
      if (r.finding.queryTemplateId !== artifact.probeTemplateId) return false;
      if (artifact.probeParamsFrom === "user") return r.finding.params.user === alert.user;
      return r.finding.params.asset === alert.asset;
    }) ?? null
  );
}

function sourceOf(artifact: TelemetrySource): TelemetrySource {
  return artifact;
}

export function buildNegativeSpaceReport(
  alert: AlertEnvelope,
  etm: Etm,
  records: FindingRecord[],
  coverageMap: CoverageMap,
): NegativeSpaceReport {
  const facts = contextFacts(alert);
  const artifacts: NegativeSpaceArtifact[] = [];

  for (const artifact of etm.requiredIfReal) {
    const triggered = conditionMet(artifact, facts);
    const record = probeFinding(artifact, records, alert);
    let covered: NegativeSpaceArtifact["covered"] = "unknown";
    let detail = "not yet probed";
    let observed = false;

    if (record) {
      observed = evaluateAssertion(artifact.observedWhen, record.result);
      const answer =
        artifact.probeParamsFrom === "user"
          ? coverageMap.coverageForUser(sourceOf(artifact.artifact), alert.user)
          : coverageMap.coverage(sourceOf(artifact.artifact), alert.asset, null);
      covered = answer.status;
      detail = `${formatAssertion(artifact.observedWhen)} → ${observed ? "observed" : "not observed"}; ${answer.detail}`;
    } else if (!triggered) {
      detail = `conditional requirement not triggered: ${artifact.condition ?? ""}`;
    }

    const effectiveNecessity: Necessity = triggered ? artifact.necessity : "soft";
    const inference: Inference = triggered
      ? scoreArtifact(artifact.artifact, observed, covered === "covered", effectiveNecessity)
      : "unknown";

    artifacts.push({
      artifact: artifact.artifact,
      observed,
      covered,
      inference,
      necessity: effectiveNecessity,
      evidenceFindingId: record?.finding.id ?? null,
      detail,
    });
  }

  const byTemplate: Record<string, FindingRecord> = {};
  for (const record of records) {
    if (!byTemplate[record.finding.queryTemplateId]) byTemplate[record.finding.queryTemplateId] = record;
  }

  const tamperSignals: { pattern: string; weight: TamperWeight; detail: string }[] = [];
  for (const signal of etm.tamperSignals) {
    const detail = signal.detect({ byTemplate, artifacts, alert });
    if (detail) tamperSignals.push({ pattern: signal.pattern, weight: signal.weight, detail });
  }

  let overall: NegativeSpaceReport["overall"] = "clean";
  if (tamperSignals.some((s) => s.weight === "high" || s.weight === "critical")) overall = "anomaly";
  else if (artifacts.some((a) => a.inference === "anomaly")) overall = "anomaly";
  else if (artifacts.some((a) => a.covered === "uncovered")) overall = "gap";
  else if (artifacts.some((a) => a.necessity === "hard" && a.inference === "unknown")) overall = "gap";
  else if (artifacts.some((a) => a.inference === "mild_absence")) overall = "gap";

  return { alertClass: etm.alertClass, artifacts, tamperSignals, overall };
}

/**
 * Hard evidence requirements that are still unresolved (blind sensor or not yet
 * probed). No verdict may be issued while this list is non-empty — this is what
 * makes "we found nothing" impossible to report as benign.
 */
export function unresolvedHardRequirements(report: NegativeSpaceReport): NegativeSpaceArtifact[] {
  return report.artifacts.filter((a) => a.necessity === "hard" && a.inference === "unknown");
}
