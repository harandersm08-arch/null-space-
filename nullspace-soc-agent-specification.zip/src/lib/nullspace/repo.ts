import { and, desc, eq, gte, inArray, sql } from "drizzle-orm";
import { db } from "@/db";
import { caseFindings, cases, evaluationRuns, historicalCases, verifications } from "@/db/schema";
import type { Case, Finding, NegativeSpaceReport } from "./types";
import type { EngineEvent } from "./state";
import { normalizeAlert, runCase, type RunResult } from "./engine";
import { HISTORY_SEED, resolveWorld, type MockWorld } from "./world";
import { CoverageMap } from "./coverage";
import { executeDirect } from "./executor";
import { verifyFinding } from "./verifier";

let seeded = false;

export async function ensureSeed(): Promise<void> {
  if (seeded) return;
  const existing = await db.select({ count: sql<number>`count(*)::int` }).from(historicalCases);
  if ((existing[0]?.count ?? 0) === 0) {
    await db.insert(historicalCases).values(
      HISTORY_SEED.map((h) => ({
        alertClass: h.alert_class,
        cluster: h.cluster,
        resolution: h.resolution,
        cases: h.cases,
        label: h.label,
      })),
    );
  }
  seeded = true;
}

export function newCaseId(): string {
  return `NS-${Date.now().toString(36).toUpperCase()}-${Math.random().toString(36).slice(2, 7).toUpperCase()}`;
}

export async function benignCountsByWinningKey(): Promise<Record<string, number>> {
  const since = new Date(Date.now() - 30 * 24 * 3600 * 1000);
  const rows = await db
    .select({ key: cases.winningKey, count: sql<number>`count(*)::int` })
    .from(cases)
    .where(and(inArray(cases.verdict, ["benign", "benign_noisy"]), gte(cases.createdAt, since)))
    .groupBy(cases.winningKey);
  const out: Record<string, number> = {};
  for (const row of rows) if (row.key) out[row.key] = row.count;
  return out;
}

function winningKeyOf(c: Case): string | null {
  const live = c.hypothesesFinal.filter((h) => h.status !== "falsified");
  const benign = live.filter((h) => h.hypothesisClass === "benign").sort((a, b) => b.posterior - a.posterior);
  if (benign[0]) return benign[0].key ?? null;
  const any = live.sort((a, b) => b.posterior - a.posterior)[0];
  return any?.key ?? null;
}

export async function investigateAndPersist(
  alertInput: Record<string, unknown>,
  opts: { label?: string | null; useLlm?: boolean; caseId?: string },
): Promise<RunResult & { caseId: string }> {
  await ensureSeed();
  const caseId = opts.caseId ?? newCaseId();
  const counts = await benignCountsByWinningKey();
  const result = await runCase(alertInput, {
    caseId,
    label: opts.label ?? null,
    useLlm: opts.useLlm ?? false,
    dbBenignCaseCounts: counts,
  });

  await db.insert(cases).values({
    id: caseId,
    scenarioKey: result.case.scenarioKey ?? null,
    alertClass: result.case.alertClass,
    status: "complete",
    alert: result.case.alert as unknown as Record<string, unknown>,
    label: opts.label ?? null,
    verdict: result.case.verdict,
    verdictConfidence: result.case.verdictConfidence,
    verdictReason: result.verdictReason,
    recommendedAction: result.case.recommendedAction,
    decisiveQuestion: result.case.decisiveQuestion,
    winningKey: winningKeyOf(result.case),
    negativeSpace: result.case.negativeSpace,
    hypothesesInitial: result.case.hypothesesInitial,
    hypothesesFinal: result.case.hypothesesFinal,
    queryTrace: result.case.queryTrace,
    budgetUsed: result.case.budgetUsed,
    events: result.events,
    queryCount: result.case.queryTrace.length,
    llmUsed: result.llmUsed,
    completedAt: new Date(),
  });

  if (result.case.findings.length > 0) {
    const findingRecords = result.case.findings.map((f) => {
      return {
        caseId,
        findingId: f.id,
        claim: f.claim,
        type: f.type,
        queryTemplateId: f.queryTemplateId,
        params: f.params,
        executedAt: f.executedAt,
        resultHash: f.resultHash,
        resultSnapshotUri: f.resultSnapshotUri,
        reproducibility: f.reproducibility,
        coverageAtExecution: f.coverageAtExecution,
        hypothesisImpact: f.hypothesisImpact,
        summary: f.summary,
        result: result.findingResults[f.id] ?? {},
      };
    });
    await db.insert(caseFindings).values(findingRecords);
  }

  return { ...result, caseId };
}

export interface CaseRecord {
  case: Case;
  events: EngineEvent[];
  label: string | null;
  verdictReason: string | null;
  llmUsed: boolean;
  createdAt: string;
}

export async function loadCase(id: string): Promise<CaseRecord | null> {
  const rows = await db.select().from(cases).where(eq(cases.id, id)).limit(1);
  const row = rows[0];
  if (!row) return null;
  const findingRows = await db.select().from(caseFindings).where(eq(caseFindings.caseId, id));
  const findings: Finding[] = findingRows
    .sort((a, b) => a.findingId.localeCompare(b.findingId, undefined, { numeric: true }))
    .map((f) => ({
      id: f.findingId,
      claim: f.claim,
      type: f.type as Finding["type"],
      queryTemplateId: f.queryTemplateId,
      params: f.params,
      executedAt: f.executedAt,
      resultHash: f.resultHash,
      resultSnapshotUri: f.resultSnapshotUri,
      reproducibility: f.reproducibility as Finding["reproducibility"],
      coverageAtExecution: f.coverageAtExecution as Finding["coverageAtExecution"],
      hypothesisImpact: f.hypothesisImpact,
      summary: f.summary,
    }));

  return {
    case: {
      id: row.id,
      alert: normalizeAlert(row.alert),
      alertClass: row.alertClass,
      hypothesesInitial: row.hypothesesInitial ?? [],
      hypothesesFinal: row.hypothesesFinal ?? [],
      queryTrace: row.queryTrace ?? [],
      findings,
      negativeSpace: row.negativeSpace ?? { alertClass: row.alertClass, artifacts: [], tamperSignals: [], overall: "clean" },
      verdict: (row.verdict ?? "indeterminate") as Case["verdict"],
      verdictConfidence: row.verdictConfidence ?? 0,
      recommendedAction: row.recommendedAction ?? "",
      decisiveQuestion: row.decisiveQuestion,
      decisiveQuestionIg: null,
      createdAt: row.createdAt.toISOString(),
      completedAt: row.completedAt?.toISOString() ?? null,
      budgetUsed: row.budgetUsed ?? { queries: 0, wallMs: 0, costUsd: 0 },
      scenarioKey: row.scenarioKey,
      label: row.label,
    },
    events: row.events ?? [],
    label: row.label,
    verdictReason: row.verdictReason,
    llmUsed: row.llmUsed,
    createdAt: row.createdAt.toISOString(),
  };
}

export interface CaseSummary {
  id: string;
  scenarioKey: string | null;
  label: string | null;
  alertClass: string;
  verdict: string;
  verdictConfidence: number;
  queryCount: number;
  asset: string;
  user: string;
  ruleId: string;
  createdAt: string;
  negativeSpace: NegativeSpaceReport | null;
}

export async function listCases(limit = 25): Promise<CaseSummary[]> {
  const rows = await db.select().from(cases).orderBy(desc(cases.createdAt)).limit(limit);
  return rows.map((row) => ({
    id: row.id,
    scenarioKey: row.scenarioKey,
    label: row.label,
    alertClass: row.alertClass,
    verdict: row.verdict ?? "indeterminate",
    verdictConfidence: row.verdictConfidence ?? 0,
    queryCount: row.queryCount,
    asset: String(row.alert.asset ?? ""),
    user: String(row.alert.user ?? ""),
    ruleId: String(row.alert.ruleId ?? ""),
    createdAt: row.createdAt.toISOString(),
    negativeSpace: row.negativeSpace ?? null,
  }));
}

export interface FindingContext {
  finding: Finding;
  caseId: string;
  alert: Record<string, unknown>;
  result: Record<string, unknown>;
}

export async function getFindingContext(findingId: string): Promise<FindingContext | null> {
  const rows = await db.select().from(caseFindings).where(eq(caseFindings.findingId, findingId)).limit(1);
  const row = rows[0];
  if (!row) return null;
  const caseRows = await db.select().from(cases).where(eq(cases.id, row.caseId)).limit(1);
  const caseRow = caseRows[0];
  return {
    finding: {
      id: row.findingId,
      claim: row.claim,
      type: row.type as Finding["type"],
      queryTemplateId: row.queryTemplateId,
      params: row.params,
      executedAt: row.executedAt,
      resultHash: row.resultHash,
      resultSnapshotUri: row.resultSnapshotUri,
      reproducibility: row.reproducibility as Finding["reproducibility"],
      coverageAtExecution: row.coverageAtExecution as Finding["coverageAtExecution"],
      hypothesisImpact: row.hypothesisImpact,
      summary: row.summary,
    },
    caseId: row.caseId,
    alert: caseRow?.alert ?? {},
    result: row.result ?? {},
  };
}

/** Deterministic "world moved on" mutation used to demonstrate DRIFT / FAIL. */
export function mutateWorld(world: MockWorld, asset: string): MockWorld {
  const next: MockWorld = JSON.parse(JSON.stringify(world));
  const hb = next.heartbeats[asset];
  if (hb) next.heartbeats[asset] = { ...hb, agent_status: "degraded", coverage_pct: 0.71, observed_intervals: Math.round(hb.expected_intervals * 0.71) };
  const proxy = next.proxy[asset];
  if (proxy && proxy.sensor_status === "collecting") {
    next.proxy[asset] = {
      ...proxy,
      flow_count: proxy.flow_count + 1,
      egress_to_raw_ip: true,
      flows: [...proxy.flows, { destination: "203.0.113.9:443", bytes: 4096, category: "raw_ip" }],
    };
  }
  const dns = next.dns[asset];
  if (dns && dns.sensor_status === "collecting") {
    next.dns[asset] = {
      ...dns,
      resolution_count: dns.resolution_count + 1,
      suspicious_domain_count: dns.suspicious_domain_count + 1,
      resolutions: [...dns.resolutions, { domain: "update-check-cdn.top", resolved_ip: "198.51.100.23", classification: "newly_registered", count: 1 }],
    };
  }
  const tree = next.processTrees[asset];
  if (tree) {
    next.processTrees[asset] = {
      ...tree,
      signature_valid: false,
      suspicious_module_count: tree.suspicious_module_count + 1,
      module_load_count: tree.module_load_count + 1,
      modules: [...tree.modules, "comsvgs.dll (MiniDump)"],
    };
  }
  const fleetKeys = Object.keys(next.hashFleet);
  if (fleetKeys.length > 0) {
    const key = fleetKeys[0];
    const record = next.hashFleet[key];
    next.hashFleet[key] = { ...record, occurrence_count: record.occurrence_count + 1, distinct_hosts: record.distinct_hosts + 1 };
  }
  return next;
}

export async function verifyFindingById(findingId: string, mode: "replay" | "drift") {
  const context = await getFindingContext(findingId);
  if (!context) return null;
  const alert = normalizeAlert(context.alert);
  const baseWorld = resolveWorld(alert);
  const world = mode === "drift" ? mutateWorld(baseWorld, alert.asset) : baseWorld;
  const coverage = new CoverageMap(world);
  const outcome = executeDirect(world, coverage, context.finding.queryTemplateId, context.finding.params);
  const result = verifyFinding(
    context.finding,
    { templateId: context.finding.queryTemplateId, params: context.finding.params, data: context.result },
    outcome,
  );

  await db.insert(verifications).values({
    caseId: context.caseId,
    findingId,
    status: result.status,
    mode,
    originalHash: result.originalHash,
    currentHash: result.currentHash,
    diff: result.diff,
    message: result.message,
  });

  return { ...result, caseId: context.caseId, currentData: outcome.untrusted?.data ?? null, snapshotData: context.result };
}

export async function recentVerifications(limit = 10) {
  return db.select().from(verifications).orderBy(desc(verifications.createdAt)).limit(limit);
}

export async function saveEvaluation(summary: {
  total: number;
  correct: number;
  sycophancyRate: number;
  averageQueries: number;
  benignSurvival: number;
  results: Record<string, unknown>[];
}): Promise<string> {
  const id = `EVAL-${Date.now().toString(36).toUpperCase()}`;
  await db.insert(evaluationRuns).values({
    id,
    total: summary.total,
    correct: summary.correct,
    sycophancyRate: summary.sycophancyRate,
    averageQueries: summary.averageQueries,
    benignSurvival: summary.benignSurvival,
    results: summary.results,
  });
  return id;
}

export async function latestEvaluations(limit = 5) {
  return db.select().from(evaluationRuns).orderBy(desc(evaluationRuns.startedAt)).limit(limit);
}
