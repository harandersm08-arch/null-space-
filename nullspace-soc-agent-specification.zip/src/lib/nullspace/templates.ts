import { z } from "zod";
import type { AlertEnvelope, Reproducibility, TelemetrySource } from "./types";
import type { MockWorld } from "./world";

/**
 * Query template registry (§5). The only surface an LLM ever sees is
 * `id` + `params` — there is no code path where model output becomes a query
 * string (§13.1). Params are schema-validated before execution.
 */

export interface ParamSpec {
  type: "string" | "integer";
  pattern?: string;
  required: boolean;
  description: string;
}

export interface MockResult {
  data: Record<string, unknown>;
  sensor: { source: TelemetrySource; asset: string; status: "covered" | "uncovered" | "unknown"; detail: string };
}

export interface QueryTemplate {
  id: string;
  capability: string;
  description: string;
  paramSpec: Record<string, ParamSpec>;
  schema: z.ZodType<Record<string, unknown>>;
  returns: { name: string; type: string }[];
  typicalLatencyS: number;
  cost: number;
  reproducibility: Reproducibility;
  discriminates: string[];
  source: TelemetrySource;
  returnsCollection: boolean;
  bindFromAlert: (alert: AlertEnvelope) => Record<string, unknown> | null;
  run: (world: MockWorld, params: Record<string, unknown>) => MockResult;
}

const str = (pattern: RegExp, description: string): ParamSpec => ({ type: "string", pattern: pattern.source, required: true, description });
const ASSET = str(/^[A-Za-z0-9][A-Za-z0-9._-]{1,63}$/, "Asset hostname");
const USER = str(/^[A-Za-z0-9][A-Za-z0-9._@-]{1,63}$/, "Identity (user or service principal)");
const WINDOW = str(/^[0-9]+(h|d|m)$/, "Lookback window, e.g. 24h");
const HASH = str(/^[a-f0-9]{64}$/, "SHA-256 file hash, lowercase hex");

function sensor(
  source: TelemetrySource,
  asset: string,
  status: "covered" | "uncovered" | "unknown",
  detail: string,
): MockResult["sensor"] {
  return { source, asset, status, detail };
}

function s(value: unknown, fallback = ""): string {
  return typeof value === "string" ? value : fallback;
}

function n(value: unknown, fallback = 0): number {
  return typeof value === "number" && Number.isFinite(value) ? value : fallback;
}

export const TEMPLATES: QueryTemplate[] = [
  {
    id: "asset_context",
    capability: "cmdb.read",
    description: "Get asset criticality, owner, department, OS and EDR agent status",
    paramSpec: { asset: ASSET },
    schema: z.object({ asset: z.string().regex(/^[A-Za-z0-9][A-Za-z0-9._-]{1,63}$/) }) as unknown as z.ZodType<Record<string, unknown>>,
    returns: [
      { name: "asset", type: "str" },
      { name: "criticality", type: "str" },
      { name: "owner", type: "str" },
      { name: "department", type: "str" },
      { name: "os", type: "str" },
      { name: "edr_agent_status", type: "str" },
      { name: "tags", type: "list[str]" },
    ],
    typicalLatencyS: 1,
    cost: 1,
    reproducibility: "live_state",
    discriminates: ["Crown-jewel vs. low-value target", "Managed/owned asset vs. unmanaged"],
    source: "cmdb.asset",
    returnsCollection: false,
    bindFromAlert: (a) => ({ asset: a.asset }),
    run: (world, params) => {
      const asset = s(params.asset);
      const record = world.assets[asset];
      if (!record) {
        return {
          data: { asset, criticality: "unknown", owner: "unknown", department: "unknown", os: "unknown", edr_agent_status: "unknown", tags: [] },
          sensor: sensor("cmdb.asset", asset, "unknown", "asset not present in CMDB"),
        };
      }
      return {
        data: { ...record, tags: [...record.tags] },
        sensor: sensor("cmdb.asset", asset, "covered", "CMDB record present"),
      };
    },
  },
  {
    id: "change_calendar_lookup",
    capability: "itsm.read",
    description: "Check for open/scheduled change tickets for an asset in a window",
    paramSpec: { asset: ASSET, window: WINDOW },
    schema: z.object({
      asset: z.string().regex(/^[A-Za-z0-9][A-Za-z0-9._-]{1,63}$/),
      window: z.string().regex(/^[0-9]+(h|d|m)$/),
    }) as unknown as z.ZodType<Record<string, unknown>>,
    returns: [
      { name: "ticket_count", type: "int" },
      { name: "tickets", type: "list[dict]" },
      { name: "open_ticket_covering_event", type: "bool" },
    ],
    typicalLatencyS: 2,
    cost: 1,
    reproducibility: "point_in_time",
    discriminates: ["Scheduled work vs. unscheduled intrusion activity"],
    source: "itsm.change",
    returnsCollection: true,
    bindFromAlert: (a) => ({ asset: a.asset, window: "7d" }),
    run: (world, params) => {
      const asset = s(params.asset);
      const tickets = world.changeTickets.filter((t) => t.asset === asset && t.status !== "closed");
      return {
        data: {
          ticket_count: tickets.length,
          tickets,
          open_ticket_covering_event: tickets.some((t) => t.covers_event),
        },
        sensor: sensor("itsm.change", asset, "covered", "ITSM change calendar reachable"),
      };
    },
  },
  {
    id: "hash_fleet_occurrence",
    capability: "siem.search",
    description: "Count how many hosts executed a given file hash in a time window",
    paramSpec: { hash: HASH, window: WINDOW },
    schema: z.object({
      hash: z.string().regex(/^[a-f0-9]{64}$/),
      window: z.string().regex(/^[0-9]+(h|d|m)$/),
    }) as unknown as z.ZodType<Record<string, unknown>>,
    returns: [
      { name: "occurrence_count", type: "int" },
      { name: "host_list", type: "list[str]" },
      { name: "distinct_hosts", type: "int" },
      { name: "first_seen", type: "str" },
      { name: "last_seen", type: "str" },
    ],
    typicalLatencyS: 8,
    cost: 2,
    reproducibility: "point_in_time",
    discriminates: ["IT automation (fleet-wide) vs. single-host malware", "Known tooling vs. novel payload"],
    source: "siem.process_event",
    returnsCollection: true,
    bindFromAlert: (a) => (a.fileHash ? { hash: a.fileHash, window: "24h" } : null),
    run: (world, params) => {
      const hash = s(params.hash);
      const asset = s(params.asset, "fleet");
      const record = world.hashFleet[hash];
      if (!record) {
        return {
          data: { occurrence_count: 0, host_list: [], distinct_hosts: 0, first_seen: null, last_seen: null },
          sensor: sensor("siem.process_event", asset, "covered", "SIEM search completed, no executions observed"),
        };
      }
      return {
        data: {
          occurrence_count: record.occurrence_count,
          host_list: [...record.host_list],
          distinct_hosts: record.distinct_hosts,
          first_seen: record.first_seen,
          last_seen: record.last_seen,
        },
        sensor: sensor("siem.process_event", asset, "covered", `SIEM search completed over ${s(params.window, "24h")}`),
      };
    },
  },
  {
    id: "edr_process_tree",
    capability: "edr.read",
    description: "Get parent process, session, signature and command line for a PID",
    paramSpec: { asset: ASSET, pid: { type: "integer", required: true, description: "OS process id" } },
    schema: z.object({
      asset: z.string().regex(/^[A-Za-z0-9][A-Za-z0-9._-]{1,63}$/),
      pid: z.number().int().positive(),
    }) as unknown as z.ZodType<Record<string, unknown>>,
    returns: [
      { name: "found", type: "bool" },
      { name: "parent_process_name", type: "str" },
      { name: "parent_command_line", type: "str" },
      { name: "user", type: "str" },
      { name: "integrity_level", type: "str" },
      { name: "signature_valid", type: "bool" },
      { name: "module_load_count", type: "int" },
      { name: "suspicious_module_count", type: "int" },
      { name: "correlated_sources", type: "list[str]" },
    ],
    typicalLatencyS: 3,
    cost: 1,
    reproducibility: "live_state",
    discriminates: ["Office/mail parent vs. scheduler/service parent", "In-memory dumping modules vs. normal modules"],
    source: "edr.process_event",
    returnsCollection: false,
    bindFromAlert: (a) => (a.pid ? { asset: a.asset, pid: a.pid } : null),
    run: (world, params) => {
      const asset = s(params.asset);
      const pid = n(params.pid);
      const record = world.processTrees[asset];
      if (!record || record.pid !== pid) {
        return {
          data: {
            found: false,
            pid,
            process_name: null,
            parent_process_name: null,
            parent_command_line: null,
            user: null,
            session_id: null,
            integrity_level: null,
            signature_valid: false,
            module_load_count: 0,
            suspicious_module_count: 0,
            modules: [],
            correlated_sources: [],
          },
          sensor: sensor("edr.process_event", asset, "unknown", "no EDR process event for this PID"),
        };
      }
      return {
        data: { ...record, modules: [...record.modules], correlated_sources: [...record.correlated_sources] },
        sensor: sensor("edr.process_event", asset, "covered", "EDR process telemetry present for this PID"),
      };
    },
  },
  {
    id: "edr_heartbeat_check",
    capability: "edr.read",
    description: "Confirm EDR agent was active during a time window (coverage proof)",
    paramSpec: { asset: ASSET, window: WINDOW },
    schema: z.object({
      asset: z.string().regex(/^[A-Za-z0-9][A-Za-z0-9._-]{1,63}$/),
      window: z.string().regex(/^[0-9]+(h|d|m)$/),
    }) as unknown as z.ZodType<Record<string, unknown>>,
    returns: [
      { name: "agent_status", type: "str" },
      { name: "expected_intervals", type: "int" },
      { name: "observed_intervals", type: "int" },
      { name: "coverage_pct", type: "float" },
      { name: "gap_covering_event", type: "bool" },
      { name: "gap_minutes", type: "int" },
    ],
    typicalLatencyS: 2,
    cost: 1,
    reproducibility: "point_in_time",
    discriminates: ["Sensor was watching vs. sensor was blind vs. sensor was silenced"],
    source: "edr.heartbeat",
    returnsCollection: false,
    bindFromAlert: (a) => ({ asset: a.asset, window: "1h" }),
    run: (world, params) => {
      const asset = s(params.asset);
      const record = world.heartbeats[asset];
      if (!record) {
        return {
          data: { agent_status: "offline", expected_intervals: 60, observed_intervals: 0, coverage_pct: 0, gap_covering_event: null, gap_minutes: 0 },
          sensor: sensor("edr.heartbeat", asset, "uncovered", "no heartbeat data retained for this asset"),
        };
      }
      const status = record.agent_status === "online" ? "covered" : record.agent_status === "offline" ? "uncovered" : "unknown";
      return {
        data: { ...record },
        sensor: sensor(
          "edr.heartbeat",
          asset,
          status,
          `agent ${record.agent_status}, ${(record.coverage_pct * 100).toFixed(0)}% of expected cadence`,
        ),
      };
    },
  },
  {
    id: "idp_signin_lookup",
    capability: "idp.read",
    description: "Get IdP sign-in events for a user in a window",
    paramSpec: { user: USER, window: WINDOW },
    schema: z.object({
      user: z.string().regex(/^[A-Za-z0-9][A-Za-z0-9._@-]{1,63}$/),
      window: z.string().regex(/^[0-9]+(h|d|m)$/),
    }) as unknown as z.ZodType<Record<string, unknown>>,
    returns: [
      { name: "event_count", type: "int" },
      { name: "interactive_count", type: "int" },
      { name: "mfa_used", type: "bool" },
      { name: "new_country", type: "bool" },
      { name: "impossible_travel", type: "bool" },
      { name: "client_app", type: "str" },
      { name: "pipeline_health", type: "str" },
    ],
    typicalLatencyS: 4,
    cost: 1,
    reproducibility: "point_in_time",
    discriminates: ["Interactive MFA session vs. service principal", "Baseline geography vs. impossible travel"],
    source: "idp.logon",
    returnsCollection: true,
    bindFromAlert: (a) => (a.user ? { user: a.user, window: "24h" } : null),
    run: (world, params) => {
      const user = s(params.user);
      const record = world.idp[user];
      if (!record) {
        return {
          data: { event_count: 0, interactive_count: 0, mfa_used: false, new_country: false, impossible_travel: false, client_app: null, pipeline_health: "unknown", events: [] },
          sensor: sensor("idp.logon", user, "unknown", "no IdP events retained for this identity"),
        };
      }
      return {
        data: { ...record, events: record.events.map((e) => ({ ...e })) },
        sensor: sensor(
          "idp.logon",
          user,
          record.pipeline_health === "healthy" ? "covered" : "unknown",
          `IdP pipeline ${record.pipeline_health}`,
        ),
      };
    },
  },
  {
    id: "dns_resolution_lookup",
    capability: "network.read",
    description: "Get DNS resolutions from a host in a window",
    paramSpec: { asset: ASSET, window: WINDOW },
    schema: z.object({
      asset: z.string().regex(/^[A-Za-z0-9][A-Za-z0-9._-]{1,63}$/),
      window: z.string().regex(/^[0-9]+(h|d|m)$/),
    }) as unknown as z.ZodType<Record<string, unknown>>,
    returns: [
      { name: "sensor_status", type: "str" },
      { name: "resolution_count", type: "int" },
      { name: "new_domain_count", type: "int" },
      { name: "suspicious_domain_count", type: "int" },
      { name: "resolutions", type: "list[dict]" },
    ],
    typicalLatencyS: 5,
    cost: 1,
    reproducibility: "point_in_time",
    discriminates: ["C2/exfil domains vs. corporate/CDN lookups", "Sensor blind spot vs. genuine absence of lookups"],
    source: "dns.resolution",
    returnsCollection: true,
    bindFromAlert: (a) => ({ asset: a.asset, window: "1h" }),
    run: (world, params) => {
      const asset = s(params.asset);
      const record = world.dns[asset];
      const status = !record || record.sensor_status === "error" ? "unknown" : record?.sensor_status === "no_collector" ? "uncovered" : "covered";
      if (!record) {
        return {
          data: { sensor_status: "error", resolution_count: 0, new_domain_count: 0, suspicious_domain_count: 0, resolutions: [] },
          sensor: sensor("dns.resolution", asset, "unknown", "DNS query endpoint errored"),
        };
      }
      return {
        data: { ...record, resolutions: record.resolutions.map((r) => ({ ...r })) },
        sensor: sensor(
          "dns.resolution",
          asset,
          status,
          record.sensor_status === "collecting" ? "DNS collector active on this segment" : "no DNS collector deployed for this asset",
        ),
      };
    },
  },
  {
    id: "proxy_egress_lookup",
    capability: "network.read",
    description: "Get proxy egress logs for a host in a window",
    paramSpec: { asset: ASSET, window: WINDOW },
    schema: z.object({
      asset: z.string().regex(/^[A-Za-z0-9][A-Za-z0-9._-]{1,63}$/),
      window: z.string().regex(/^[0-9]+(h|d|m)$/),
    }) as unknown as z.ZodType<Record<string, unknown>>,
    returns: [
      { name: "sensor_status", type: "str" },
      { name: "flow_count", type: "int" },
      { name: "egress_to_raw_ip", type: "bool" },
      { name: "category_summary", type: "dict" },
      { name: "flows", type: "list[dict]" },
    ],
    typicalLatencyS: 5,
    cost: 1,
    reproducibility: "point_in_time",
    discriminates: ["Stager download from raw IP vs. sanctioned SaaS", "No egress vs. blind proxy"],
    source: "proxy.egress",
    returnsCollection: true,
    bindFromAlert: (a) => ({ asset: a.asset, window: "1h" }),
    run: (world, params) => {
      const asset = s(params.asset);
      const record = world.proxy[asset];
      const status = !record || record.sensor_status === "error" ? "unknown" : record?.sensor_status === "no_collector" ? "uncovered" : "covered";
      if (!record) {
        return {
          data: { sensor_status: "error", flow_count: 0, egress_to_raw_ip: false, category_summary: {}, flows: [] },
          sensor: sensor("proxy.egress", asset, "unknown", "proxy query endpoint errored"),
        };
      }
      return {
        data: { ...record, flows: record.flows.map((f) => ({ ...f })), category_summary: { ...record.category_summary } },
        sensor: sensor(
          "proxy.egress",
          asset,
          status,
          record.sensor_status === "collecting" ? "proxy logs present for this asset" : "asset bypasses the corporate proxy",
        ),
      };
    },
  },
];

export const REGISTRY: Record<string, QueryTemplate> = Object.fromEntries(TEMPLATES.map((t) => [t.id, t]));

export function allTemplates(): QueryTemplate[] {
  return [...TEMPLATES];
}

export function getTemplate(id: string): QueryTemplate | undefined {
  return REGISTRY[id];
}

export interface ValidationResult {
  ok: boolean;
  templateId: string;
  params: Record<string, unknown>;
  errors: string[];
}

/** §13.1: validate params against the template schema before execution. */
export function validateParams(templateId: string, params: Record<string, unknown>): ValidationResult {
  const template = getTemplate(templateId);
  if (!template) {
    return { ok: false, templateId, params, errors: [`unknown template id: ${templateId}`] };
  }
  const parsed = template.schema.safeParse(params);
  if (parsed.success) {
    return { ok: true, templateId, params: parsed.data, errors: [] };
  }
  return {
    ok: false,
    templateId,
    params,
    errors: parsed.error.issues.map((i) => `${i.path.join(".") || "params"}: ${i.message}`),
  };
}

/** Pure mock execution (no budget, no tracing) — used by the coverage map. */
export function runMock(templateId: string, world: MockWorld, params: Record<string, unknown>): MockResult | null {
  const template = getTemplate(templateId);
  if (!template) return null;
  const validation = validateParams(templateId, params);
  if (!validation.ok) return null;
  return template.run(world, validation.params);
}
