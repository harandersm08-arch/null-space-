/** Runtime settings (mirrors config/settings.yaml from the spec). */

export const SETTINGS = {
  version: "nullspace-phase-3",
  alertClass: "process_execution.suspicious_powershell",
  verdict: {
    benignThreshold: 0.75,
    maliciousThreshold: 0.4,
    minCorroboration: 2,
    minQueriesForIndeterminate: 3,
  },
  budget: {
    maxQueries: 12,
    maxWallMs: 30000,
    maxCostUsd: 0.5,
    minIgThreshold: 0.05,
  },
  ig: {
    lambdaLatencyPerSecond: 0.01,
    muCostPerUnit: 0.05,
    noveltyListBonus: 0.2,
    noveltySourceBonus: 0.1,
    coverageBonus: { hard: 0.3, soft: 0.16, conditional: 0.1 },
    conditionalMetWeight: 1.0,
    conditionalUnmetWeight: 0,
    softWeight: 0.4,
    hardWeight: 1.0,
  },
  posterior: {
    confirmHard: 3.0,
    confirmSoft: 1.5,
    violateSoft: 0.5,
    unobservable: 0.8,
    floor: 0.001,
  },
  priors: {
    baseMaliciousRate: 0.18,
    criticalAssetMaliciousBoost: 0.05,
    changeWindowBoost: 0.15,
    generativePrior: 0.05,
    historyClusterPrior: 0.2,
  },
  coverage: {
    edrCoveredPct: 0.9,
  },
  history: {
    recurringWindowDays: 30,
    recurringMinCases: 3,
  },
  llm: {
    hypothesisModel: "gpt-4o-mini",
    reasoningModel: "gpt-4o",
    enabled: true,
    maxGenerativeHypotheses: 2,
  },
} as const;

export const VERDICT_LABELS: Record<string, string> = {
  benign: "Benign — falsified",
  benign_noisy: "Benign — recurring noise",
  suspicious: "Suspicious — corroborated",
  confirmed: "Confirmed — canary tripped",
  tamper_suspected: "Tamper suspected",
  indeterminate: "Indeterminate",
};
