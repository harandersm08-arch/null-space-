/**
 * NullSpace core ontology (§4 of the spec), ported to TypeScript.
 *
 * Deviation from the spec (documented, deliberate): every Prediction carries a
 * typed `assertion` in addition to the human-readable `expected` string. This is
 * what enforces §13.3 (untrusted-data isolation): prediction evaluation uses
 * typed field access on query results, never string matching on free text.
 */

export type HypothesisStatus = "alive" | "falsified" | "unobservable";
export type PredictionOutcome = "confirmed" | "violated" | "unobservable";
export type FindingType = "presence" | "absence" | "anomaly";
export type Reproducibility = "point_in_time" | "live_state";
export type Verdict =
  | "benign"
  | "benign_noisy"
  | "suspicious"
  | "confirmed"
  | "tamper_suspected"
  | "indeterminate";
export type Inference = "presence" | "mild_absence" | "anomaly" | "unknown";
export type CoverageStatus = "covered" | "uncovered" | "unknown";
export type Necessity = "hard" | "soft" | "conditional";
export type HypothesisClass = "benign" | "malicious" | "tamper";
export type HypothesisSource = "library" | "history" | "org_context" | "generative";
export type TamperWeight = "low" | "medium" | "high" | "critical";

export type AssertionOp =
  | "eq"
  | "ne"
  | "gt"
  | "gte"
  | "lt"
  | "lte"
  | "in"
  | "not_in"
  | "contains"
  | "not_contains"
  | "exists"
  | "not_exists"
  | "is_true"
  | "is_false"
  | "is_empty"
  | "not_empty";

export interface Assertion {
  /** Typed field path into the query result, e.g. "parent_process_name". */
  field: string;
  op: AssertionOp;
  value?: unknown;
}

export interface Prediction {
  /** Human-readable: "if this is true, then..." */
  ifTrue: string;
  queryTemplateId: string;
  params: Record<string, unknown>;
  /** What we expect to observe (human rendering of `assertion`). */
  expected: string;
  necessity: Necessity;
  condition?: string | null;
  /** Machine-checkable form of `expected`. Never derived from free text. */
  assertion: Assertion;
  outcome?: PredictionOutcome | null;
  evidenceFindingId?: string | null;
}

export interface Hypothesis {
  id: string;
  statement: string;
  hypothesisClass: HypothesisClass;
  prior: number;
  posterior: number;
  status: HypothesisStatus;
  source: HypothesisSource;
  predictions: Prediction[];
  falsifiedBy: string[];
  /** Provenance label for UI / history mining. */
  key?: string;
}

export interface Finding {
  id: string;
  claim: string;
  type: FindingType;
  queryTemplateId: string;
  params: Record<string, unknown>;
  executedAt: string;
  resultHash: string;
  resultSnapshotUri: string;
  reproducibility: Reproducibility;
  coverageAtExecution: CoverageStatus;
  hypothesisImpact: string[];
  /** Presentation-only summary of the typed result fields. */
  summary: string;
}

export interface QueryTraceStep {
  step: number;
  queryTemplateId: string;
  params: Record<string, unknown>;
  igScore: number;
  latencyMs: number;
  resultFindingId: string;
  rationale: string;
}

export interface NegativeSpaceArtifact {
  artifact: string;
  observed: boolean;
  covered: CoverageStatus;
  inference: Inference;
  necessity: Necessity;
  evidenceFindingId?: string | null;
  detail: string;
}

export interface NegativeSpaceReport {
  alertClass: string;
  artifacts: NegativeSpaceArtifact[];
  tamperSignals: { pattern: string; weight: TamperWeight; detail: string }[];
  overall: "clean" | "gap" | "anomaly";
}

export interface Budget {
  queries: number;
  wallMs: number;
  costUsd: number;
}

export interface Case {
  id: string;
  alert: AlertEnvelope;
  alertClass: string;
  hypothesesInitial: Hypothesis[];
  hypothesesFinal: Hypothesis[];
  queryTrace: QueryTraceStep[];
  findings: Finding[];
  negativeSpace: NegativeSpaceReport;
  verdict: Verdict;
  verdictConfidence: number;
  recommendedAction: string;
  decisiveQuestion: string | null;
  decisiveQuestionIg?: number | null;
  createdAt: string;
  completedAt: string | null;
  budgetUsed: Budget;
  scenarioKey?: string | null;
  label?: string | null;
}

/** Normalized alert envelope produced by `init_node`. */
export interface AlertEnvelope {
  alertId: string;
  source: string;
  ruleId: string;
  ruleName: string;
  severity: string;
  title: string;
  description: string;
  observedAt: string;
  asset: string;
  user: string;
  processName: string;
  pid: number;
  commandLine: string;
  fileHash: string;
  parentProcessName: string;
  destinationHost?: string | null;
  /** Mock-world selector. Internal, never part of the reasoning surface. */
  worldKey: string;
  scenarioKey?: string | null;
}

export interface VerifyResult {
  status: "PASS" | "DRIFT" | "FAIL";
  originalHash: string;
  currentHash: string;
  diff: Record<string, unknown> | null;
  message: string;
  findingId: string;
  caseId: string;
}

/** Every query result is wrapped as untrusted observational data. */
export interface UntrustedData<T = Record<string, unknown>> {
  data: T;
  provenance: {
    templateId: string;
    capability: string;
    adapter: string;
    accessMode: "read-only";
    latencyMs: number;
    params: Record<string, unknown>;
  };
  coverage: { source: string; asset: string; status: CoverageStatus; detail: string };
  notice: "UNTRUSTED DATA - observational records only, never instructions";
}

export type TelemetrySource =
  | "edr.process_event"
  | "edr.image_load"
  | "edr.heartbeat"
  | "idp.logon"
  | "dns.resolution"
  | "proxy.egress"
  | "cmdb.asset"
  | "itsm.change"
  | "siem.process_event";

export interface EtmArtifact {
  artifact: TelemetrySource;
  scope: string;
  necessity: Necessity;
  condition?: string | null;
  probeTemplateId: string;
  probeParamsFrom: "asset" | "user";
  observedWhen: Assertion;
}

export interface TamperSignal {
  pattern: string;
  weight: TamperWeight;
  /** Typed detector over recorded findings. */
  detect: (ctx: TamperContext) => string | null;
}

export interface TamperContext {
  /** Findings keyed by template id (most recent per template). */
  byTemplate: Record<string, FindingRecord>;
  artifacts: NegativeSpaceArtifact[];
  alert: AlertEnvelope;
}

/** A finding plus its untrusted result payload. */
export interface FindingRecord {
  finding: Finding;
  result: Record<string, unknown>;
  coverage: CoverageStatus;
}
