import { SCENARIOS } from "./world";
import { runCase } from "./engine";
import type { Case, Verdict } from "./types";

/**
 * Golden-case replay (§14). Runs each labelled scenario twice — once with the
 * original alert prose and once with a paraphrase that carries identical
 * structured data — and measures verdict accuracy, sycophancy, query budget and
 * benign-explanation survival.
 */

export interface GoldenResult {
  scenarioKey: string;
  label: string;
  narrative: string;
  expected: string;
  actual: Verdict;
  correct: boolean;
  paraphraseVerdict: Verdict;
  sycophancyFlip: boolean;
  queries: number;
  paraphraseQueries: number;
  findings: number;
  hypotheses: number;
  falsified: number;
  negativeSpace: string;
  tamperSignals: number;
  decisiveQuestion: string | null;
  benignSurvival: boolean | null;
  evidence: { claim: string; type: string; hash: string }[];
}

export interface EvaluationReport {
  total: number;
  correct: number;
  accuracy: number;
  sycophancyRate: number;
  averageQueries: number;
  benignSurvivalRate: number;
  falseNegativeRate: number;
  anomalyFindingDetected: boolean;
  results: GoldenResult[];
}

function localCaseId(): string {
  return `LOCAL-${Math.random().toString(36).slice(2, 10).toUpperCase()}`;
}

export async function runGoldenEvaluation(opts: { useLlm?: boolean; dbCounts?: Record<string, number> } = {}): Promise<EvaluationReport> {
  const counts = opts.dbCounts ?? {};
  const results: GoldenResult[] = [];

  for (const scenario of SCENARIOS) {
    const base = { ...scenario.alert, worldKey: scenario.key, scenarioKey: scenario.key };
    const paraphrased = {
      ...base,
      title: scenario.paraphrase.title,
      description: scenario.paraphrase.description,
    };

    const [original, paraphrase] = await Promise.all([
      runCase(base, { caseId: localCaseId(), label: scenario.verdict, useLlm: opts.useLlm ?? false, dbBenignCaseCounts: counts }),
      runCase(paraphrased, { caseId: localCaseId(), label: scenario.verdict, useLlm: opts.useLlm ?? false, dbBenignCaseCounts: counts }),
    ]);

    const c: Case = original.case;
    const expected = scenario.verdict;
    const actual = c.verdict;
    const isBenignLabel = expected === "benign" || expected === "benign_noisy";

    results.push({
      scenarioKey: scenario.key,
      label: scenario.label,
      narrative: scenario.narrative,
      expected,
      actual,
      correct: actual === expected,
      paraphraseVerdict: paraphrase.case.verdict,
      sycophancyFlip: paraphrase.case.verdict !== actual,
      queries: c.queryTrace.length,
      paraphraseQueries: paraphrase.case.queryTrace.length,
      findings: c.findings.length,
      hypotheses: c.hypothesesFinal.length,
      falsified: c.hypothesesFinal.filter((h) => h.status === "falsified").length,
      negativeSpace: c.negativeSpace.overall,
      tamperSignals: c.negativeSpace.tamperSignals.length,
      decisiveQuestion: c.decisiveQuestion,
      benignSurvival: isBenignLabel ? actual === "benign" || actual === "benign_noisy" : null,
      evidence: c.findings.slice(0, 4).map((f) => ({ claim: f.claim, type: f.type, hash: f.resultHash.slice(0, 16) })),
    });
  }

  const total = results.length;
  const correct = results.filter((r) => r.correct).length;
  const flips = results.filter((r) => r.sycophancyFlip).length;
  const benignLabeled = results.filter((r) => r.benignSurvival !== null);
  const survived = benignLabeled.filter((r) => r.benignSurvival === true).length;
  const maliciousLabeled = results.filter((r) => r.expected === "suspicious" || r.expected === "tamper_suspected");
  const falseNegatives = maliciousLabeled.filter((r) => r.actual === "benign" || r.actual === "benign_noisy").length;

  return {
    total,
    correct,
    accuracy: total ? correct / total : 0,
    sycophancyRate: total ? flips / total : 0,
    averageQueries: total ? results.reduce((s, r) => s + r.queries, 0) / total : 0,
    benignSurvivalRate: benignLabeled.length ? survived / benignLabeled.length : 0,
    falseNegativeRate: maliciousLabeled.length ? falseNegatives / maliciousLabeled.length : 0,
    anomalyFindingDetected: results.some((r) => r.expected === "tamper_suspected" && r.tamperSignals > 0),
    results,
  };
}
