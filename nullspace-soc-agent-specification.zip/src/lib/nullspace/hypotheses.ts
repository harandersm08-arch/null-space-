import type {
  AlertEnvelope,
  Assertion,
  Hypothesis,
  HypothesisClass,
  HypothesisSource,
  Prediction,
} from "./types";
import { SETTINGS } from "./settings";
import { contextFacts } from "./etm";
import { HISTORY_SEED, type MockWorld } from "./world";
import { generateLlmHypotheses } from "./llm";

/**
 * Hypothesis generation (§9) from four sources: curated library, history
 * mining, org context, and a generative fallback. Any hypothesis without at
 * least one falsifiable prediction is discarded (invariant 2).
 */

interface PredictionSpec {
  ifTrue: string;
  queryTemplateId: string;
  params: (alert: AlertEnvelope) => Record<string, unknown> | null;
  expected: string;
  necessity: "hard" | "soft" | "conditional";
  condition?: string;
  assertion: Assertion;
}

interface LibraryEntry {
  key: string;
  statement: string;
  hypothesisClass: HypothesisClass;
  basePrior: number;
  source: HypothesisSource;
  predictions: PredictionSpec[];
  /** Used by LLM-generated entries whose params are already concrete. */
  concretePredictions?: Prediction[];
}

const fleetHash = (a: AlertEnvelope) => ({ hash: a.fileHash, window: "24h" });
const assetParams = (a: AlertEnvelope) => ({ asset: a.asset, window: "1h" });
const changeParams = (a: AlertEnvelope) => ({ asset: a.asset, window: "7d" });
const treeParams = (a: AlertEnvelope) => ({ asset: a.asset, pid: a.pid });
const idpParams = (a: AlertEnvelope) => ({ user: a.user, window: "24h" });

export const HYPOTHESIS_LIBRARY: LibraryEntry[] = [
  {
    key: "fleet_automation",
    statement: "Fleet-wide IT automation (DSC / ConfigMgr / Ansible baseline) executed this script on many hosts.",
    hypothesisClass: "benign",
    basePrior: 0.2,
    source: "library",
    predictions: [
      {
        ifTrue: "If this is fleet automation, the same file hash was executed on many hosts in the last 24h.",
        queryTemplateId: "hash_fleet_occurrence",
        params: fleetHash,
        expected: "occurrence_count >= 5",
        necessity: "hard",
        assertion: { field: "occurrence_count", op: "gte", value: 5 },
      },
      {
        ifTrue: "If this is automation, the parent process is a fleet management agent or service host.",
        queryTemplateId: "edr_process_tree",
        params: treeParams,
        expected: "parent_process_name ∈ [psservice.exe, psexec.exe, ccmexec.exe, ansible.exe, salt-minion.exe, taskeng.exe]",
        necessity: "soft",
        assertion: {
          field: "parent_process_name",
          op: "in",
          value: ["psservice.exe", "psexec.exe", "ccmexec.exe", "ansible.exe", "salt-minion.exe", "taskeng.exe"],
        },
      },
      {
        ifTrue: "If this is automation, an approved change covers the work.",
        queryTemplateId: "change_calendar_lookup",
        params: changeParams,
        expected: "open_ticket_covering_event is true",
        necessity: "soft",
        assertion: { field: "open_ticket_covering_event", op: "is_true" },
      },
    ],
  },
  {
    key: "scheduled_maintenance",
    statement: "The execution is scheduled maintenance covered by an approved change ticket.",
    hypothesisClass: "benign",
    basePrior: 0.14,
    source: "library",
    predictions: [
      {
        ifTrue: "If this is scheduled maintenance, an open change ticket covers the alert time.",
        queryTemplateId: "change_calendar_lookup",
        params: changeParams,
        expected: "open_ticket_covering_event is true",
        necessity: "hard",
        assertion: { field: "open_ticket_covering_event", op: "is_true" },
      },
      {
        ifTrue: "If this is maintenance, a scheduler service (not a user session) spawned the process.",
        queryTemplateId: "edr_process_tree",
        params: treeParams,
        expected: "parent_process_name ∈ [taskeng.exe, taskhostw.exe, svchost.exe, psservice.exe]",
        necessity: "soft",
        assertion: {
          field: "parent_process_name",
          op: "in",
          value: ["taskeng.exe", "taskhostw.exe", "svchost.exe", "psservice.exe"],
        },
      },
      {
        ifTrue: "If this is offline maintenance, there was no external egress.",
        queryTemplateId: "proxy_egress_lookup",
        params: assetParams,
        expected: "flow_count == 0",
        necessity: "soft",
        assertion: { field: "flow_count", op: "eq", value: 0 },
      },
    ],
  },
  {
    key: "authorized_admin_interactive",
    statement: "An authorized administrator ran a known script interactively from an MFA-authenticated session.",
    hypothesisClass: "benign",
    basePrior: 0.14,
    source: "library",
    predictions: [
      {
        ifTrue: "If an admin ran this, there is an interactive sign-in for the identity.",
        queryTemplateId: "idp_signin_lookup",
        params: idpParams,
        expected: "interactive_count >= 1",
        necessity: "hard",
        assertion: { field: "interactive_count", op: "gte", value: 1 },
      },
      {
        ifTrue: "If an admin ran this, the session was MFA-authenticated.",
        queryTemplateId: "idp_signin_lookup",
        params: idpParams,
        expected: "mfa_used is true",
        necessity: "hard",
        assertion: { field: "mfa_used", op: "is_true" },
      },
      {
        ifTrue: "If an admin ran this, the script is signed.",
        queryTemplateId: "edr_process_tree",
        params: treeParams,
        expected: "signature_valid is true",
        necessity: "soft",
        assertion: { field: "signature_valid", op: "is_true" },
      },
      {
        ifTrue: "If an admin ran this, the tooling is in use elsewhere in the fleet.",
        queryTemplateId: "hash_fleet_occurrence",
        params: fleetHash,
        expected: "occurrence_count >= 2",
        necessity: "soft",
        assertion: { field: "occurrence_count", op: "gte", value: 2 },
      },
    ],
  },
  {
    key: "software_deployment",
    statement: "A desktop-engineering package re-ran a bootstrap script on this endpoint.",
    hypothesisClass: "benign",
    basePrior: 0.1,
    source: "library",
    predictions: [
      {
        ifTrue: "If a package ran, the hash is not unique to this host.",
        queryTemplateId: "hash_fleet_occurrence",
        params: fleetHash,
        expected: "occurrence_count >= 3",
        necessity: "hard",
        assertion: { field: "occurrence_count", op: "gte", value: 3 },
      },
      {
        ifTrue: "If a package ran, the asset belongs to a desktop engineering team.",
        queryTemplateId: "asset_context",
        params: (a) => ({ asset: a.asset }),
        expected: "department ∈ [IT Operations, End User Computing, Workplace Services, Infrastructure]",
        necessity: "soft",
        assertion: {
          field: "department",
          op: "in",
          value: ["IT Operations", "End User Computing", "Workplace Services", "Infrastructure"],
        },
      },
    ],
  },
  {
    key: "service_account_batch",
    statement: "The process belongs to a non-interactive service account batch job.",
    hypothesisClass: "benign",
    basePrior: 0.12,
    source: "library",
    predictions: [
      {
        ifTrue: "If this is a batch identity, its IdP client is a service principal or daemon.",
        queryTemplateId: "idp_signin_lookup",
        params: idpParams,
        expected: "client_app ∈ [service_principal, daemon]",
        necessity: "hard",
        assertion: { field: "client_app", op: "in", value: ["service_principal", "daemon"] },
      },
      {
        ifTrue: "If this is a batch job, it runs at System integrity.",
        queryTemplateId: "edr_process_tree",
        params: treeParams,
        expected: "integrity_level == System",
        necessity: "soft",
        assertion: { field: "integrity_level", op: "eq", value: "System" },
      },
      {
        ifTrue: "If this is a batch job, the session is a local system session.",
        queryTemplateId: "edr_process_tree",
        params: treeParams,
        expected: "session_id == S-1-5-18",
        necessity: "soft",
        assertion: { field: "session_id", op: "eq", value: "S-1-5-18" },
      },
    ],
  },
  {
    key: "vulnerability_scanner",
    statement: "The process is scanner / security tooling running on a designated scan asset.",
    hypothesisClass: "benign",
    basePrior: 0.05,
    source: "library",
    predictions: [
      {
        ifTrue: "If this is a scanner, the asset is tagged as one.",
        queryTemplateId: "asset_context",
        params: (a) => ({ asset: a.asset }),
        expected: "tags contains 'scanner'",
        necessity: "hard",
        assertion: { field: "tags", op: "contains", value: "scanner" },
      },
      {
        ifTrue: "If this is a scanner, the tooling appears on multiple hosts.",
        queryTemplateId: "hash_fleet_occurrence",
        params: fleetHash,
        expected: "occurrence_count >= 3",
        necessity: "soft",
        assertion: { field: "occurrence_count", op: "gte", value: 3 },
      },
    ],
  },
  {
    key: "rule_overfire",
    statement: "The detection rule over-fires on this well-understood administrative pattern (tuning defect).",
    hypothesisClass: "benign",
    basePrior: 0.08,
    source: "history",
    predictions: [
      {
        ifTrue: "If the rule over-fires, the same hash recurs across the fleet.",
        queryTemplateId: "hash_fleet_occurrence",
        params: fleetHash,
        expected: "occurrence_count >= 2",
        necessity: "soft",
        assertion: { field: "occurrence_count", op: "gte", value: 2 },
      },
      {
        ifTrue: "If the rule over-fires, the host is healthy and managed.",
        queryTemplateId: "asset_context",
        params: (a) => ({ asset: a.asset }),
        expected: "edr_agent_status == online",
        necessity: "soft",
        assertion: { field: "edr_agent_status", op: "eq", value: "online" },
      },
      {
        ifTrue: "If the rule over-fires, no suspicious modules were loaded.",
        queryTemplateId: "edr_process_tree",
        params: treeParams,
        expected: "suspicious_module_count == 0",
        necessity: "soft",
        assertion: { field: "suspicious_module_count", op: "eq", value: 0 },
      },
    ],
  },
  {
    key: "download_cradle_stager",
    statement: "A document or macro spawned a PowerShell download cradle that retrieved a stager.",
    hypothesisClass: "malicious",
    basePrior: 0.12,
    source: "library",
    predictions: [
      {
        ifTrue: "If this is a cradle, the host resolved suspicious domains.",
        queryTemplateId: "dns_resolution_lookup",
        params: assetParams,
        expected: "suspicious_domain_count >= 1",
        necessity: "hard",
        assertion: { field: "suspicious_domain_count", op: "gte", value: 1 },
      },
      {
        ifTrue: "If this is a cradle, the host egressed to a raw IP address.",
        queryTemplateId: "proxy_egress_lookup",
        params: assetParams,
        expected: "egress_to_raw_ip is true",
        necessity: "hard",
        assertion: { field: "egress_to_raw_ip", op: "is_true" },
      },
      {
        ifTrue: "If this is a cradle, the payload is novel (single host).",
        queryTemplateId: "hash_fleet_occurrence",
        params: fleetHash,
        expected: "occurrence_count == 1",
        necessity: "hard",
        assertion: { field: "occurrence_count", op: "eq", value: 1 },
      },
      {
        ifTrue: "If this is a cradle, an Office/mail application is the parent.",
        queryTemplateId: "edr_process_tree",
        params: treeParams,
        expected: "parent_process_name ∈ [winword.exe, excel.exe, powerpnt.exe, outlook.exe, acrord32.exe]",
        necessity: "soft",
        assertion: {
          field: "parent_process_name",
          op: "in",
          value: ["winword.exe", "excel.exe", "powerpnt.exe", "outlook.exe", "acrord32.exe"],
        },
      },
      {
        ifTrue: "If this is a cradle, several domains are seen for the first time.",
        queryTemplateId: "dns_resolution_lookup",
        params: assetParams,
        expected: "new_domain_count >= 2",
        necessity: "soft",
        assertion: { field: "new_domain_count", op: "gte", value: 2 },
      },
    ],
  },
  {
    key: "credential_dump_lateral",
    statement: "The process dumped credentials or moved laterally using stolen tokens.",
    hypothesisClass: "malicious",
    basePrior: 0.1,
    source: "library",
    predictions: [
      {
        ifTrue: "If credentials were dumped, the EDR observed credential-access modules.",
        queryTemplateId: "edr_process_tree",
        params: treeParams,
        expected: "suspicious_module_count >= 1",
        necessity: "hard",
        assertion: { field: "suspicious_module_count", op: "gte", value: 1 },
      },
      {
        ifTrue: "If tokens were stolen, the identity shows impossible travel.",
        queryTemplateId: "idp_signin_lookup",
        params: idpParams,
        expected: "impossible_travel is true",
        necessity: "soft",
        assertion: { field: "impossible_travel", op: "is_true" },
      },
      {
        ifTrue: "If tokens were stolen, the identity signed in from a new country.",
        queryTemplateId: "idp_signin_lookup",
        params: idpParams,
        expected: "new_country is true",
        necessity: "soft",
        assertion: { field: "new_country", op: "is_true" },
      },
    ],
  },
  {
    key: "edr_sensor_tamper",
    statement: "The endpoint sensor was silenced or its telemetry suppressed around the event.",
    hypothesisClass: "tamper",
    basePrior: 0.06,
    source: "library",
    predictions: [
      {
        ifTrue: "If the sensor was silenced, there is a heartbeat gap straddling the event.",
        queryTemplateId: "edr_heartbeat_check",
        params: assetParams,
        expected: "gap_covering_event is true",
        necessity: "hard",
        assertion: { field: "gap_covering_event", op: "is_true" },
      },
      {
        ifTrue: "If the sensor was degraded, cadence dropped below 90%.",
        queryTemplateId: "edr_heartbeat_check",
        params: assetParams,
        expected: "coverage_pct < 0.9",
        necessity: "soft",
        assertion: { field: "coverage_pct", op: "lt", value: 0.9 },
      },
      {
        ifTrue: "If telemetry was suppressed, the EDR has no process event for the PID.",
        queryTemplateId: "edr_process_tree",
        params: treeParams,
        expected: "found is false",
        necessity: "hard",
        assertion: { field: "found", op: "is_false" },
      },
    ],
  },
];

/** H0: the malicious default is always present (§9). */
const H0_ENTRY: LibraryEntry = {
  key: "generic_intrusion",
  statement: "Unspecified intrusion activity: the alert reflects genuine attacker behaviour on this host.",
  hypothesisClass: "malicious",
  basePrior: SETTINGS.priors.baseMaliciousRate,
  source: "library",
  predictions: [
    {
      ifTrue: "If this is an intrusion, the host egressed to a raw IP address.",
      queryTemplateId: "proxy_egress_lookup",
      params: assetParams,
      expected: "egress_to_raw_ip is true",
      necessity: "hard",
      assertion: { field: "egress_to_raw_ip", op: "is_true" },
    },
    {
      ifTrue: "If this is an intrusion, the executed code is unsigned.",
      queryTemplateId: "edr_process_tree",
      params: treeParams,
      expected: "signature_valid is false",
      necessity: "soft",
      assertion: { field: "signature_valid", op: "is_false" },
    },
    {
      ifTrue: "If this is an intrusion, the host touched domains not seen before.",
      queryTemplateId: "dns_resolution_lookup",
      params: assetParams,
      expected: "new_domain_count >= 2",
      necessity: "soft",
      assertion: { field: "new_domain_count", op: "gte", value: 2 },
    },
  ],
};

export interface OrgContext {
  hasChangeWindow: boolean;
  changeTicketId: string | null;
  hasServiceAccount: boolean;
  assetCriticality: string;
  baseMaliciousRate: number;
}

export function orgContextFor(alert: AlertEnvelope, world: MockWorld): OrgContext {
  const ticket = world.changeTickets.find((t) => t.asset === alert.asset && t.status !== "closed" && t.covers_event);
  const idp = world.idp[alert.user];
  const facts = contextFacts(alert);
  return {
    hasChangeWindow: Boolean(ticket),
    changeTicketId: ticket?.id ?? null,
    hasServiceAccount: facts.executingUserIsServiceAccount || idp?.client_app === "service_principal" || idp?.client_app === "daemon",
    assetCriticality: world.assets[alert.asset]?.criticality ?? "unknown",
    baseMaliciousRate: SETTINGS.priors.baseMaliciousRate,
  };
}

export interface HistoryCluster {
  cluster: string;
  resolution: string;
  cases: number;
  label: string;
}

/** Source 2: cluster past resolutions into reusable hypotheses. */
export function historyClusters(alertClass: string, extraCounts: Record<string, number> = {}): HistoryCluster[] {
  return HISTORY_SEED.filter((h) => h.alert_class === alertClass).map((h) => ({
    cluster: h.cluster,
    resolution: h.resolution,
    cases: h.cases + (extraCounts[h.cluster] ?? 0),
    label: h.label,
  }));
}

function buildPredictions(entry: LibraryEntry, alert: AlertEnvelope): Prediction[] {
  if (entry.concretePredictions) return entry.concretePredictions.map((p) => ({ ...p }));
  const out: Prediction[] = [];
  for (const spec of entry.predictions) {
    const params = spec.params(alert);
    if (!params) continue;
    out.push({
      ifTrue: spec.ifTrue,
      queryTemplateId: spec.queryTemplateId,
      params,
      expected: spec.expected,
      necessity: spec.necessity,
      condition: spec.condition ?? null,
      assertion: spec.assertion,
      outcome: null,
      evidenceFindingId: null,
    });
  }
  return out;
}

export function makeHypothesis(
  id: string,
  entry: LibraryEntry,
  alert: AlertEnvelope,
  priorOverride?: number,
): Hypothesis {
  return {
    id,
    statement: entry.statement,
    hypothesisClass: entry.hypothesisClass,
    prior: priorOverride ?? entry.basePrior,
    posterior: priorOverride ?? entry.basePrior,
    status: "alive",
    source: entry.source,
    predictions: buildPredictions(entry, alert),
    falsifiedBy: [],
    key: entry.key,
  };
}

/** Source 3: org-context hypotheses. */
function orgContextHypotheses(alert: AlertEnvelope, org: OrgContext): LibraryEntry[] {
  const entries: LibraryEntry[] = [];
  if (org.hasChangeWindow) {
    entries.push({
      key: "org_change_window",
      statement: `Org context: an approved change window (${org.changeTicketId}) is open for this asset right now.`,
      hypothesisClass: "benign",
      basePrior: 0.16,
      source: "org_context",
      predictions: [
        {
          ifTrue: "If a change window is open, the ITSM calendar shows a covering ticket.",
          queryTemplateId: "change_calendar_lookup",
          params: changeParams,
          expected: "open_ticket_covering_event is true",
          necessity: "hard",
          assertion: { field: "open_ticket_covering_event", op: "is_true" },
        },
        {
          ifTrue: "If a change window is open, the executing identity matches the change owner.",
          queryTemplateId: "idp_signin_lookup",
          params: idpParams,
          expected: "client_app ∈ [service_principal, daemon]",
          necessity: "soft",
          assertion: { field: "client_app", op: "in", value: ["service_principal", "daemon"] },
        },
      ],
    });
  }
  if (org.hasServiceAccount) {
    entries.push({
      key: "org_service_account",
      statement: "Org context: this identity is a registered service account in the directory.",
      hypothesisClass: "benign",
      basePrior: 0.13,
      source: "org_context",
      predictions: [
        {
          ifTrue: "If this is a registered service identity, its IdP client is non-interactive.",
          queryTemplateId: "idp_signin_lookup",
          params: idpParams,
          expected: "client_app ∈ [service_principal, daemon]",
          necessity: "hard",
          assertion: { field: "client_app", op: "in", value: ["service_principal", "daemon"] },
        },
      ],
    });
  }
  return entries;
}

/** Source 4: heuristic generative fallback (used when no LLM key is present). */
function heuristicGenerative(alert: AlertEnvelope): LibraryEntry[] {
  const entries: LibraryEntry[] = [];
  if (/vendor|contractor|extern/i.test(alert.user)) {
    entries.push({
      key: "gen_vendor_tooling",
      statement: "Generative: a vendor/contractor ran their own unsigned toolkit on this endpoint.",
      hypothesisClass: "benign",
      basePrior: SETTINGS.priors.generativePrior,
      source: "generative",
      predictions: [
        {
          ifTrue: "If a contractor ran vendor tooling, the session is interactive and MFA-authenticated.",
          queryTemplateId: "idp_signin_lookup",
          params: idpParams,
          expected: "interactive_count >= 1 and mfa_used is true",
          necessity: "soft",
          assertion: { field: "interactive_count", op: "gte", value: 1 },
        },
      ],
    });
  }
  if (/updater|update|bootstrap|setup/i.test(alert.commandLine)) {
    entries.push({
      key: "gen_software_updater",
      statement: "Generative: a third-party software updater re-ran its bootstrap script.",
      hypothesisClass: "benign",
      basePrior: SETTINGS.priors.generativePrior,
      source: "generative",
      predictions: [
        {
          ifTrue: "If an updater ran, its egress is limited to sanctioned update endpoints.",
          queryTemplateId: "proxy_egress_lookup",
          params: assetParams,
          expected: "egress_to_raw_ip is false",
          necessity: "hard",
          assertion: { field: "egress_to_raw_ip", op: "is_false" },
        },
      ],
    });
  }
  return entries;
}

export function deduplicate(hypotheses: Hypothesis[]): Hypothesis[] {
  const seen = new Set<string>();
  const out: Hypothesis[] = [];
  for (const h of hypotheses) {
    const signature = [
      h.statement.trim().toLowerCase(),
      ...h.predictions.map((p) => p.queryTemplateId).sort(),
    ].join("|");
    if (seen.has(signature)) continue;
    seen.add(signature);
    out.push(h);
  }
  return out;
}

export interface GenerationContext {
  alert: AlertEnvelope;
  alertClass: string;
  world: MockWorld;
  org: OrgContext;
  historyClusters: HistoryCluster[];
  historyCaseCounts: Record<string, number>;
  useLlm: boolean;
}

export async function generateHypotheses(ctx: GenerationContext): Promise<{
  hypotheses: Hypothesis[];
  llmUsed: boolean;
  llmError: string | null;
}> {
  const { alert, org } = ctx;
  let llmUsed = false;
  let llmError: string | null = null;

  const entries: LibraryEntry[] = [...HYPOTHESIS_LIBRARY, H0_ENTRY];
  entries.push(...orgContextHypotheses(alert, org));
  entries.push(...heuristicGenerative(alert));

  if (ctx.useLlm) {
    try {
      const generated = await generateLlmHypotheses({
        alert,
        existing: entries.map((e) => e.statement),
        templateIds: ["asset_context", "change_calendar_lookup", "hash_fleet_occurrence", "edr_process_tree", "edr_heartbeat_check", "idp_signin_lookup", "dns_resolution_lookup", "proxy_egress_lookup"],
      });
      llmUsed = generated.length > 0;
      for (const g of generated) {
        entries.push({
          key: g.key,
          statement: g.statement,
          hypothesisClass: "benign",
          basePrior: SETTINGS.priors.generativePrior,
          source: "generative",
          predictions: [],
          concretePredictions: g.predictions.map((p) => ({
            ifTrue: p.ifTrue,
            queryTemplateId: p.queryTemplateId,
            params: p.params,
            expected: p.expected,
            necessity: p.necessity,
            condition: null,
            assertion: p.assertion,
            outcome: null,
            evidenceFindingId: null,
          })),
        });
      }
    } catch (error) {
      llmError = error instanceof Error ? error.message : String(error);
    }
  }

  let hypotheses = entries
    .map((entry, index) => makeHypothesis(`H${index + 1}`, entry, alert))
    .filter((h) => h.predictions.length > 0);

  hypotheses = deduplicate(hypotheses);
  hypotheses = assignPriors(hypotheses, org, ctx.historyClusters);
  return { hypotheses, llmUsed, llmError };
}

/** Prior assignment rules (§9). */
export function assignPriors(hypotheses: Hypothesis[], org: OrgContext, clusters: HistoryCluster[]): Hypothesis[] {
  const clusterCases: Record<string, number> = {};
  for (const c of clusters) clusterCases[c.cluster] = c.cases;

  for (const h of hypotheses) {
    let prior = h.prior;
    if (h.key && clusterCases[h.key]) {
      const support = Math.min(0.12, clusterCases[h.key] / 400);
      prior += support;
    }
    if (h.key === "scheduled_maintenance" && org.hasChangeWindow) prior += SETTINGS.priors.changeWindowBoost;
    if (h.key === "org_change_window" && org.hasChangeWindow) prior += SETTINGS.priors.changeWindowBoost;
    if (h.key === "org_service_account" && org.hasServiceAccount) prior += 0.05;
    if (h.hypothesisClass === "malicious" && org.assetCriticality === "critical") {
      prior += SETTINGS.priors.criticalAssetMaliciousBoost;
    }
    if (h.source === "generative") prior = Math.max(prior, SETTINGS.priors.generativePrior);
    h.prior = Number(prior.toFixed(4));
    h.posterior = h.prior;
  }

  const total = hypotheses.reduce((sum, h) => sum + h.prior, 0) || 1;
  for (const h of hypotheses) {
    h.prior = Number((h.prior / total).toFixed(4));
    h.posterior = h.prior;
  }
  return hypotheses;
}

export function isRecurringResolution(key: string | undefined, clusters: HistoryCluster[], dbCases = 0): boolean {
  if (!key) return false;
  const cluster = clusters.find((c) => c.cluster === key);
  const cases = (cluster?.cases ?? 0) + dbCases;
  return cluster !== undefined && cases >= 30;
}
