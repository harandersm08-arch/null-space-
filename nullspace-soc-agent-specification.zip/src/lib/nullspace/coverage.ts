import type { CoverageStatus, TelemetrySource } from "./types";
import { runMock } from "./templates";
import type { MockWorld } from "./world";
import { SETTINGS } from "./settings";

/**
 * Coverage map (§7). Answers: was sensor `source` actively monitoring `asset`
 * during `interval`? A heartbeat IS the proof for EDR sources.
 */
export interface CoverageAnswer {
  status: CoverageStatus;
  detail: string;
  coveragePct: number | null;
}

export class CoverageMap {
  constructor(private readonly world: MockWorld) {}

  coverage(source: TelemetrySource, asset: string, interval: [Date, Date] | null): CoverageAnswer {
    if (source.startsWith("edr.")) {
      const hb = runMock("edr_heartbeat_check", this.world, { asset, window: "1h" });
      if (!hb) return { status: "unknown", detail: "heartbeat query could not be executed", coveragePct: null };
      const status = String(hb.data.agent_status);
      const pct = typeof hb.data.coverage_pct === "number" ? hb.data.coverage_pct : null;
      if (status === "online") {
        return {
          status: pct !== null && pct < SETTINGS.coverage.edrCoveredPct ? "covered" : "covered",
          detail: `agent online, ${(Number(pct ?? 0) * 100).toFixed(0)}% of expected heartbeat cadence`,
          coveragePct: pct,
        };
      }
      if (status === "offline") {
        return { status: "uncovered", detail: "EDR agent offline / no heartbeats retained", coveragePct: pct };
      }
      return { status: "unknown", detail: `EDR agent status: ${status}`, coveragePct: pct };
    }

    if (source === "dns.resolution") {
      const dns = runMock("dns_resolution_lookup", this.world, { asset, window: "1h" });
      if (!dns) return { status: "unknown", detail: "DNS query errored", coveragePct: null };
      const st = String(dns.data.sensor_status);
      if (st === "collecting") return { status: "covered", detail: "DNS collector active on this segment", coveragePct: null };
      if (st === "no_collector") return { status: "uncovered", detail: "no DNS collector deployed for this asset", coveragePct: null };
      return { status: "unknown", detail: "DNS sensor status unknown", coveragePct: null };
    }

    if (source === "proxy.egress") {
      const proxy = runMock("proxy_egress_lookup", this.world, { asset, window: "1h" });
      if (!proxy) return { status: "unknown", detail: "proxy query errored", coveragePct: null };
      const st = String(proxy.data.sensor_status);
      if (st === "collecting") return { status: "covered", detail: "proxy logs present for this asset", coveragePct: null };
      if (st === "no_collector") return { status: "uncovered", detail: "asset bypasses the corporate proxy", coveragePct: null };
      return { status: "unknown", detail: "proxy sensor status unknown", coveragePct: null };
    }

    if (source === "idp.logon") {
      // The interval/user pair is resolved by the caller; identity pipeline health
      // is treated as covered unless the world says otherwise.
      return { status: "covered", detail: "IdP pipeline healthy", coveragePct: null };
    }

    if (source === "cmdb.asset" || source === "itsm.change" || source === "siem.process_event") {
      return { status: "covered", detail: `${source} source reachable`, coveragePct: null };
    }

    return { status: "unknown", detail: `no coverage model for ${source}`, coveragePct: null };
  }

  coverageForUser(source: TelemetrySource, user: string): CoverageAnswer {
    if (source === "idp.logon") {
      const idp = runMock("idp_signin_lookup", this.world, { user, window: "24h" });
      if (!idp) return { status: "unknown", detail: "IdP query errored", coveragePct: null };
      const health = String(idp.data.pipeline_health);
      if (health === "healthy") return { status: "covered", detail: "IdP pipeline healthy", coveragePct: null };
      if (health === "degraded") return { status: "unknown", detail: "IdP pipeline degraded", coveragePct: null };
      return { status: "unknown", detail: "IdP pipeline status unknown", coveragePct: null };
    }
    return { status: "unknown", detail: "coverage for identity-scoped sources requires a user", coveragePct: null };
  }
}
