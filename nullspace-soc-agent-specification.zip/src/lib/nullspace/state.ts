import type {
  AlertEnvelope,
  Budget,
  Case,
  CoverageStatus,
  Finding,
  Hypothesis,
  NegativeSpaceReport,
  Prediction,
  Reproducibility,
  Verdict,
} from "./types";
import { canonicalJson } from "./util";
import type { CoverageMap } from "./coverage";
import type { Etm } from "./etm";
import type { OrgContext, HistoryCluster } from "./hypotheses";
import type { MockWorld } from "./world";
import { buildNegativeSpaceReport } from "./negativeSpace";

export interface EngineEvent {
  ts: string;
  kind: "state_transition" | "query" | "llm_call" | "policy" | "verdict" | "coverage";
  name: string;
  attrs: Record<string, unknown>;
  durationMs?: number;
}

export interface PendingQuery {
  templateId: string;
  params: Record<string, unknown>;
  igScore: number;
  rationale: string;
}

export interface EngineState {
  case: Case;
  alert: AlertEnvelope;
  pendingOutcome: import("./executor").ExecOutcome | null;
  extraHypothesisGenerated: boolean;
  world: MockWorld;
  coverageMap: CoverageMap;
  etm: Etm;
  org: OrgContext;
  clusters: HistoryCluster[];
  hypotheses: Hypothesis[];
  findings: { finding: Finding; result: Record<string, unknown>; coverage: CoverageStatus }[];
  runKeys: Set<string>;
  budgetUsed: Budget;
  budgetExhausted: boolean;
  stepCount: number;
  verdict: Verdict | null;
  verdictReason: string | null;
  stopReason: string | null;
  pendingQuery: PendingQuery | null;
  events: EngineEvent[];
  startedAt: number;
  llmUsed: boolean;
  llmError: string | null;
  decisiveQuestion: string | null;
  decisiveQuestionIg: number | null;
  useLlm: boolean;
  dbBenignCaseCounts: Record<string, number>;
}

export function queryKey(templateId: string, params: Record<string, unknown>): string {
  return `${templateId}|${canonicalJson(params)}`;
}

export function predictionKey(p: Prediction): string {
  return queryKey(p.queryTemplateId, p.params);
}

export function liveHypotheses(state: EngineState): Hypothesis[] {
  return state.hypotheses.filter((h) => h.status === "alive");
}

export function refreshNegativeSpace(state: EngineState): NegativeSpaceReport {
  const report = buildNegativeSpaceReport(state.alert, state.etm, state.findings, state.coverageMap);
  state.case.negativeSpace = report;
  return report;
}

export function logEvent(
  state: EngineState,
  kind: EngineEvent["kind"],
  name: string,
  attrs: Record<string, unknown> = {},
  durationMs?: number,
): void {
  state.events.push({ ts: new Date().toISOString(), kind, name, attrs, durationMs });
}
