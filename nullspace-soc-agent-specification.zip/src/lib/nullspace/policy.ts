import type { Budget } from "./types";
import { SETTINGS } from "./settings";

/**
 * Policy gate (§2 OPA role). Implemented as an explicit, auditable policy
 * function rather than a sidecar so the whole engine stays single-process for
 * Phase 1-3. The policy document is the source of truth for the numbers.
 *
 * policy nullspace.budget.v1 {
 *   default allow := false
 *   allow if { input.queries_used < 12 }
 *   allow if { input.wall_ms < 30000 }
 *   allow if { input.cost_usd < 0.50 }
 *   deny if { input.mode == "action" }   # actions are never autonomous (§1.6)
 * }
 */

export type PolicyDecision = { allow: boolean; reason: string; rule: string };

export function allowQuery(budgetUsed: Budget, nextCostUsd: number): PolicyDecision {
  const { maxQueries, maxWallMs, maxCostUsd } = SETTINGS.budget;
  if (budgetUsed.queries + 1 > maxQueries) {
    return { allow: false, reason: `query budget exhausted (${budgetUsed.queries}/${maxQueries})`, rule: "budget.max_queries" };
  }
  if (budgetUsed.wallMs >= maxWallMs) {
    return { allow: false, reason: `wall-clock budget exhausted (${budgetUsed.wallMs}ms/${maxWallMs}ms)`, rule: "budget.max_wall_ms" };
  }
  if (budgetUsed.costUsd + nextCostUsd > maxCostUsd) {
    return { allow: false, reason: `cost budget exhausted ($${(budgetUsed.costUsd + nextCostUsd).toFixed(3)}/$${maxCostUsd})`, rule: "budget.max_cost_usd" };
  }
  return { allow: true, reason: "within budget", rule: "budget.allow" };
}

/** §1.6 / §15: actions are never autonomous in Phase 1-4. */
export function allowAction(action: string): PolicyDecision {
  return {
    allow: false,
    reason: `action '${action}' requires human approval (Phase 1-4 has no autonomous containment)`,
    rule: "action.gate.human_approval_required",
  };
}
