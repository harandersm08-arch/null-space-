import type { Assertion, Finding, FindingType, Reproducibility, UntrustedData } from "./types";
import { evaluateAssertion, formatValue } from "./util";
import { getTemplate } from "./templates";

/** findings/builder.py — every finding is an executable query + result hash. */

/** "Did this query return substantive observations?" (typed, per template). */
const PRIMARY_ASSERTION: Record<string, Assertion> = {
  asset_context: { field: "edr_agent_status", op: "ne", value: "unknown" },
  change_calendar_lookup: { field: "ticket_count", op: "gte", value: 1 },
  hash_fleet_occurrence: { field: "occurrence_count", op: "gte", value: 1 },
  edr_process_tree: { field: "found", op: "is_true" },
  edr_heartbeat_check: { field: "coverage_pct", op: "gte", value: 0.9 },
  idp_signin_lookup: { field: "event_count", op: "gte", value: 1 },
  dns_resolution_lookup: { field: "resolution_count", op: "gte", value: 1 },
  proxy_egress_lookup: { field: "flow_count", op: "gte", value: 1 },
};

const SUMMARY_FIELDS: Record<string, string[]> = {
  asset_context: ["criticality", "department", "edr_agent_status"],
  change_calendar_lookup: ["ticket_count", "open_ticket_covering_event"],
  hash_fleet_occurrence: ["occurrence_count", "distinct_hosts"],
  edr_process_tree: ["found", "parent_process_name", "signature_valid", "suspicious_module_count"],
  edr_heartbeat_check: ["agent_status", "coverage_pct", "gap_covering_event"],
  idp_signin_lookup: ["event_count", "interactive_count", "mfa_used", "new_country", "impossible_travel"],
  dns_resolution_lookup: ["sensor_status", "resolution_count", "new_domain_count", "suspicious_domain_count"],
  proxy_egress_lookup: ["sensor_status", "flow_count", "egress_to_raw_ip"],
};

export function isSubstantive(templateId: string, data: Record<string, unknown>): boolean {
  const assertion = PRIMARY_ASSERTION[templateId];
  if (!assertion) return true;
  return evaluateAssertion(assertion, data);
}

export function summarize(templateId: string, data: Record<string, unknown>): string {
  const fields = SUMMARY_FIELDS[templateId] ?? [];
  const parts = fields.filter((f) => data[f] !== undefined).map((f) => `${f}=${formatValue(data[f])}`);
  return parts.length ? parts.join(", ") : "no typed return fields";
}

export function shortParams(params: Record<string, unknown>): string {
  return Object.entries(params)
    .map(([k, v]) => `${k}=${formatValue(v)}`)
    .join(", ");
}

export interface BuildFindingArgs {
  id: string;
  templateId: string;
  params: Record<string, unknown>;
  untrusted: UntrustedData;
  hash: string;
  snapshotUri: string;
}

export function buildFinding(args: BuildFindingArgs): Finding {
  const template = getTemplate(args.templateId);
  const data = args.untrusted.data;
  const coverage = args.untrusted.coverage.status;
  const substantive = isSubstantive(args.templateId, data);
  const reproducibility: Reproducibility = template?.reproducibility ?? "point_in_time";

  let type: FindingType;
  let claim: string;
  if (coverage !== "covered") {
    type = "absence";
    claim = `No usable evidence: ${args.untrusted.coverage.source} was not monitoring ${args.untrusted.coverage.asset} (${args.untrusted.coverage.detail}).`;
  } else if (substantive) {
    type = "presence";
    claim = `${template?.description ?? args.templateId}: observed ${summarize(args.templateId, data)}.`;
  } else {
    type = "absence";
    claim = `Evidence of absence: ${args.untrusted.coverage.source} covered ${args.untrusted.coverage.asset} and observed ${summarize(args.templateId, data)}.`;
  }

  return {
    id: args.id,
    claim,
    type,
    queryTemplateId: args.templateId,
    params: args.params,
    executedAt: new Date().toISOString(),
    resultHash: args.hash,
    resultSnapshotUri: args.snapshotUri,
    reproducibility,
    coverageAtExecution: coverage,
    hypothesisImpact: [],
    summary: summarize(args.templateId, data),
  };
}

/** Reclassify a finding as an anomaly when the ETM/tamper logic fires. */
export function markAnomaly(finding: Finding, reason: string): Finding {
  if (finding.type === "anomaly") return finding;
  return { ...finding, type: "anomaly", claim: `${finding.claim} Negative-space anomaly: ${reason}` };
}
