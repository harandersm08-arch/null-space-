import { allTemplates, getTemplate } from "./templates";
import { conditionMet, contextFacts } from "./etm";
import { SETTINGS } from "./settings";
import { canonicalJson } from "./util";
import { liveHypotheses, queryKey, type EngineState, type PendingQuery } from "./state";

/** core/selector.py — information-gain query selection (§8.2). */

export type Candidate = PendingQuery;

export interface IgBreakdown {
  score: number;
  discriminativeness: number;
  novelty: number;
  coverageNeed: number;
  penalty: number;
  rationale: string;
}

export function computeIg(templateId: string, params: Record<string, unknown>, state: EngineState): IgBreakdown {
  const template = getTemplate(templateId);
  const facts = contextFacts(state.alert);
  const paramsJson = canonicalJson(params);
  const live = liveHypotheses(state);

  const killed: string[] = [];
  const shifted: string[] = [];
  let discriminativeness = 0;
  for (const h of live) {
    for (const p of h.predictions) {
      if (p.queryTemplateId !== templateId) continue;
      if (canonicalJson(p.params) !== paramsJson) continue;
      if (p.outcome !== null && p.outcome !== undefined) continue;
      let weight = 0;
      if (p.necessity === "hard") {
        weight = SETTINGS.ig.hardWeight;
        killed.push(`${h.id}(${h.key ?? h.hypothesisClass})`);
      } else if (p.necessity === "soft") {
        weight = SETTINGS.ig.softWeight;
        shifted.push(`${h.id}(${h.key ?? h.hypothesisClass})`);
      } else {
        weight = 0; // conditional predictions only bind when their typed condition holds
      }
      discriminativeness += h.prior * weight;
    }
  }

  let novelty = 0;
  const noveltyParts: string[] = [];
  if (template?.returnsCollection) {
    novelty += SETTINGS.ig.noveltyListBonus;
    noveltyParts.push("collection return space");
  }
  const queriedSources = new Set(state.findings.map((f) => getTemplate(f.finding.queryTemplateId)?.source));
  if (template && !queriedSources.has(template.source)) {
    novelty += SETTINGS.ig.noveltySourceBonus;
    noveltyParts.push(`new source ${template.source}`);
  }

  let coverageNeed = 0;
  const coverageParts: string[] = [];
  for (const artifact of state.etm.requiredIfReal) {
    if (artifact.probeTemplateId !== templateId) continue;
    const artifactState = state.case.negativeSpace.artifacts.find((a) => a.artifact === artifact.artifact);
    if (!artifactState || artifactState.inference !== "unknown") continue;
    if (!conditionMet(artifact, facts)) continue;
    const bonus = SETTINGS.ig.coverageBonus[artifact.necessity];
    coverageNeed += bonus;
    coverageParts.push(`${artifact.artifact} (${artifact.necessity}, unresolved)`);
  }

  const latencyS = template?.typicalLatencyS ?? 1;
  const cost = template?.cost ?? 1;
  const penalty = SETTINGS.ig.lambdaLatencyPerSecond * latencyS + SETTINGS.ig.muCostPerUnit * cost;

  const score = Number((discriminativeness + novelty + coverageNeed - penalty).toFixed(4));

  const rationaleParts: string[] = [];
  if (killed.length) rationaleParts.push(`can falsify ${killed.join(", ")}`);
  if (shifted.length) rationaleParts.push(`shifts ${shifted.join(", ")}`);
  if (coverageParts.length) rationaleParts.push(`resolves ETM requirement ${coverageParts.join("; ")}`);
  if (noveltyParts.length) rationaleParts.push(`novelty: ${noveltyParts.join("; ")}`);
  rationaleParts.push(`penalty ${penalty.toFixed(3)} (latency ${latencyS}s, cost ${cost})`);

  return {
    score,
    discriminativeness: Number(discriminativeness.toFixed(4)),
    novelty: Number(novelty.toFixed(4)),
    coverageNeed: Number(coverageNeed.toFixed(4)),
    penalty: Number(penalty.toFixed(4)),
    rationale: rationaleParts.join(" · "),
  };
}

export function enumerateCandidates(state: EngineState): Candidate[] {
  const out: Candidate[] = [];
  for (const template of allTemplates()) {
    const base = template.bindFromAlert(state.alert);
    if (!base) continue;
    const bindings: Record<string, unknown>[] = [base];

    // Discovered context (§8.5.4): a process tree can reveal a different identity.
    const tree = state.findings.find((f) => f.finding.queryTemplateId === "edr_process_tree");
    const treeUser = typeof tree?.result.user === "string" ? tree.result.user : null;
    if (template.id === "idp_signin_lookup" && treeUser && treeUser !== state.alert.user) {
      bindings.push({ user: treeUser, window: "24h" });
    }

    for (const params of bindings) {
      if (state.runKeys.has(queryKey(template.id, params))) continue;
      const ig = computeIg(template.id, params, state);
      if (ig.discriminativeness <= 0 && ig.coverageNeed <= 0) continue;
      out.push({ templateId: template.id, params, igScore: ig.score, rationale: ig.rationale });
    }
  }
  return out.sort((a, b) => b.igScore - a.igScore);
}

export function selectQuery(state: EngineState): Candidate | null {
  const ranked = enumerateCandidates(state);
  const best = ranked[0];
  if (!best) return null;
  if (best.igScore < SETTINGS.budget.minIgThreshold) return null;
  return best;
}

/** Best un-run query, used to phrase the decisive question for an analyst. */
export function bestUnrunCandidate(state: EngineState): Candidate | null {
  return enumerateCandidates(state)[0] ?? null;
}
