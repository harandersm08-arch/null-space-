import type { Finding, VerifyResult } from "./types";
import { deepDiff, resultHash } from "./util";
import type { ExecOutcome } from "./executor";

/** findings/verifier.py — re-execute, diff, PASS / DRIFT / FAIL (§11). */

export function verifyFinding(
  finding: Finding,
  snapshot: Record<string, unknown> | null,
  outcome: ExecOutcome,
): VerifyResult {
  const originalHash = finding.resultHash;
  if (!outcome.ok || !outcome.untrusted) {
    return {
      status: "FAIL",
      originalHash,
      currentHash: "",
      diff: null,
      message: `Re-execution of ${finding.queryTemplateId} failed: ${outcome.errors.join("; ")}`,
      findingId: finding.id,
      caseId: "",
    };
  }

  const currentHash = resultHash(outcome.templateId, outcome.params, outcome.untrusted.data);
  const snapshotData = (snapshot?.data ?? null) as Record<string, unknown> | null;

  if (finding.reproducibility === "point_in_time") {
    if (currentHash === originalHash) {
      return {
        status: "PASS",
        originalHash,
        currentHash,
        diff: null,
        message: `Point-in-time replay reproduced the exact result hash for ${finding.queryTemplateId}.`,
        findingId: finding.id,
        caseId: "",
      };
    }
    return {
      status: "FAIL",
      originalHash,
      currentHash,
      diff: deepDiff(snapshotData ?? {}, outcome.untrusted.data),
      message: `Point-in-time result changed between original execution and replay (snapshot drift or tampering).`,
      findingId: finding.id,
      caseId: "",
    };
  }

  const diff = deepDiff(snapshotData ?? {}, outcome.untrusted.data);
  if (!diff) {
    return {
      status: "PASS",
      originalHash,
      currentHash,
      diff: null,
      message: `Live state is unchanged since execution for ${finding.queryTemplateId}.`,
      findingId: finding.id,
      caseId: "",
    };
  }
  return {
    status: "DRIFT",
    originalHash,
    currentHash,
    diff,
    message: `Live state changed since execution for ${finding.queryTemplateId} (expected for live_state findings).`,
    findingId: finding.id,
    caseId: "",
  };
}
