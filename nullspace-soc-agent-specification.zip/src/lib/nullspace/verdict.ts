import type { Verdict } from "./types";
import { SETTINGS } from "./settings";
import { isRecurringResolution } from "./hypotheses";
import { liveHypotheses, type EngineState } from "./state";
import { unresolvedHardRequirements } from "./negativeSpace";
import { getTemplate } from "./templates";

/** core/verdict.py — verdict calculus (§10). */

export interface VerdictResult {
  verdict: Verdict | null;
  confidence: number;
  reason: string;
  benignShare: number;
  maliciousShare: number;
  corroboration: number;
  benignBestKey: string | null;
}

export function massShares(state: EngineState) {
  const live = liveHypotheses(state);
  const benignMass = live.filter((h) => h.hypothesisClass === "benign").reduce((s, h) => s + h.posterior, 0);
  const maliciousMass = live.filter((h) => h.hypothesisClass === "malicious").reduce((s, h) => s + h.posterior, 0);
  const tamperMass = live.filter((h) => h.hypothesisClass === "tamper").reduce((s, h) => s + h.posterior, 0);
  const total = benignMass + maliciousMass + tamperMass;
  return {
    benignMass,
    maliciousMass,
    tamperMass,
    total,
    benignShare: total > 0 ? benignMass / total : 0,
    maliciousShare: total > 0 ? maliciousMass / total : 0,
  };
}

/** Distinct findings that positively confirm a live malicious hypothesis. */
export function countCorroboration(state: EngineState): number {
  const live = liveHypotheses(state);
  const ids = new Set<string>();
  for (const h of live) {
    if (h.hypothesisClass !== "malicious") continue;
    for (const p of h.predictions) {
      if (p.outcome === "confirmed" && p.evidenceFindingId) ids.add(p.evidenceFindingId);
    }
  }
  return ids.size;
}

/**
 * A blind sensor can never clear an alert: if a live malicious hypothesis still
 * has a hard prediction that could not be observed because the sensor was
 * uncovered, a benign verdict is not available (invariant 3).
 */
export function hasMaliciousBlindSpot(state: EngineState): boolean {
  return liveHypotheses(state).some(
    (h) =>
      h.hypothesisClass === "malicious" &&
      h.predictions.some((p) => p.necessity === "hard" && p.outcome === "unobservable"),
  );
}

/**
 * Falsification-first stopping rule: the agent may not accept a benign verdict
 * while a leading benign hypothesis still has an UNTESTED hard prediction. You
 * accept a benign explanation only after you have tried to kill it.
 */
export function hasUntestedCriticalPrediction(state: EngineState): boolean {
  return liveHypotheses(state).some(
    (h) =>
      h.hypothesisClass === "benign" &&
      h.posterior >= 0.1 &&
      h.predictions.some((p) => p.necessity === "hard" && (p.outcome === null || p.outcome === undefined)),
  );
}

/**
 * A verdict is "recurring noise" when a benign explanation that this case just
 * *confirmed* has also been confirmed >= 30 times in the recent history window.
 */
export function recurringNoiseResolution(state: EngineState): string | null {
  const live = liveHypotheses(state).filter((h) => h.hypothesisClass === "benign");
  for (const h of live) {
    if (!h.key) continue;
    const confirmedHard = h.predictions.some((p) => p.necessity === "hard" && p.outcome === "confirmed");
    if (!confirmedHard) continue;
    if (isRecurringResolution(h.key, state.clusters, state.dbBenignCaseCounts[h.key] ?? 0)) return h.key;
  }
  return null;
}

export function computeVerdict(state: EngineState, opts: { force?: boolean } = {}): VerdictResult {
  const shares = massShares(state);
  const live = liveHypotheses(state);
  const report = state.case.negativeSpace;
  const corroboration = countCorroboration(state);
  const benignBest = live
    .filter((h) => h.hypothesisClass === "benign")
    .sort((a, b) => b.posterior - a.posterior)[0];

  const base: VerdictResult = {
    verdict: null,
    confidence: 0,
    reason: "",
    benignShare: shares.benignShare,
    maliciousShare: shares.maliciousShare,
    corroboration,
    benignBestKey: benignBest?.key ?? null,
  };

  // Gate 0: hard evidence requirements must be resolved before any verdict.
  const unresolved = unresolvedHardRequirements(report);
  if (unresolved.length > 0 && !opts.force) {
    return {
      ...base,
      reason: `unresolved hard telemetry requirements: ${unresolved.map((a) => a.artifact).join(", ")}`,
    };
  }

  // Tamper overrides everything.
  if (report.overall === "anomaly") {
    const strong = report.tamperSignals.filter((s) => s.weight === "high" || s.weight === "critical");
    return {
      ...base,
      verdict: "tamper_suspected",
      confidence: Number(Math.min(0.96, 0.6 + 0.12 * strong.length + 0.06 * report.tamperSignals.length).toFixed(3)),
      reason: `negative-space anomaly: ${report.tamperSignals.map((s) => s.pattern).join(" | ") || "hard-required telemetry missing while sensors were covered"}`,
    };
  }

  // Benign: dominant benign mass, negligible malicious mass, no blind spots.
  if (
    shares.benignShare > SETTINGS.verdict.benignThreshold &&
    shares.maliciousShare < 0.15 &&
    !hasMaliciousBlindSpot(state) &&
    !hasUntestedCriticalPrediction(state)
  ) {
    const recurring = recurringNoiseResolution(state);
    if (recurring) {
      return {
        ...base,
        verdict: "benign_noisy",
        confidence: Number(Math.min(0.97, shares.benignShare).toFixed(3)),
        reason: `benign mass ${(shares.benignShare * 100).toFixed(0)}%; confirmed resolution '${recurring}' recurred within ${SETTINGS.history.recurringWindowDays}d`,
      };
    }
    return {
      ...base,
      verdict: "benign",
      confidence: Number(Math.min(0.97, shares.benignShare).toFixed(3)),
      reason: `benign mass ${(shares.benignShare * 100).toFixed(0)}% with falsified alternatives`,
    };
  }

  // Suspicious: every credible benign hypothesis is dead + corroboration.
  const benignWithPrior = state.hypotheses.filter(
    (h) => h.hypothesisClass === "benign" && h.prior > 0.1,
  );
  const allBenignDead = benignWithPrior.length > 0 && benignWithPrior.every((h) => h.status === "falsified");
  if (allBenignDead && shares.maliciousShare > SETTINGS.verdict.maliciousThreshold && corroboration >= SETTINGS.verdict.minCorroboration) {
    return {
      ...base,
      verdict: "suspicious",
      confidence: Number(Math.min(0.95, shares.maliciousShare).toFixed(3)),
      reason: `all benign hypotheses with prior > 0.10 are falsified; ${corroboration} corroborating findings on malicious hypotheses`,
    };
  }

  // INDETERMINATE is only ever *forced*: the loop keeps going while there is a
  // query left whose information gain clears the threshold. The anytime
  // property is preserved by output_node forcing a verdict.
  if (opts.force) {
    const unresolvedText = unresolved.length
      ? ` (unresolved: ${unresolved.map((a) => a.artifact).join(", ")})`
      : "";
    return {
      ...base,
      verdict: "indeterminate",
      confidence: Number(Math.max(0.05, 1 - Math.max(shares.benignShare, shares.maliciousShare)).toFixed(3)),
      reason:
        state.stepCount >= SETTINGS.verdict.minQueriesForIndeterminate
          ? `no hypothesis reached threshold after ${state.stepCount} queries${unresolvedText}`
          : `stopped after only ${state.stepCount} queries (below the ${SETTINGS.verdict.minQueriesForIndeterminate}-query minimum)${unresolvedText}`,
    };
  }

  return { ...base, reason: "below threshold; continuing" };
}

export function recommendedAction(verdict: Verdict, state: EngineState): string {
  const findingIds = state.findings
    .filter((f) => f.finding.hypothesisImpact.length > 0)
    .slice(0, 3)
    .map((f) => f.finding.id);
  switch (verdict) {
    case "benign":
      return `Close as false positive. Attach ${findingIds.join(", ") || "the finding set"} as reproducible evidence. No action required.`;
    case "benign_noisy":
      return `Close as false positive and raise a detection-tuning recommendation for ${state.alert.ruleId} (${state.alert.ruleName}): this benign resolution recurs.`;
    case "suspicious":
      return `Escalate to Tier-2 containment review with the corroborating findings (${findingIds.join(", ") || "see findings"}). Host isolation is NOT autonomous — it must go through the human approval action gate.`;
    case "tamper_suspected":
      return `Escalate to IR. Preserve the host, verify EDR agent integrity and pull the heartbeat timeline. Any containment requires human approval.`;
    case "confirmed":
      return `Escalate to IR as confirmed (canary module). Containment requires human approval.`;
    default:
      return `Return to the analyst with the decisive question. Do not close on absence of evidence — the sensor coverage map shows unresolved requirements.`;
  }
}

/** Fallback decisive question when the query pool is exhausted: restore coverage. */
export function coverageDecisiveQuestion(state: EngineState): string | null {
  const report = state.case.negativeSpace;
  const unresolved = report.artifacts.filter((a) => a.inference === "unknown");
  if (unresolved.length === 0) return null;
  const parts = unresolved.map((a) => {
    const artifact = state.etm.requiredIfReal.find((x) => x.artifact === a.artifact);
    const scope = artifact?.probeParamsFrom === "user" ? state.alert.user : state.alert.asset;
    const cause = a.covered === "uncovered" ? "no sensor deployed for this asset" : "requirement not yet probed";
    return `${a.artifact} on ${scope} (${cause}) — deploy/repair the collector, then re-run ${artifact?.probeTemplateId ?? "the probe"}`;
  });
  const reduction = Math.min(70, 22 * unresolved.length + 8);
  return `Telemetry coverage is the blocker, not the analysis: ${parts.join("; ")}. Expected uncertainty reduction ≈ ${reduction}% once that sensor answers.`;
}

/** Human-readable decisive question with expected uncertainty reduction. */
export function decisiveQuestion(
  state: EngineState,
  candidate: { templateId: string; params: Record<string, unknown>; igScore: number } | null,
): string | null {
  if (!candidate) return null;
  const template = getTemplate(candidate.templateId);
  const shares = massShares(state);
  const entropyBefore = -[shares.benignShare, shares.maliciousShare]
    .filter((p) => p > 0)
    .reduce((s, p) => s + p * Math.log2(p), 0);
  const expectedReduction = Math.min(
    65,
    Math.max(8, Math.round((candidate.igScore / Math.max(0.2, entropyBefore || 1)) * 100 * 0.35)),
  );
  const p = candidate.params;
  const target = p.asset ?? p.user ?? p.hash ?? "";
  const questions: Record<string, string> = {
    asset_context: `Who owns ${target} and is it a managed, monitored asset?`,
    change_calendar_lookup: `Was there an approved change open for ${target} at ${state.alert.observedAt}?`,
    hash_fleet_occurrence: `Is ${String(p.hash ?? "").slice(0, 12)}… in use on other hosts in the fleet?`,
    edr_process_tree: `What was the parent process of PID ${String(p.pid ?? "")} on ${target}?`,
    edr_heartbeat_check: `Was the EDR agent on ${target} reporting throughout the event window?`,
    idp_signin_lookup: `What do the IdP sign-ins for ${target} show in the last 24h?`,
    dns_resolution_lookup: `What did ${target} resolve in the event window?`,
    proxy_egress_lookup: `What did ${target} egress to in the event window?`,
  };
  const question = questions[candidate.templateId] ?? `Run ${candidate.templateId} on ${target}`;
  return `${question} (${template?.description ?? candidate.templateId}) — expected uncertainty reduction ≈ ${expectedReduction}%, IG ${candidate.igScore.toFixed(3)}.`;
}
