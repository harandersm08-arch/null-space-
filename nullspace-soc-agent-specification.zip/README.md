# NullSpace

A falsification-first autonomous SOC investigation agent.

> The agent's primary question is **“can I prove this alert benign?”** — not “is this malicious?”

This repository is a full implementation of the NullSpace spec (Phase 1–4 scope) on a
TypeScript / Next.js (App Router) + PostgreSQL/Drizzle stack instead of Python/LangGraph/FastAPI.
The module boundaries, data model, state machine and every invariant from the spec are preserved;
see the port map below.

## What it does

1. **Normalize** an alert into a standard envelope and classify it (`SEC-1001`/`SEC-1077` →
   `process_execution.suspicious_powershell`).
2. **Generate hypotheses** from four sources: curated library (10 entries + H0 malicious default),
   history mining (clustered past resolutions), org context (change window / service account), and a
   generative fallback (OpenAI when `OPENAI_API_KEY` is set, deterministic heuristics otherwise).
   Any hypothesis without a falsifiable prediction is discarded.
3. **Select** the next query by expected information gain:
   `discriminativeness + novelty + ETM-coverage-need − λ·latency − μ·cost`.
4. **Execute** it through the allowlisted template registry (read-only adapter, schema-validated
   params, sha256 result hash, snapshot URI) behind an OPA-style budget policy.
5. **Update**: falsify hypotheses on violated *hard* predictions, apply likelihood ratios to
   posteriors, re-normalize live mass, score negative space, spawn a tamper hypothesis on anomaly.
6. **Output** a verdict (benign / benign_noisy / suspicious / tamper_suspected / indeterminate) with
   confidence, recommended action, and — when indeterminate — the single decisive question with the
   highest remaining information gain.

## Core invariants (§1) and where they live

| Invariant | Enforcement |
|---|---|
| Prove-benign-first | `core/verdict.ts` benign gate, `HYPOTHESIS_LIBRARY` is benign-dominant |
| ≥1 falsifiable prediction per hypothesis | `hypotheses.ts` filters `predictions.length === 0` |
| Missing evidence is a first-class signal | `etm.ts` + `negativeSpace.ts` + `coverage.ts` |
| Findings are executable queries + hashes | `findings.ts`, `executor.ts`, `/api/findings/{id}/verify` |
| LLM never writes queries | `templates.ts` registry + `llm.ts` validation of template id / param schema / return field |
| Read-only tools, no autonomous actions | `executor.ts` (`accessMode: "read-only"`), `policy.ts` `allowAction()` always denies |
| Anytime verdict | `engine.ts` `outputNode` forces a verdict when the budget or the query pool is exhausted |

## Port map (spec → this repo)

| Spec (Python) | Here |
|---|---|
| `core/models.py` | `src/lib/nullspace/types.ts` |
| `core/engine.py` (LangGraph) | `src/lib/nullspace/engine.ts` (`StateGraph` with nodes `init → select → execute → record → update → check → output`) |
| `core/selector.py` | `src/lib/nullspace/selector.ts` |
| `core/verdict.py` | `src/lib/nullspace/verdict.ts` |
| `core/coverage.py` | `src/lib/nullspace/coverage.ts` |
| `hypotheses/*` | `src/lib/nullspace/hypotheses.ts` (+ `llm.ts`) |
| `telemetry/etm.py`, `negative_space.py`, `coverage_map.py` | `etm.ts`, `negativeSpace.ts`, `coverage.ts` |
| `queries/registry.py`, `executor.py`, `config/templates/*.yaml` | `templates.ts` (8 templates with zod param schemas) |
| `findings/builder.py`, `verifier.py` | `findings.ts`, `verifier.ts` |
| `llm/*` | `llm.ts` (OpenAI `gpt-4o-mini`, JSON mode, output re-validated) |
| `api/app.py`, `routes.py` | `src/app/api/**` |
| OPA policy | `policy.ts` (explicit policy document + `allowQuery` / `allowAction`) |
| `config/etm/*.yaml` | `etm.ts` (typed ETM + tamper detectors) |
| `tests/golden/*` | `world.ts` (`SCENARIOS`) + `evaluate.ts` golden replay |
| `main.py` | `POST /api/cases` |

## API

| Method | Path | Purpose |
|---|---|---|
| `POST` | `/api/cases` | `{scenarioKey}` or `{alert:{...}}` → runs the loop, persists, returns case id + verdict |
| `GET` | `/api/cases` | recent case summaries |
| `GET` | `/api/cases/{id}` | full `Case` (hypotheses, findings, verdict, trace, span log) |
| `GET` | `/api/cases/{id}/trace` | `QueryTraceStep[]` for the kill board |
| `POST` | `/api/findings/{id}/verify` | `{mode:"replay"\|"drift"}` → `PASS` / `DRIFT` / `FAIL` with diff |
| `GET` | `/api/coverage/{asset}/{source}/{start}/{end}` | `covered \| uncovered \| unknown` |
| `POST` | `/api/evaluate` | golden-case replay + sycophancy/negative-space/budget metrics |
| `GET` | `/api/health` | liveness + DB check |

## UI

- `/` — scenario launcher (6 golden cases), ad-hoc alert form, fleet state, recent cases.
- `/cases/{id}` — the analyst kill board: hypothesis ledger with prior→posterior and prediction
  outcomes, findings with one-click re-execution, query trace with IG rationale, negative-space
  report, tamper signals, engine span log.
- `/evaluate` — Phase 4 calibration report.
- `/reference` — the allowlisted surface: query registry, ETM, hypothesis library, settings.

## Golden-set results (Phase 2/4 acceptance)

| Metric | Result | Target |
|---|---|---|
| Verdict accuracy | 6/6 | all labelled cases |
| Sycophancy rate | 0% | < 5% |
| Average queries | 6.0 | ≤ 8 |
| Benign-explanation survival | 100% | ≥ 80% |
| False-negative rate | 0% | ≤ 5% |
| Negative-space test | anomaly + 3 tamper signals when the EDR heartbeat gap is present | required |

The uncovered-sensor case correctly returns `indeterminate` with a decisive question instead of a
false “nothing found”, because a blind sensor can never clear an alert.

## Local development

```bash
npx drizzle-kit push     # create tables
npm run build && npm start
```

`OPENAI_API_KEY` is optional: without it the generative hypothesis source falls back to
deterministic heuristics, and the whole system runs with zero external dependencies.
